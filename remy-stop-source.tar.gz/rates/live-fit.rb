#!/usr/bin/env ruby
# frozen_string_literal: true

# Rate fit: quota percentage points per million tokens.
# Port of live-fit.mjs. Numbers, sort order, hashes and JSON text follow
# JavaScript semantics so results match the former Node pipeline.

require "json"
require "digest"
require "fileutils"
require "tmpdir"

Encoding.default_external = Encoding::UTF_8

RubyVM::YJIT.enable if defined?(RubyVM::YJIT) && RubyVM::YJIT.respond_to?(:enable) && !RubyVM::YJIT.enabled?

module Rates
  BASE = File.expand_path(__dir__)
  TOKEN_TYPES = %w[input cache_read cache_write cache_write_5m cache_write_1h output reasoning nonreasoning_output].freeze
  NAN = Float::NAN
  INF = Float::INFINITY

  # JavaScript value semantics used by the pipeline.
  module JS
    module_function

    def now_ms = Process.clock_gettime(Process::CLOCK_REALTIME, :millisecond)

    # a ?? b ?? c
    def nn(*values) = values.find { |v| !v.nil? }

    def nan?(v) = v.is_a?(Float) && v.nan?

    def truthy(v)
      !(v.nil? || v == false || v == "" || (v.is_a?(Numeric) && (v.zero? || nan?(v))))
    end

    def get(object, key) = object.is_a?(Hash) ? object[key] : nil

    def dig(object, *keys) = keys.reduce(object) { |o, k| get(o, k) }

    # Number.isFinite
    def finite?(v) = v.is_a?(Numeric) && v.finite?

    WS = "[\t\n\v\f\r    -     　﻿]"
    TRIM = /\A#{WS}+|#{WS}+\z/

    # Number(v)
    def number(v)
      case v
      when Integer, Float then v
      when nil, false then 0
      when true then 1
      when String then string_number(v)
      when Array then string_number(join(v, ","))
      else NAN
      end
    end

    def string_number(s)
      t = s.gsub(TRIM, "")
      return 0 if t.empty?
      case t
      when /\A[+-]?Infinity\z/ then t.start_with?("-") ? -INF : INF
      when /\A0[xX]\h+\z/ then t[2..].to_i(16)
      when /\A0[oO][0-7]+\z/ then t[2..].to_i(8)
      when /\A0[bB][01]+\z/ then t[2..].to_i(2)
      when /\A[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?\z/ then t.to_f
      else NAN
      end
    end

    # live-fit.mjs finite/token/num
    def finite_value?(v) = !v.nil? && v != "" && finite?(number(v))
    def token(v)
      return v.negative? ? nil : v if v.is_a?(Integer)
      return nil if v.nil?
      finite_value?(v) && number(v) >= 0 ? number(v) : nil
    end
    def num(v) = finite_value?(v) ? number(v) : nil

    def time(v)
      if v.is_a?(Numeric) || (v.is_a?(String) && v.match?(/\A\d+(\.\d+)?\z/))
        n = v.is_a?(String) ? v.to_f : v
        n < 1e11 ? n * 1000 : n
      elsif v.is_a?(String)
        date_parse(v)
      else
        NAN
      end
    end

    ISO = /\A([+-]\d{6}|\d{4})(?:-(\d{2})(?:-(\d{2}))?)?(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?(Z|[+-]\d{2}:\d{2})?)?\z/

    # Date.parse for the ES ISO format; other formats are NaN.
    def date_parse(s)
      m = ISO.match(s) or return NAN
      year = m[1].to_i
      month = (m[2] || "1").to_i
      day = (m[3] || "1").to_i
      hour = (m[4] || "0").to_i
      minute = (m[5] || "0").to_i
      second = (m[6] || "0").to_i
      ms = m[7] ? (m[7] + "00")[0, 3].to_i : 0
      return NAN unless (1..12).cover?(month) && (1..31).cover?(day) && hour <= 24 && minute <= 59 && second <= 59
      return NAN if hour == 24 && (minute.positive? || second.positive? || ms.positive?)
      return NAN if day > days_in_month(year, month)
      if m[4] && m[8].nil?
        Time.local(year, month, day, hour, minute, second).to_i * 1000 + ms
      else
        offset = 0
        if m[8] && m[8] != "Z"
          sign = m[8].start_with?("-") ? -1 : 1
          offset = sign * (m[8][1, 2].to_i * 60 + m[8][4, 2].to_i) * 60_000
        end
        utc_ms(year, month, day, hour, minute, second) + ms - offset
      end
    end

    def days_in_month(year, month)
      return 29 if month == 2 && (year % 4).zero? && (!(year % 100).zero? || (year % 400).zero?)
      [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1]
    end

    # Date.UTC
    def utc_ms(year, month, day, hour = 0, minute = 0, second = 0)
      extra = hour == 24 ? 86_400_000 : 0
      Time.utc(year, month, day, hour == 24 ? 0 : hour, minute, second).to_i * 1000 + extra
    end

    def with_tz(tz)
      old = ENV["TZ"]
      return yield if old == tz || (old.nil? && tz == SYSTEM_TZ)
      begin
        ENV["TZ"] = tz
        yield
      ensure
        ENV["TZ"] = old
      end
    end

    SYSTEM_TZ = begin
      File.readlink("/etc/localtime").split("zoneinfo/", 2)[1]
    rescue StandardError
      nil
    end

    # Intl.DateTimeFormat parts for a millisecond time in a named zone.
    def local_fields(t, tz)
      ms = t.truncate
      with_tz(tz) do
        lt = Time.at(Rational(ms, 1000)).localtime
        [lt.year, lt.month, lt.day, lt.hour, lt.min, lt.sec]
      end
    end

    def local_parts(t, tz)
      y, m, d, h = local_fields(t, tz)
      {date: format("%04d-%02d-%02d", y, m, d), hour: h}
    end

    def local_date(t, tz) = local_parts(t, tz)[:date]

    def local_midnight(t, tz)
      y, m, d = local_parts(t, tz)[:date].split("-").map(&:to_i)
      civil = utc_ms(y, m, d)
      guess = civil
      3.times do
        rendered = utc_ms(*local_fields(guess, tz))
        guess = civil - (rendered - guess)
      end
      guess
    end

    # Date.prototype.toISOString
    def iso(t)
      ms = t.truncate
      Time.at(Rational(ms, 1000)).utc.strftime("%Y-%m-%dT%H:%M:%S.%LZ")
    end

    # Number.prototype.toString
    def num_s(x)
      return x.to_s if x.is_a?(Integer)
      return "NaN" if x.nan?
      return(x.positive? ? "Infinity" : "-Infinity") if x.infinite?
      return "0" if x.zero?
      return "-" + num_s(-x) if x.negative?
      digits, n = shortest(x)
      k = digits.length
      if k <= n && n <= 21
        digits + "0" * (n - k)
      elsif n.positive? && n <= 21
        digits[0, n] + "." + digits[n..]
      elsif n > -6 && n <= 0
        "0." + "0" * -n + digits
      else
        e = n - 1
        mant = k == 1 ? digits : digits[0] + "." + digits[1..]
        mant + "e" + (e.negative? ? "-" : "+") + e.abs.to_s
      end
    end

    # Shortest round-trip digits d and exponent n with x = 0.d * 10**n.
    def shortest(x)
      s = x.to_s
      if s.include?("e")
        mant, exp = s.split("e")
        ip, fp = mant.split(".")
        digits = ip + fp.to_s
        n = ip.length + exp.to_i
      else
        ip, fp = s.split(".")
        if ip == "0"
          z = fp[/\A0*/].length
          digits = fp[z..]
          n = -z
        else
          digits = ip + fp.to_s
          n = ip.length
        end
      end
      digits = digits.sub(/0+\z/, "")
      lead = digits[/\A0*/].length
      [digits[lead..], n - lead]
    end

    # Number.prototype.toPrecision
    def to_precision(x, p)
      x = x.to_f
      return "NaN" if x.nan?
      return(x.positive? ? "Infinity" : "-Infinity") if x.infinite?
      return "-" + to_precision(-x, p) if x.negative?
      if x.zero?
        return p > 1 ? "0." + "0" * (p - 1) : "0"
      end
      r = x.to_r
      e = Math.log10(x).floor
      e -= 1 while Rational(10)**e > r
      e += 1 while Rational(10)**(e + 1) <= r
      scaled = r / Rational(10)**(e - p + 1)
      n = scaled.floor
      n += 1 if scaled - n >= Rational(1, 2)
      if n == 10**p
        n /= 10
        e += 1
      end
      a = n.to_s
      if e < -6 || e >= p
        (p == 1 ? a : a[0] + "." + a[1..]) + "e" + (e.negative? ? "-" : "+") + e.abs.to_s
      elsif e == p - 1
        a
      elsif e >= 0
        a[0, e + 1] + "." + a[(e + 1)..]
      else
        "0." + "0" * -(e + 1) + a
      end
    end

    # String(v)
    def str(v)
      case v
      when String then v
      when nil then "null"
      when Integer then v.to_s
      when Float then num_s(v)
      when true then "true"
      when false then "false"
      when Array then join(v, ",")
      when Hash then "[object Object]"
      else v.to_s
      end
    end

    # Array.prototype.join
    def join(values, sep = ",")
      return values.join(sep) if values.all?(String)
      values.map { |v| v.nil? ? "" : str(v) }.join(sep)
    end

    # Math.max for two numbers, including NaN and signed zero.
    def max2(a, b)
      return NAN if nan?(a) || nan?(b)
      if a == b
        return a.is_a?(Float) && a.zero? && (1.0 / a).negative? ? b : a
      end
      a > b ? a : b
    end

    def min_of(values) = values.reduce(INF) { |m, v| nan?(v) || nan?(m) ? NAN : (v < m ? v : m) }
    def max_of(values) = values.reduce(-INF) { |m, v| max2(m, v) }

    # Numeric Map/Set key: 5 and 5.0 are the same key in JavaScript.
    def key(v) = v.is_a?(Float) && v.finite? && v == v.truncate ? v.to_i : v

    # Stable sort by a key array (Array.prototype.sort is stable).
    def sort_by(values)
      keys = values.map { |v| yield(v) }
      n = values.length
      limit = 2**61 / [n, 1].max
      if keys.all? { |k| k.length == 1 && k[0].is_a?(Integer) && k[0].abs < limit }
        # One integer key: index-tagged fixnums keep the sort stable without array keys.
        order = (0...n).sort_by { |i| keys[i][0] * n + i }
        return order.map { |i| values[i] }
      end
      (0...values.length).sort_by { |i| [*keys[i], i] }.map { |i| values[i] }
    end

    INT_KEY = /\A(?:0|[1-9]\d{0,9})\z/

    # JSON.stringify(value, null, indent)
    def stringify(value, indent = nil)
      out = +""
      emit(value, indent && " " * indent, "", out)
      out
    end

    def emit(v, ind, cur, out)
      case v
      when nil then out << "null"
      when true then out << "true"
      when false then out << "false"
      when Integer then out << v.to_s
      when Float then out << (v.finite? ? num_s(v) : "null")
      when String then out << v.to_json
      when Symbol then out << v.to_s.to_json
      when Array
        if v.empty?
          out << "[]"
        elsif ind
          inner = cur + ind
          out << "[\n"
          v.each_with_index do |x, i|
            out << ",\n" if i.positive?
            out << inner
            emit(x, ind, inner, out)
          end
          out << "\n" << cur << "]"
        else
          out << "["
          v.each_with_index do |x, i|
            out << "," if i.positive?
            emit(x, ind, cur, out)
          end
          out << "]"
        end
      when Hash
        keys = v.keys
        if keys.any? { |k| k.is_a?(String) && k.match?(INT_KEY) && k.to_i < 4_294_967_295 }
          ints, rest = keys.partition { |k| k.is_a?(String) && k.match?(INT_KEY) && k.to_i < 4_294_967_295 }
          keys = ints.sort_by(&:to_i) + rest
        end
        if keys.empty?
          out << "{}"
        elsif ind
          inner = cur + ind
          out << "{\n"
          keys.each_with_index do |k, i|
            out << ",\n" if i.positive?
            out << inner << str(k).to_json << ": "
            emit(v[k], ind, inner, out)
          end
          out << "\n" << cur << "}"
        else
          out << "{"
          keys.each_with_index do |k, i|
            out << "," if i.positive?
            out << str(k).to_json << ":"
            emit(v[k], ind, cur, out)
          end
          out << "}"
        end
      else
        out << v.to_s.to_json
      end
    end

    # Array.prototype.reduce((s, v) => s + f(v), 0): plain left-to-right addition.
    def sum(values) = values.reduce(0) { |s, v| s + yield(v) }

    def sha256(text) = Digest::SHA256.hexdigest(text)
    def digest(value) = sha256(stringify(value))

    # String.prototype.localeCompare (ICU root collation) for the ASCII keys
    # used in card ordering.
    PUNCT = "\t\n\v\f\r _-,;:!?.'\"()[]{}@*/\\&#%`^+<=>|~$0123456789"
    PRIMARY = {}.tap do |h|
      PUNCT.each_char.with_index { |c, i| h[c] = [i + 1, 0] }
      ("a".."z").each_with_index do |c, i|
        h[c] = [PUNCT.length + 1 + i, 0]
        h[c.upcase] = [PUNCT.length + 1 + i, 1]
      end
    end.freeze

    def collation_key(s)
      primary = []
      tertiary = []
      s.each_char do |c|
        w = PRIMARY[c]
        if w.nil?
          o = c.ord
          next if o < 0x20 || o == 0x7f
          w = [1000 + o, 0]
        end
        primary << w[0]
        tertiary << w[1]
      end
      [primary, tertiary]
    end
  end

  module_function

  def line_of(row) = row.key?("_line") ? {"line" => row["_line"]} : {}

  def normalize_samples(rows, config = {}, now = JS.now_ms)
    accepted = []
    rejected = []
    regimes = []
    seen = {}
    max_age = JS.nn(config["max_sample_age_ms"], 300_000)
    rows.each do |sample|
      observed = JS.time(sample["t"])
      source_t = JS.time(JS.nn(sample["source_timestamp"], sample["sourceTimestamp"]))
      t = JS.finite?(source_t) ? source_t : observed
      age = JS.num(JS.nn(sample["cache_age_ms"], sample["cacheAgeMs"], sample["age_ms"]))
      age = JS.finite?(observed) && JS.finite?(source_t) ? observed - source_t : 0 if age.nil?
      line = line_of(sample)
      if !JS.finite?(t) || t > now
        rejected << line.merge("reason" => "invalid_or_future_timestamp")
        next
      end
      if age > max_age || sample["fresh"] == false
        rejected << line.merge("reason" => "stale_source", "cache_age_ms" => age)
        next
      end
      next if t < JS.nn(config["epoch_start"], 0)
      raw = JS.nn(sample["rate_limits"], sample["usage"], sample)
      raw = JS.nn(JS.get(raw, "result"), raw)
      measured = JS.nn(sample["account"], JS.get(raw, "accountId"), JS.get(raw, "account_id"),
                       JS.dig(raw, "account", "accountId"), JS.dig(raw, "account", "id"))
      account = JS.nn(measured, sample["provider"] == "claude" ? "unattributed:claude:#{JS.str(JS.nn(sample["source"], "cached_usage"))}" : nil)
      account_source = JS.nn(sample["account_source"], JS.truthy(measured) ? "sample_metadata" : "assumed_anonymous_cached_stream")
      main_regime = JS.nn(JS.get(raw, "rateLimits"), JS.get(raw, "rate_limits"), raw)
      state = {
        "ordinaryUsageAllowed" => JS.get(raw, "ordinaryUsageAllowed"),
        "planType" => JS.nn(JS.get(main_regime, "planType"), JS.get(main_regime, "plan_type")),
        "credits" => JS.get(main_regime, "credits"),
        "spendControlReached" => JS.nn(JS.get(main_regime, "spendControlReached"), JS.get(main_regime, "spend_control_reached")),
        "availableResetCredits" => JS.dig(raw, "rateLimitResetCredits", "availableCount"),
      }
      source = JS.nn(sample["source"], "unknown")
      source_line = sample.key?("_line") ? {"source_line" => sample["_line"]} : {}
      if JS.truthy(account)
        regimes << {"provider" => sample["provider"], "account" => JS.str(account), "account_source" => account_source,
                    "t" => t, "state" => state, "source" => source}.merge(source_line)
      end
      regime_id = nil
      add = lambda do |kind, percent, reset, minutes, limit, slot|
        percent = JS.num(percent)
        reset_ms = JS.time(reset)
        if percent.nil? || percent.negative? || percent > 100 || !JS.finite?(reset_ms) || !JS.truthy(account)
          rejected << line.merge("reason" => JS.truthy(account) ? "invalid_quota" : "missing_sample_account", "kind" => kind)
          return
        end
        key = JS.join([sample["provider"], account, kind, limit, slot, reset_ms, t, percent], "|")
        return if seen.key?(key)
        seen[key] = true
        regime_id ||= JS.digest(state)[0, 12]
        accepted << {"provider" => sample["provider"], "account" => JS.str(account), "account_source" => account_source,
                     "kind" => kind, "percent" => percent, "reset" => reset_ms, "minutes" => minutes, "limit" => limit,
                     "slot" => slot, "t" => t, "observed_t" => observed, "source" => source}
                    .merge(source_line)
                    .merge("regime_id" => regime_id, "source_timestamp_reported" => JS.finite?(source_t), "cache_age_ms" => age)
      end
      case sample["provider"]
      when "codex"
        limits = []
        main = JS.nn(JS.get(raw, "rateLimits"), JS.get(raw, "rate_limits"), raw)
        limits << main if JS.truthy(JS.get(main, "primary")) || JS.truthy(JS.get(main, "secondary"))
        by = JS.nn(JS.get(raw, "rateLimitsByLimitId"), JS.get(raw, "rate_limits_by_limit_id"))
        (by.is_a?(Hash) ? by.values : []).each { |value| limits << value if JS.truthy(value) }
        limits.each do |l|
          id = JS.nn(JS.get(l, "limitId"), JS.get(l, "limit_id"), "codex")
          next unless id == "codex"
          %w[primary secondary].each do |slot|
            w = JS.get(l, slot)
            next unless JS.truthy(w)
            minutes = JS.num(JS.nn(JS.get(w, "windowDurationMins"), JS.get(w, "window_minutes")))
            next unless minutes == 300 || minutes == 10_080
            add.call(minutes == 300 ? "five_hour" : "seven_day", JS.nn(JS.get(w, "usedPercent"), JS.get(w, "used_percent")),
                     JS.nn(JS.get(w, "resetsAt"), JS.get(w, "resets_at")), minutes, id, slot)
          end
        end
      when "claude"
        usage = JS.nn(JS.get(raw, "usage"), raw)
        %w[five_hour seven_day].each do |kind|
          w = JS.get(usage, kind)
          next unless JS.truthy(w)
          add.call(kind, JS.nn(JS.get(w, "utilization"), JS.get(w, "used_percent"), JS.get(w, "usedPercent")),
                   JS.nn(JS.get(w, "resets_at"), JS.get(w, "resetsAt")), kind == "five_hour" ? 300 : 10_080, "claude", kind)
        end
      else
        rejected << line.merge("reason" => "unknown_provider")
      end
    end
    known = accepted.select { |r| r["provider"] == "claude" && !r["account"].start_with?("unattributed:") }.map { |r| r["account"] }.uniq
    if known.length == 1
      (accepted + regimes).each do |r|
        next unless r["provider"] == "claude" && r["account"].start_with?("unattributed:")
        r["original_account"] = r["account"]
        r["account"] = known[0]
        r["account_source"] = "assumed_prior_cached_stream_same_as_single_named_scope"
      end
    end
    accepted = JS.sort_by(accepted) { |r| [r["t"]] }
    {accepted: accepted, rejected: rejected, regimes: regimes}
  end

  def normalize_requests(rows, samples, config = {}, now = JS.now_ms)
    accounts = {}
    samples.each { |s| (accounts[s["provider"]] ||= {})[s["account"]] = true }
    requests = []
    rejected = []
    upserts = {}
    duplicates = 0
    request_start = JS.nn(config["request_start"], 0)
    rows.each do |raw|
      t = JS.time(raw["t"])
      next if !JS.finite?(t) || t > now || t < request_start
      id = raw["id"]
      id = JS.join([raw["session"], t, raw["model"], raw["input"], raw["cache_read"], raw["output"]], "|") if id.nil?
      key = JS.join([raw["provider"], id], "|")
      old = upserts[key]
      if old
        duplicates += 1
        merged = old.merge(raw)
        merged["t"] = JS.max2(JS.time(old["t"]), t)
        (TOKEN_TYPES + ["input_total"]).each do |k|
          a = JS.token(old[k])
          b = JS.token(raw[k])
          merged[k] = a.nil? ? b : (b.nil? ? a : JS.max2(a, b))
        end
        %w[account model tier session].each do |k|
          merged[k] = old[k] if raw[k].nil? && (old.key?(k) || merged.key?(k))
        end
        upserts[key] = merged
      else
        upserts[key] = raw.dup
      end
    end
    upserts.each_value do |raw|
      unless %w[codex claude].include?(raw["provider"])
        rejected << line_of(raw).merge("reason" => "unknown_provider")
        next
      end
      account = raw["account"]
      account_source = JS.truthy(account) ? "request_metadata" : "unknown"
      observed = accounts[raw["provider"]] || {}
      if !JS.truthy(account) && observed.size == 1
        account = observed.keys[0]
        account_source = "assumed_single_observed_account"
      end
      tier = raw["tier"]
      r = raw.merge(
        "t" => JS.time(raw["t"]),
        "account" => JS.truthy(account) ? JS.str(account) : nil,
        "account_source" => account_source,
        "model" => raw["model"].is_a?(String) && !raw["model"].empty? ? raw["model"] : "unknown",
        "tier" => if tier == "priority" || tier == "fast" then "fast"
                  elsif tier == "default" || tier == "standard" then "standard"
                  else "unknown"
                  end,
      )
      TOKEN_TYPES.each { |k| r[k] = JS.token(raw[k]) }
      r["input_total"] = JS.token(raw["input_total"])
      r["nonreasoning_output"] = !r["output"].nil? && !r["reasoning"].nil? && r["reasoning"] <= r["output"] ? r["output"] - r["reasoning"] : nil
      r["invalid_token_fields"] = TOKEN_TYPES.select { |k| k != "nonreasoning_output" && !raw[k].nil? && r[k].nil? }
      r["invalid_token_fields"] << "reasoning_exceeds_output" if !r["reasoning"].nil? && !r["output"].nil? && r["reasoning"] > r["output"]
      requests << r
    end
    requests = JS.sort_by(requests) { |r| [r["t"]] }
    {requests: requests, rejected: rejected, duplicates: duplicates,
     provider_accounts: accounts.transform_values(&:keys)}
  end

  def rank(x)
    return 0 if x.empty? || x[0].empty?
    a = x.map(&:dup)
    cols = a[0].length
    rows = a.length
    j = 0
    while j < cols
      s = 0.0
      a.each { |r| s += r[j] * r[j] }
      scale = Math.sqrt(s)
      scale = 1 if scale.zero? || scale.nan?
      a.each { |r| r[j] /= scale }
      j += 1
    end
    k = 0
    j = 0
    while j < cols && k < rows
      best = k
      i = k + 1
      while i < rows
        best = i if a[i][j].abs > a[best][j].abs
        i += 1
      end
      if a[best][j].abs < 1e-8
        j += 1
        next
      end
      a[k], a[best] = a[best], a[k]
      v = a[k][j]
      z = j
      while z < cols
        a[k][z] /= v
        z += 1
      end
      i = k + 1
      while i < rows
        vi = a[i][j]
        z = j
        while z < cols
          a[i][z] -= vi * a[k][z]
          z += 1
        end
        i += 1
      end
      k += 1
      j += 1
    end
    k
  end

  def nnls(x, y)
    p = x.empty? ? 0 : x[0].length
    return {coefficients: Array.new(p, 0), converged: false} if x.empty?
    scale = Array.new(p, 0.0)
    x.each do |r|
      j = 0
      while j < p
        scale[j] += r[j] * r[j]
        j += 1
      end
    end
    scale.map! { |s| (q = Math.sqrt(s)).zero? || q.nan? ? 1 : q }
    g = Array.new(p) { Array.new(p, 0.0) }
    b = Array.new(p, 0.0)
    x.each_with_index do |r, i|
      yi = y[i]
      j = 0
      while j < p
        v = r[j] / scale[j]
        b[j] += v * yi
        gj = g[j]
        k = 0
        while k < p
          gj[k] += (v * r[k]) / scale[k]
          k += 1
        end
        j += 1
      end
    end
    c = Array.new(p, 0.0)
    converged = false
    z = 0
    while z < 10_000
      change = 0.0
      j = 0
      while j < p
        gj = g[j]
        if gj[j] < 1e-14
          j += 1
          next
        end
        nxt = b[j]
        k = 0
        while k < p
          nxt -= gj[k] * c[k] if j != k
          k += 1
        end
        nxt = JS.max2(0.0, nxt / gj[j])
        change = JS.max2(change, (nxt - c[j]).abs)
        c[j] = nxt
        j += 1
      end
      if change < 1e-9
        converged = true
        break
      end
      z += 1
    end
    {coefficients: c.each_with_index.map { |v, j| v / scale[j] }, converged: converged}
  end

  def quantile(a, q)
    return nil if a.empty?
    v = a.any? { |x| JS.nan?(x) } ? a.sort_by.with_index { |x, i| [JS.nan?(x) ? 1 : 0, JS.nan?(x) ? 0 : x, i] } : a.sort
    x = q * (v.length - 1)
    i = x.floor
    v[i] + (v[[i + 1, v.length - 1].min] - v[i]) * (x - i)
  end

  def gram_correlation(x)
    max = 0
    cols = x.empty? ? 0 : x[0].length
    (0...cols).each do |j|
      ((j + 1)...cols).each do |k|
        a = 0.0
        b = 0.0
        c = 0.0
        x.each do |r|
          a += r[j] * r[j]
          b += r[k] * r[k]
          c += r[j] * r[k]
        end
        max = JS.max2(max, c / Math.sqrt(a * b)) if JS.truthy(a) && JS.truthy(b)
      end
    end
    max
  end

  def fit_tokens(windows, types, config, split = false)
    present = types.select { |k| !windows.empty? && windows.all? { |w| w["fields"][k]["missing"].zero? } }
    positive = present.select { |k| windows.any? { |w| w["fields"][k]["sum"].positive? } }
    x = windows.map { |w| positive.map { |k| w["fields"][k]["sum"] / 1e6 } }
    y = windows.map { |w| w["delta_pp"] }
    days = windows.map { |w| w["bootstrap_block"] }.uniq
    r = rank(x)
    minimum_blocks = JS.nn(config["min_ci_blocks"], 4)
    fit = nnls(x, y)
    adequate = present.length == types.length && positive.length.positive? && r == positive.length &&
               windows.length > positive.length && days.length >= minimum_blocks && fit[:converged]
    draws = JS.nn(config["bootstrap_draws"], 500)
    bootstrap = []
    singular = 0
    seed = 431_071
    if adequate
      blocks = Hash.new { |h, k| h[k] = [] }
      windows.each_with_index { |w, i| blocks[w["bootstrap_block"]] << i }
      z = 0
      while z < draws
        indices = []
        days.length.times do
          seed = (seed * 1_664_525 + 1_013_904_223) & 0xFFFFFFFF
          indices.concat(blocks[days[((seed / 4_294_967_296.0) * days.length).floor]])
        end
        xx = indices.map { |i| x[i] }
        yy = indices.map { |i| y[i] }
        if rank(xx) < positive.length
          singular += 1
          bootstrap << nil
        else
          f = nnls(xx, yy)
          if f[:converged]
            bootstrap << f[:coefficients]
          else
            singular += 1
            bootstrap << nil
          end
        end
        z += 1
      end
    end
    common = {
      "n_windows" => windows.length,
      "n_requests" => JS.sum(windows) { |w| w["n_requests"] },
      "n_blocks" => days.length,
      "n_calendar_days" => windows.map { |w| w["day"] }.uniq.length,
      "bootstrap_block_minutes" => JS.nn(config["bootstrap_block_minutes"], 60),
      "n_positive_quota_windows" => windows.count { |w| w["delta_pp"].positive? },
      "design_rank" => r,
      "n_parameters" => positive.length,
      "max_column_cosine" => gram_correlation(x),
      "n_bootstrap" => bootstrap.length,
      "n_singular_bootstrap" => singular,
      "minimum_ci_blocks" => minimum_blocks,
      "output_split" => split,
    }
    coef = fit[:coefficients]
    rates = {}
    types.each do |k|
      exposure = JS.sum(windows) { |w| w["fields"][k]["sum"] }
      missing = JS.sum(windows) { |w| w["fields"][k]["missing"] }
      n_exposure = JS.sum(windows) { |w| w["fields"][k]["positive"] }
      j = positive.index(k) || -1
      cj = j >= 0 ? coef[j] : nil
      status = if windows.empty? then "no_pure_windows"
               elsif JS.truthy(missing) then "missing_field"
               elsif exposure <= 0 then "no_positive_exposure"
               elsif present.length < types.length then "incomplete_predictors"
               elsif r < positive.length then "rank_deficient"
               elsif y.none? { |v| v.positive? } then "unresolved_zero_quota_delta"
               elsif !adequate then "insufficient_windows_or_time_blocks"
               elsif singular.fdiv(draws) >= 0.025 then "bootstrap_rank_unstable"
               elsif cj <= 1e-12 then "zero_boundary"
               else "estimated"
               end
      estimate = nil
      ci = nil
      if status.start_with?("estimated")
        estimate = cj
        if status == "estimated"
          b = bootstrap.compact.map { |c| c[j] }
          ci = [quantile(b, 0.025), quantile(b, 0.975)]
        end
      end
      if !estimate.nil? && estimate <= 1e-12
        estimate = nil
        ci = nil
        status = "zero_boundary"
      end
      rates[k] = {
        "estimate_pp_per_million" => estimate,
        "ci95_pp_per_million" => ci,
        "status" => status,
        "diagnostic_nnls_pp_per_million" => cj,
        "n_positive_requests" => n_exposure,
        "exposure_tokens" => exposure,
        "n_missing_field_requests" => missing,
      }.merge(common)
    end
    ref = positive.index("input") || -1
    zero_reference = bootstrap.count { |b| b.nil? || ref.negative? || b[ref] <= 1e-12 }
    types.each do |k|
      j = positive.index(k) || -1
      status = if ref.negative? then "no_input_reference"
               elsif !adequate then "not_identifiable"
               elsif zero_reference.fdiv(bootstrap.empty? ? 1 : bootstrap.length) >= 0.025 then "unbounded_reference_at_zero"
               elsif rates[k]["status"] != "estimated" then "not_identifiable"
               else "estimated"
               end
      norm = {"ratio" => nil, "ci95" => nil, "status" => status, "n_zero_or_missing_reference_draws" => zero_reference}
      rates[k]["normalized_to_input"] = norm
      next unless status == "estimated"
      ratios = bootstrap.compact.map { |b| b[j] / b[ref] }
      norm["ratio"] = coef[j] / coef[ref]
      norm["ci95"] = [quantile(ratios, 0.025), quantile(ratios, 0.975)]
    end
    {rates: rates, diagnostics: common}
  end

  # Requests with provider and t in (lo, hi], in sorted order.
  def requests_between(requests, provider, lo, hi)
    first = requests.bsearch_index { |r| r["t"] > lo } || requests.length
    last = requests.bsearch_index { |r| r["t"] > hi } || requests.length
    requests[first...last].select { |r| r["provider"] == provider }
  end

  def analyze(request_rows, sample_rows, config = {}, now = JS.now_ms)
    timezone = JS.nn(config["timezone"], "America/Los_Angeles")
    midnight = JS.local_midnight(now, timezone)
    config = config.merge(
      "epoch_start" => JS.max2(JS.nn(config["epoch_start"], 0), midnight),
      "request_start" => JS.max2(JS.nn(config["request_start"], 0), midnight),
    )
    s = normalize_samples(sample_rows, config, now)
    q = normalize_requests(request_rows, s[:accepted], config, now)
    requests = q[:requests]
    step = JS.nn(config["fit_interval_minutes"], 10) * 60_000
    block_ms = JS.nn(config["bootstrap_block_minutes"], 60) * 60_000
    groups = []
    JS.sort_by(s[:accepted]) { |x| [x["reset"], x["t"]] }.each do |sample|
      identity = JS.join([sample["provider"], sample["account"], sample["kind"], sample["limit"], sample["slot"]], "|")
      g = groups.find { |c| c["identity"] == identity && (sample["reset"] - c["first_reset"]).abs <= 60_000 }
      unless g
        g = {"identity" => identity, "provider" => sample["provider"], "account" => sample["account"], "kind" => sample["kind"],
             "limit" => sample["limit"], "slot" => sample["slot"], "first_reset" => sample["reset"],
             "last_reset" => sample["reset"], "samples" => []}
        groups << g
      end
      g["last_reset"] = JS.max2(g["last_reset"], sample["reset"])
      g["samples"] << sample
    end
    pure = []
    observational = []
    contaminated = []
    excluded = []
    regime_history = []
    prior_regime = {}
    s[:regimes] = JS.sort_by(s[:regimes]) { |r| [r["t"]] }
    s[:regimes].each do |event|
      key = JS.join([event["provider"], event["account"]], "|")
      signature = JS.stringify(event["state"])
      old = prior_regime[key]
      next if old && old[:signature] == signature
      regime_history << event.merge("transition" => !old.nil?, "previous_state" => old && old[:state])
      prior_regime[key] = {signature: signature, state: event["state"]}
    end
    transitions = regime_history.select { |r| r["transition"] }
    groups.each do |g|
      grid = {}
      g["samples"] = JS.sort_by(g["samples"]) { |p| [p["t"]] }
      g["samples"].each { |p| grid[(p["t"].to_f / step).floor] = p }
      unique = {}
      ([g["samples"][0]] + grid.values).each { |p| unique[JS.key(p["t"])] = p }
      endpoints = JS.sort_by(unique.values) { |p| [p["t"]] }
      (1...endpoints.length).each do |i|
        a = endpoints[i - 1]
        b = endpoints[i]
        dt = b["t"] - a["t"]
        all = requests_between(requests, g["provider"], a["t"], b["t"])
        ambiguous = all.reject { |r| JS.truthy(r["account"]) }
        rows = all.select { |r| r["account"] == g["account"] }
        models = rows.map { |r| r["model"] }.uniq
        tiers = rows.map { |r| r["tier"] }.uniq
        day = JS.local_date(a["t"], timezone)
        source = ->(p) { {"source" => p["source"]}.merge(p.key?("source_line") ? {"line" => p["source_line"]} : {}).merge("t" => p["t"]) }
        w = {
          "id" => JS.join([g["identity"], g["first_reset"], a["t"], b["t"]], "|"),
          "provider" => g["provider"],
          "account" => g["account"],
          "quota" => g["kind"],
          "reset" => g["first_reset"],
          "regime_id" => a["regime_id"],
          "start" => a["t"],
          "end" => b["t"],
          "elapsed_ms" => dt,
          "start_percent" => a["percent"],
          "end_percent" => b["percent"],
          "delta_pp" => b["percent"] - a["percent"],
          "day" => day,
          "bootstrap_block" => day + "|" + JS.str(a["regime_id"]) + "|" +
            ((a["t"] - JS.local_midnight(a["t"], timezone)).to_f / block_ms).floor.to_s,
          "n_requests" => rows.length,
          "n_ambiguous_requests" => ambiguous.length,
          "n_assumed_account_requests" => rows.count { |r| r["account_source"].start_with?("assumed") },
          "models" => models,
          "tiers" => tiers,
          "source_start" => source.call(a),
          "source_end" => source.call(b),
          "fields" => TOKEN_TYPES.to_h do |k|
            sum = 0
            missing = 0
            positive = 0
            rows.each do |r|
              v = r[k]
              if v.nil?
                missing += 1
              else
                sum += v
                positive += 1 if v.positive?
              end
            end
            [k, {"sum" => sum, "missing" => missing, "positive" => positive}]
          end,
          "n_over_272k" => rows.count { |r| !r["input_total"].nil? && r["input_total"] > 272_000 },
          "n_missing_input_total" => rows.count { |r| r["input_total"].nil? },
        }
        defects = []
        defects << "ambiguous_account" unless ambiguous.empty?
        defects << "mixed_model" if models.length > 1
        defects << "unknown_model" if models.include?("unknown")
        defects << "mixed_tier" if tiers.length > 1
        defects << "unknown_tier" if g["provider"] == "codex" && tiers.include?("unknown")
        if transitions.any? { |r| r["provider"] == g["provider"] && r["account"] == g["account"] && r["t"] > a["t"] && r["t"] <= b["t"] }
          defects << "regime_change"
        end
        defects << "invalid_token_fields" if rows.any? { |r| !r["invalid_token_fields"].empty? }
        reason = if dt < step * 0.25 || dt > step * 2.5 then "sample_gap"
                 elsif a["percent"] >= 100 || b["percent"] >= 100 then "saturated_endpoint"
                 elsif b["percent"] < a["percent"] then "decreasing_raw_quota"
                 elsif rows.empty? then JS.truthy(w["delta_pp"]) ? "unattributed_quota_increase" : "no_requests"
                 end
        if reason.nil? && !rows.empty? && models.length == 1 && defects.all? { |d| %w[unknown_tier mixed_tier].include?(d) }
          observational << w.merge("model" => models[0], "tier" => "pooled_speed_uncertain", "speed_uncertainty" => true)
        end
        unless defects.empty?
          contaminated << w.merge("reasons" => defects, "exclusion_reason" => reason)
          next
        end
        if reason
          excluded << w.merge("reason" => reason)
          next
        end
        pure << w.merge("model" => models[0], "tier" => tiers[0])
      end
    end
    identities = {}
    requests.each do |r|
      key = JS.join([r["provider"], JS.nn(r["account"], "unattributed"), r["model"], r["tier"]], "|")
      identities[key] ||= {"provider" => r["provider"], "account" => r["account"], "model" => r["model"], "tier" => r["tier"]}
    end
    (config["cohort"] || []).each do |r|
      next unless JS.truthy(r["model"])
      provider = JS.nn(r["provider"], "codex")
      next if requests.any? { |x| x["provider"] == provider && x["model"] == r["model"] }
      identities[JS.join([provider, "unattributed", r["model"], "standard"], "|")] =
        {"provider" => provider, "account" => nil, "model" => r["model"], "tier" => "standard"}
    end
    make_cards = lambda do |identity_map, window_set, scope|
      cards = []
      identity_map.each_value do |identity|
        quotas = s[:accepted].select { |x| x["provider"] == identity["provider"] && (!JS.truthy(identity["account"]) || x["account"] == identity["account"]) }
                             .map { |x| x["kind"] }.uniq
        quotas << "seven_day" if quotas.empty?
        observed_requests = requests.select do |r|
          r["provider"] == identity["provider"] && r["model"] == identity["model"] && r["account"] == identity["account"] &&
            (scope == "model_only_observational" || r["tier"] == identity["tier"])
        end
        quotas.each do |quota|
          eligible = window_set.select do |w|
            w["provider"] == identity["provider"] && w["account"] == identity["account"] && w["model"] == identity["model"] &&
              w["tier"] == identity["tier"] && w["quota"] == quota
          end
          regimes = eligible.map { |w| w["regime_id"] }.uniq
          current_state = prior_regime[JS.join([identity["provider"], identity["account"]], "|")]&.dig(:state)
          current_regime = current_state ? JS.digest(current_state)[0, 12] : nil
          regimes << current_regime if regimes.empty?
          first_snapshot = JS.min_of(s[:accepted].select { |x| x["provider"] == identity["provider"] && x["account"] == identity["account"] && x["kind"] == quota }.map { |x| x["t"] })
          regimes.each do |regime|
            ww = eligible.select { |w| w["regime_id"] == regime }
            use_ttl = identity["provider"] == "claude" &&
                      ww.any? { |w| w["fields"]["cache_write_5m"]["sum"].positive? || w["fields"]["cache_write_1h"]["sum"].positive? }
            writes = use_ttl ? %w[cache_write_5m cache_write_1h] : %w[cache_write]
            fit_card = identity.merge("quota" => quota, "regime_id" => regime, "scope" => scope)
            fitter = config["token_fitter"]
            base = fitter ? fitter.call(ww, ["input", "cache_read", *writes, "output"], config, fit_card, false) : fit_tokens(ww, ["input", "cache_read", *writes, "output"], config)
            split = fitter ? fitter.call(ww, ["input", "cache_read", *writes, "nonreasoning_output", "reasoning"], config, fit_card, true) : fit_tokens(ww, ["input", "cache_read", *writes, "nonreasoning_output", "reasoning"], config, true)
            rates = base[:rates].merge("reasoning" => split[:rates]["reasoning"], "nonreasoning_output" => split[:rates]["nonreasoning_output"])
            TOKEN_TYPES.each do |k|
              next if rates[k]
              rates[k] = {
                "estimate_pp_per_million" => nil,
                "ci95_pp_per_million" => nil,
                "status" => use_ttl && k == "cache_write" ? "partitioned_into_ttl_rates" : "not_in_pooled_fit",
                "n_windows" => ww.length,
                "n_requests" => base[:diagnostics]["n_requests"],
                "n_positive_requests" => JS.sum(ww) { |w| w["fields"][k]["positive"] },
                "exposure_tokens" => JS.sum(ww) { |w| w["fields"][k]["sum"] },
                "n_missing_field_requests" => JS.sum(ww) { |w| w["fields"][k]["missing"] },
              }
            end
            cards << identity.merge(
              "quota" => quota,
              "regime_id" => regime,
              "current_regime" => regime == current_regime,
              "scope" => scope,
              "speed_uncertainty" => scope == "model_only_observational",
              "rates" => rates,
              "pooled_fit" => base[:diagnostics],
              "reasoning_split_fit" => split[:diagnostics],
              "n_observed_requests" => observed_requests.length,
              "n_prebaseline_requests" => observed_requests.count { |r| r["t"] < first_snapshot },
              "n_assumed_account_requests" => JS.sum(ww) { |w| w["n_assumed_account_requests"] },
              "n_contaminated_windows" => contaminated.count do |w|
                w["provider"] == identity["provider"] && w["account"] == identity["account"] && w["quota"] == quota &&
                  w["models"].include?(identity["model"])
              end,
            )
          end
        end
      end
      JS.sort_by(cards) { |c| JS.collation_key(JS.join([c["provider"], c["model"], c["account"], c["tier"], c["quota"]], "|")) }
    end
    cards = make_cards.call(identities, pure, "same_model_reported_tier")
    observational_identities = {}
    requests.each do |r|
      observational_identities[JS.join([r["provider"], r["account"], r["model"]], "|")] =
        {"provider" => r["provider"], "account" => r["account"], "model" => r["model"], "tier" => "pooled_speed_uncertain"}
    end
    observational_cards = make_cards.call(observational_identities, observational, "model_only_observational")
    {
      "schema_version" => 1,
      "generated_at" => JS.iso(now),
      "timezone" => timezone,
      "period" => {
        "label" => "current_local_day",
        "date" => JS.local_date(now, timezone),
        "start" => config["epoch_start"],
        "local_midnight" => midnight,
        "end" => now,
      },
      "units" => "percentage_points_per_million_tokens",
      "coverage" => "all_observed_local_requests; account-wide off-machine usage is unobserved",
      "config" => {
        "epoch_start" => config["epoch_start"],
        "fit_interval_minutes" => step.fdiv(60_000),
        "bootstrap_draws" => JS.nn(config["bootstrap_draws"], 500),
        "min_ci_blocks" => JS.nn(config["min_ci_blocks"], 4),
        "bootstrap_block_minutes" => JS.nn(config["bootstrap_block_minutes"], 60),
        "max_sample_age_ms" => JS.nn(config["max_sample_age_ms"], 300_000),
      },
      "input_summary" => {
        "n_request_records" => request_rows.length,
        "n_unique_requests" => requests.length,
        "n_duplicate_requests" => q[:duplicates],
        "n_raw_sample_records" => sample_rows.length,
        "n_normalized_snapshots" => s[:accepted].length,
        "provider_accounts" => q[:provider_accounts],
        "n_assumed_account_requests" => requests.count { |r| r["account_source"].start_with?("assumed") },
        "n_ambiguous_account_requests" => requests.count { |r| !JS.truthy(r["account"]) },
      },
      "regime_history" => regime_history,
      "cards" => cards,
      "observational_cards" => observational_cards,
      "pure_windows" => pure,
      "observational_windows" => observational,
      "contaminated_windows" => contaminated,
      "excluded_windows" => excluded,
      "rejected_samples" => s[:rejected],
      "rejected_requests" => q[:rejected],
      "limitations" => [
        "Strict Codex windows require one model and one reported tier. Claude unreported tier remains unknown. Model-only observational fits pool speeds and are not controlled. No local ledger proves complete account usage.",
        "Unknown request account is assigned only when one provider account is observed and remains explicitly assumed.",
        "Raw snapshot deltas are used without monotone smoothing; decreasing and capped windows are excluded.",
        "Reasoning remains included in the pooled output fit; its separate rate uses a distinct potentially unidentifiable split fit.",
        "Reported zero fields can be client defaults; no positive exposure is NA.",
        "Confidence intervals resample contiguous within-day time blocks; local dates and observed regimes bound blocks. They omit unobserved usage and quota-update error.",
      ],
    }
  end

  def short_rate(r)
    return "NA" if r["estimate_pp_per_million"].nil?
    ci = r["ci95_pp_per_million"]
    "#{JS.to_precision(r["estimate_pp_per_million"], 4)}[#{ci ? ci.map { |v| JS.to_precision(v, 3) }.join(",") : "NA"}]"
  end

  ALIASES = {"input" => "in", "cache_read" => "cr", "cache_write" => "cw", "cache_write_5m" => "cw5m", "cache_write_1h" => "cw1h",
             "output" => "out", "reasoning" => "reason", "nonreasoning_output" => "nonreason"}.freeze

  def cell(card)
    rates = TOKEN_TYPES.map { |k| "#{ALIASES[k]}=#{short_rate(card["rates"][k])}" }.join(" ")
    fit = card["pooled_fit"]
    "#{JS.nn(card["regime_id"], "unobserved_regime")} #{card["scope"] == "model_only_observational" ? "OBS_SPEED_UNCERTAIN " : "STRICT "}" \
      "#{JS.str(card["provider"])}/#{JS.str(card["model"])}/#{JS.str(card["tier"])}/#{JS.str(card["quota"])}/#{JS.str(JS.nn(card["account"], "unattributed"))}: " \
      "#{rates} n=#{JS.str(fit["n_windows"])}/#{JS.str(fit["n_requests"])}/#{JS.str(fit["n_blocks"])} assumed=#{JS.str(card["n_assumed_account_requests"])}"
  end

  def daily_document(result)
    period = result["period"]
    head = "# Rates\n\n| Generated UTC | Los Angeles date | Start UTC | End UTC |\n| --- | --- | --- | --- |\n| " +
           JS.str(result["generated_at"]) + " | " + JS.str(period["date"]) + " | " + JS.iso(period["start"]) + " | " + JS.iso(period["end"]) + " |\n\n"
    cols = "| Provider | Model | Scope | Tier | Quota | Token type | Rate pp/M | NNLS comparison pp/M | NNLS result | NNLS snapshot UTC | 95% CI lower | 95% CI upper | Result | n windows | n requests | n time blocks |\n" \
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |\n"
    rows = (result["cards"] + result["observational_cards"]).flat_map do |c|
      TOKEN_TYPES.map do |k|
        r = c["rates"][k]
        ci = r["ci95_pp_per_million"]
        rate = r["estimate_pp_per_million"].nil? ? "NA" : JS.to_precision(r["estimate_pp_per_million"], 5)
        fit = c["pooled_fit"]
        "| " + JS.join([c["provider"], c["model"], c["scope"], c["tier"], c["quota"], k, rate,
                        r["diagnostic_nnls_pp_per_million"].nil? ? "NA" : JS.to_precision(r["diagnostic_nnls_pp_per_million"], 5),
                        r["nnls_status"] || r["status"], r["nnls_snapshot_at"] || result["generated_at"],
                        ci ? JS.to_precision(ci[0], 5) : "NA", ci ? JS.to_precision(ci[1], 5) : "NA", r["status"],
                        fit["n_windows"], fit["n_requests"], fit["n_blocks"]], " | ") + " |"
      end
    end.join("\n")
    head + cols + rows + "\n"
  end

  def atomic(file, text)
    FileUtils.mkdir_p(File.dirname(file))
    tmp = "#{file}.#{Process.pid}.tmp"
    File.write(tmp, text)
    File.rename(tmp, file)
  end

  # DAILY.md for every refresh.
  def publish_readable(base, result)
    file = File.join(base, "live/DAILY.md")
    atomic(file, daily_document(result))
    {"status" => "published", "path" => file}
  end

  # Nightly rate card row, status JSON and frozen snapshot, written directly.
  def publish_daily(base:, result:, now:, date:, status_path:)
    live = File.join(base, "live")
    receipt_path = File.join(live, "receipts", "#{date}.json")
    snapshot_path = File.join(live, "daily", "#{date}.json")
    card_path = File.join(base, "RATECARD.md")
    frozen = File.exist?(snapshot_path) ? JSON.parse(File.read(snapshot_path)) : result
    marker = "| #{date} |"
    text = if File.exist?(card_path)
             File.read(card_path)
           else
             "# Rate card\n\n| Los Angeles date | Generated UTC | Rates pp/M, 95% CI, n windows/requests/blocks |\n| --- | --- | --- |\n"
           end
    unless text.split("\n").any? { |r| r.start_with?(marker) }
      row = "#{marker} #{frozen["generated_at"]} | " + (frozen["cards"] + frozen["observational_cards"]).map { |c| cell(c) }.join("; ").tr("|", "/") + " |"
      text += (text.end_with?("\n") ? "" : "\n") + row + "\n"
    end
    select = lambda do |cards|
      cards.select { |c| c["provider"] == "codex" && c["model"] == "gpt-6.1-sol" && c["quota"] == "seven_day" }.map do |c|
        {"scope" => c["scope"], "tier" => c["tier"], "quota" => c["quota"], "rates" => c["rates"],
         "n_windows" => c["pooled_fit"]["n_windows"], "n_requests" => c["pooled_fit"]["n_requests"], "n_time_blocks" => c["pooled_fit"]["n_blocks"]}
      end
    end
    section = {
      "schema_version" => 1, "role" => "rates", "state" => "daily_card_published", "date" => date,
      "generated_at" => frozen["generated_at"], "messaging" => false,
      "strict_sol61" => select.call(frozen["cards"]), "observational_sol61" => select.call(frozen["observational_cards"]),
      "card_path" => card_path, "snapshot_path" => snapshot_path, "details_path" => File.join(live, "DAILY.md"),
      "completion_path" => receipt_path
    }
    atomic(File.join(live, "DAILY.md"), daily_document(frozen))
    atomic(card_path, text)
    atomic(status_path, JS.stringify(section, 2) + "\n")
    atomic(snapshot_path, JS.stringify(frozen, 2)) unless File.exist?(snapshot_path)
    receipt = {"date" => date, "state" => "published", "published_at" => JS.iso(now), "messaging" => false,
               "card_sha256" => JS.sha256(text), "status_path" => status_path}
    atomic(receipt_path, JS.stringify(receipt, 2))
    receipt
  end

  def persist_daily(base, result, now: JS.now_ms, status_path: File.join(base, "live/status-section.json"), publisher: nil)
    parts = JS.local_parts(now, result["timezone"])
    return {"status" => "not_due", "date" => parts[:date], "local_hour" => parts[:hour], "messaging" => false} if parts[:hour] < 21
    publisher ||= ->(**kw) { publish_daily(**kw) }
    publisher.call(base: base, result: result, now: now, date: parts[:date], status_path: status_path)
  end

  # remote/compute.mjs reader: blank and unparsable lines are dropped, no line numbers.
  def read_rows(file)
    rows = []
    File.foreach(file, chomp: true) do |l|
      next if l.empty?
      v = begin
        JSON.parse(l)
      rescue JSON::ParserError, EncodingError
        nil
      end
      next unless JS.truthy(v)
      rows << (v.is_a?(Hash) ? v : {})
    end
    rows
  end

  def analyze_root(root, cutoff, token_fitter: nil)
    config = JSON.parse(File.read(File.join(root, "live/config.json")))
    config = config.merge("token_fitter" => token_fitter) if token_fitter
    analyze(read_rows(File.join(root, "live/requests.jsonl")), read_rows(File.join(root, "live/samples.jsonl")), config, cutoff)
  end

  def check(condition, label)
    raise "self-test failed: #{label}" unless condition
  end

  def self_test
    cfg = {"epoch_start" => 0, "timezone" => "America/Los_Angeles", "bootstrap_draws" => 100, "min_ci_blocks" => 4,
           "fit_interval_minutes" => 10, "bootstrap_block_minutes" => 60}
    req = []
    samples = []
    start = JS.date_parse("2026-09-01T08:00:00Z")
    reset = start + 30 * 86_400_000
    percent = 0
    expected = [0.2, 0.02, 0.25, 1]
    quota = lambda do |p|
      {"rateLimits" => {"limitId" => "codex", "primary" => {"usedPercent" => p, "windowDurationMins" => 10_080, "resetsAt" => reset / 1000.0}},
       "accountId" => "A"}
    end
    8.times do |day|
      t = start + day * 86_400_000
      samples << {"provider" => "codex", "t" => t, "account" => "A", "rate_limits" => quota.call(percent)}
      36.times do |j|
        values = [(j + 1) * 10_000, (j * j + day + 1) * 10_000, (((j + day) % 5) + 1) * 10_000, (((j * 3 + day) % 7) + 1) * 10_000]
        percent += values.each_with_index.reduce(0) { |s, (v, k)| s + (v * expected[k]) / 1e6 }
        req << {"provider" => "codex", "t" => t + (j + 1) * 600_000 - 1000, "id" => "#{day}-#{j}", "session" => "S", "account" => "A",
                "model" => "gpt-6.1-sol", "tier" => "default", "input" => values[0], "cache_read" => values[1],
                "cache_write" => values[2], "output" => values[3], "reasoning" => nil, "input_total" => values[0] + values[1] + values[2]}
        samples << {"provider" => "codex", "t" => t + (j + 1) * 600_000, "account" => "A", "rate_limits" => quota.call(percent)}
      end
    end
    now = start + 7 * 86_400_000 + 8 * 3_600_000
    current = req.find { |x| x["t"] >= start + 7 * 86_400_000 }
    current_sample = samples.find { |x| JS.time(x["t"]) >= start + 7 * 86_400_000 }
    r = analyze(req, samples, cfg, now)
    check(r["cards"].length == 1, "one card")
    check(r["contaminated_windows"].empty?, "no contamination")
    %w[input cache_read cache_write output].each_with_index do |k, j|
      check(r["cards"][0]["rates"][k]["status"] == "estimated", "#{k} estimated")
      check((r["cards"][0]["rates"][k]["estimate_pp_per_million"] - expected[j]).abs < 1e-5, "#{k} recovered")
    end
    check(r["cards"][0]["rates"]["reasoning"]["status"] == "missing_field", "reasoning missing")
    contaminated = analyze(req + [current.merge("id" => "other", "model" => "gpt-6-luna")], samples, cfg, now)
    check(contaminated["contaminated_windows"].any? { |w| w["reasons"].include?("mixed_model") }, "mixed model")
    absent = analyze(req.map { |x| x.merge("cache_write" => 0) }, samples, cfg, now)
    check(absent["cards"][0]["rates"]["cache_write"]["status"] == "no_positive_exposure", "zero exposure")
    bumped = current.merge("output" => current["output"] + 100)
    duplicate = analyze(req + [bumped], samples, cfg, now)
    check(duplicate["input_summary"]["n_duplicate_requests"] == 1, "duplicate counted")
    deduped = normalize_requests(req + [bumped], normalize_samples(samples, cfg, now)[:accepted], cfg, now)
    check(deduped[:requests].find { |x| x["id"] == current["id"] }["output"] == current["output"] + 100, "dedup keeps max")
    same_day_samples = samples.select { |x| JS.time(x["t"]) < start + 86_400_000 }.map do |x|
      i = ((JS.time(x["t"]) - start) / 600_000.0).round
      noise = i.zero? ? 0 : Math.sin(i * 1.31) * 0.0003
      primary = x["rate_limits"]["rateLimits"]["primary"]
      x.merge("rate_limits" => x["rate_limits"].merge("rateLimits" => x["rate_limits"]["rateLimits"].merge(
        "primary" => primary.merge("usedPercent" => primary["usedPercent"] + noise),
      )))
    end
    same_day = analyze(req.select { |x| x["t"] < start + 86_400_000 }, same_day_samples,
                       cfg.merge("min_ci_blocks" => 4, "bootstrap_block_minutes" => 60), start + 8 * 3_600_000)
    sd = same_day["cards"][0]
    check(sd["pooled_fit"]["n_calendar_days"] == 1, "same day")
    %w[input cache_read cache_write output].each { |k| check(!sd["rates"][k]["estimate_pp_per_million"].nil?, "same day #{k}") }
    ci = sd["rates"]["input"]["ci95_pp_per_million"]
    check(ci, "same day ci")
    check((sd["rates"]["input"]["estimate_pp_per_million"] - 0.2).abs < 0.02, "same day input")
    check(ci[0] <= 0.2 && ci[1] >= 0.2, "same day ci covers")
    zero = analyze(req, samples.map do |x|
      x.merge("rate_limits" => x["rate_limits"].merge("rateLimits" => x["rate_limits"]["rateLimits"].merge(
        "primary" => x["rate_limits"]["rateLimits"]["primary"].merge("usedPercent" => 0),
      )))
    end, cfg, now)
    check(zero["cards"][0]["rates"]["input"]["status"] == "unresolved_zero_quota_delta", "zero quota")
    ambiguous = analyze(req.map { |x| x.merge("account" => nil) }, samples + [current_sample.merge("account" => "B")], cfg, now)
    check(ambiguous["contaminated_windows"].any? { |w| w["reasons"].include?("ambiguous_account") }, "ambiguous account")
    early = persist_daily("/unused", r, now: JS.date_parse("2026-09-12T03:59:00Z"))
    check(early["status"] == "not_due", "21h gate")
    Dir.mktmpdir("live-fit-selftest-") do |temp|
      publications = 0
      status_path = File.join(temp, "live/status-section.json")
      publisher = lambda do |base:, result:, date:, status_path:, **|
        publications += 1
        card = File.join(base, "RATECARD.md")
        File.write(card, "| #{date} | #{result["generated_at"]} | NA |\n") unless File.exist?(card)
        FileUtils.mkdir_p(File.dirname(status_path))
        File.write(status_path, JSON.generate({"date" => date, "messaging" => false}))
        {"status" => "published", "messaging" => false}
      end
      persist_daily(temp, r, now: JS.date_parse("2026-09-12T04:00:00Z"), status_path: status_path, publisher: publisher)
      check(publications == 1, "one publication")
      check(JSON.parse(File.read(status_path))["messaging"] == false, "no messaging")
      check(File.read(File.join(temp, "RATECARD.md")).split("\n").count { |l| l.start_with?("| 2026-09-11 |") } == 1, "one card row")
      # The real publisher appends once per date and writes the status JSON.
      publish_daily(base: temp, result: r, now: JS.date_parse("2026-09-12T04:00:00Z"), date: "2026-09-12", status_path: status_path)
      publish_daily(base: temp, result: r, now: JS.date_parse("2026-09-12T04:05:00Z"), date: "2026-09-12", status_path: status_path)
      check(File.read(File.join(temp, "RATECARD.md")).split("\n").count { |l| l.start_with?("| 2026-09-12 |") } == 1, "daily idempotent")
      check(JSON.parse(File.read(status_path))["state"] == "daily_card_published", "status written")
    end
    puts JS.stringify({
      "status" => "PASS",
      "same_day_proof" => {
        "n_windows" => sd["pooled_fit"]["n_windows"], "n_blocks" => sd["pooled_fit"]["n_blocks"], "n_calendar_days" => 1,
        "fixture" => "synthetic noisy same-day, not live workload",
        "input_rate" => sd["rates"]["input"]["estimate_pp_per_million"], "ci95" => ci, "expected_input_rate" => 0.2
      },
      "checks" => %w[known_rate_recovery mixed_model_is_separate zero_exposure_is_NA missing_reasoning_is_NA request_dedup_latest_max
                     same_day_recovery zero_quota_is_unresolved multi_account_ambiguity LA_21h_gate
                     daily_card_and_local_status_idempotency no_messaging],
    })
  end
end

if $PROGRAM_NAME == __FILE__
  case ARGV[0]
  when "--self-test"
    Rates.self_test
  when "--analyze"
    # live-fit.rb --analyze ROOT CUTOFF_MS OUT: fit ROOT/live inputs as of CUTOFF_MS.
    root, cutoff, out = ARGV[1], Integer(ARGV[2]), ARGV[3]
    result = Rates.analyze_root(root, cutoff)
    Rates.atomic(out, Rates::JS.stringify(result))
    puts Rates::JS.stringify({"cutoff" => cutoff, "cards" => result["cards"].length, "requests" => result["input_summary"]["n_unique_requests"]})
  else
    warn "usage: live-fit.rb --self-test | --analyze ROOT CUTOFF_MS OUT"
    exit 2
  end
end
