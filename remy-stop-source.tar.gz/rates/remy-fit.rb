#!/usr/bin/env ruby
# frozen_string_literal: true

require "json"
require "fileutils"
require "digest"
require "open3"
require "shellwords"
require "time"

module Rates
  module RemyFit
    ISSUE = "https://github.com/nm-z/recipe-dev/issues/994"
    ROOT = ENV.fetch("REMY_RECIPE_ROOT", "/home/nate/work/recipe-dev-remy-first")
    IDENTITY = %w[provider account model tier quota regime_id scope].freeze
    module_function

    def preflight!
      manifest = File.read(File.join(ROOT, "Cargo.toml"))
      amd = manifest.lines.select { |line| line.start_with?("hsa-", "amd-", "amdgpu-") }.join
      if amd.match?(%r{/opt/rocm|libhsa-runtime|ocml\.bc|ockl\.bc})
        raise "recipe AMD backend requires ROCm; system LLVM GPU fitting is blocked by #{ISSUE}"
      end
      compiler = amd[/^(?:hsa|amd|amdgpu)-compiler\s*=\s*\{\s*linux\s*=\s*"([^"]+)"/, 1]
      linker = amd[/^(?:hsa|amd|amdgpu)-linker\s*=\s*\{\s*linux\s*=\s*"([^"]+)"/, 1]
      raise "recipe AMD compiler is not the required /usr/bin/clang" unless compiler == "/usr/bin/clang"
      raise "recipe AMD linker is not the required /usr/bin/ld.lld" if linker && linker != "/usr/bin/ld.lld"
      executable = File.join(ROOT, "target/release/recipe")
      raise "recipe executable is missing: #{executable}" unless File.executable?(executable)
      binary = File.binread(executable)
      if binary.include?("/opt/rocm/") || binary.include?("libhsa-runtime64")
        raise "recipe executable embeds a ROCm compiler or runtime dependency; rebuild the compliant backend"
      end
      %w[/usr/bin/clang /usr/bin/ld.lld].each { |p| raise "system LLVM tool missing: #{p}" unless File.executable?(p) }
      properties = File.read("/sys/class/kfd/kfd/topology/nodes/1/properties")
      raise "expected gfx1101 on engi" unless properties.match?(/^gfx_target_version 110001$/)
      raise "expected RX 7700 XT renderD128" unless File.read("/sys/class/drm/renderD128/device/vendor").strip == "0x1002" && File.read("/sys/class/drm/renderD128/device/device").strip == "0x747e"
      issue_output, _, issue_status = Open3.capture3("/usr/bin/timeout", "15", "gh", "issue", "view", "994", "--repo", "nm-z/recipe-dev", "--json", "state,closedAt,url")
      raise "recipe issue gate could not be read" unless issue_status.success?
      issue = JSON.parse(issue_output)
      raise "GPU fits remain queued until #{ISSUE} lands" unless issue["state"] == "CLOSED"
      {"node" => "engi", "device" => "amd0", "gfx" => "gfx1101", "pci" => File.basename(File.realpath("/sys/class/drm/renderD128/device")), "recipe" => executable,
       "recipe_sha256" => Digest::SHA256.hexdigest(binary), "recipe_issue" => issue}
    end

    def key(card) = IDENTITY.map { |k| card[k] }

    class Engine
      def initialize(base)
        @base = base
        @backend = RemyFit.preflight!
        @gpu_lock = File.open("/home/nate/ceo-orders/rates/live/.gpu-fit.lock", "w")
        unless @gpu_lock.flock(File::LOCK_EX | File::LOCK_NB)
          @gpu_lock.close
          raise "another Remy GPU fitter is running"
        end
        prior = File.join(base, "live/latest.json")
        snapshot = File.exist?(prior) ? JSON.parse(File.read(prior)) : {}
        @prior = [*snapshot["cards"], *snapshot["observational_cards"]].to_h { |c| [RemyFit.key(c), c] }
        @snapshot_at = snapshot["generated_at"]
        @run = File.join(base, "live/remy", Time.now.utc.strftime("%Y%m%dT%H%M%S") + "-#{Process.pid}")
        FileUtils.mkdir_p(@run)
        @sequence = 0
        @deadline = Process.clock_gettime(Process::CLOCK_MONOTONIC) + 180
      end

      def fit(windows, types, config, card, split)
        @sequence += 1
        folder = File.join(@run, format("fit-%02d", @sequence))
        FileUtils.mkdir_p(folder)
        prior = @prior[RemyFit.key(card)]
        available = types.select { |k| !windows.empty? && windows.all? { |w| w.fetch("fields").fetch(k).fetch("missing").zero? } }
        exposed = available.select { |k| windows.any? { |w| w["fields"][k]["sum"].positive? } }
        complete = available.length == types.length
        common = {"n_windows" => windows.length, "n_requests" => windows.sum { |w| w["n_requests"] },
                  "n_blocks" => windows.map { |w| w["bootstrap_block"] }.uniq.length,
                  "n_calendar_days" => windows.map { |w| w["day"] }.uniq.length,
                  "n_parameters" => exposed.length, "output_split" => split, "method" => "remy_recipe_gpu",
                  "n_bootstrap" => 0, "ci_method" => "not measured", "nnls_snapshot_at" => prior&.dig("pooled_fit", "nnls_snapshot_at") || @snapshot_at}
        result = nil
        if complete && !exposed.empty?
          problem = prepare(folder, windows, exposed, prior)
          result = execute(folder, problem)
          common["remy_execution"] = result.fetch("proof")
          common["objective"] = result.fetch("objective")
          common["fit_rmse_pp"] = result.fetch("rmse_pp")
        end
        rates = types.to_h do |k|
          old = prior&.dig("rates", k)
          status = if windows.empty? then "no_pure_windows"
                   elsif !available.include?(k) then "missing_field"
                   elsif !exposed.include?(k) then "no_positive_exposure"
                   elsif !complete then "incomplete_predictors"
                   else "remy_regularized_prediction"
                   end
          estimate = status == "remy_regularized_prediction" ? result.fetch("rates").fetch(k) : nil
          r = {"estimate_pp_per_million" => estimate, "ci95_pp_per_million" => nil, "status" => status,
               "diagnostic_nnls_pp_per_million" => old&.dig("diagnostic_nnls_pp_per_million"),
               "nnls_status" => old&.dig("nnls_status") || old&.dig("status") || "not measured", "nnls_snapshot_at" => old&.dig("nnls_snapshot_at") || @snapshot_at,
               "normalized_to_input" => {"ratio" => nil, "ci95" => nil, "status" => "not measured"},
               "n_positive_requests" => windows.sum { |w| w["fields"][k]["positive"] },
               "exposure_tokens" => windows.sum { |w| w["fields"][k]["sum"] },
               "n_missing_field_requests" => windows.sum { |w| w["fields"][k]["missing"] }}.merge(common)
          [k, r]
        end
        {rates: rates, diagnostics: common}
      end

      def prepare(folder, windows, types, prior)
        y = windows.map { |w| w.fetch("delta_pp").to_f }
        x = windows.map { |w| types.map { |k| w["fields"][k]["sum"].to_f / 1e6 } }
        quota_scale = [y.sum.fdiv(y.length), 0.01].max
        centers = types.map { |k| prior&.dig("rates", k, "diagnostic_nnls_pp_per_million") || 0.0 }
        spans = types.each_index.map do |j|
          exposure = x.sum { |row| row[j] }.fdiv(x.length)
          2.0 * [centers[j].abs, quota_scale / exposure, 1e-6].max
        end
        problem = {"types" => types, "x" => x, "y" => y, "centers" => centers, "spans" => spans,
                   "quota_scale" => quota_scale, "prior_weight" => 1e-4,
                   "prior" => "retained NNLS diagnostic, with signed ranges; zero center when unavailable"}
        File.write(File.join(folder, "problem.json"), JSON.pretty_generate(problem) + "\n")
        positions = (0..20).map { |i| format("%.17g", i / 20.0) }.join(",")
        knobs = types.each_with_index.map do |k, j|
          points = (0..20).map { |i| format("%.17g", centers[j] + spans[j] * (i / 10.0 - 1.0)) }.join("|")
          [k, 1, -1, "", positions, points, 10].join("\t")
        end
        File.write(File.join(folder, "knobs.tsv"), knobs.join("\n") + "\n")
        File.write(File.join(folder, "context.csv"), "context\n1\n")
        command = ["/usr/bin/ruby", File.join(@base, "remy-fit.rb"), "--evaluate", File.join(folder, "problem.json")]
        adapter = File.join(folder, "objective.sh")
        File.write(adapter, "#!/bin/bash\nexec #{command.map { |s| Shellwords.escape(s) }.join(' ')}\n")
        File.chmod(0o700, adapter)
        problem
      end

      def execute(folder, problem, script: File.join(@base, "remy-fit.rs"), scorer: RemyFit.method(:objective), allow_invalid: false)
        raise "Remy rates refresh exceeded its 180-second total limit" if Process.clock_gettime(Process::CLOCK_MONOTONIC) >= @deadline
        command = ["/usr/bin/nice", "-n", "19", @backend.fetch("recipe"), "run", script, "--device", "amd0", "--", folder]
        environment = {"RECIPE_DEVICE" => "amd0", "REMY_RATE_EPOCHS" => "23"}
        output = File.join(folder, "recipe.log")
        error = File.join(folder, "recipe.err")
        start = Process.clock_gettime(Process::CLOCK_MONOTONIC)
        samples = []
        pid = Process.spawn(environment, *command, out: output, err: error, pgroup: true, chdir: ROOT)
        status = nil
        begin
          loop do
            samples.concat(RemyFit.fdinfo(pid))
            waited = Process.waitpid2(pid, Process::WNOHANG)
            if waited
              status = waited[1]
              break
            end
            if Process.clock_gettime(Process::CLOCK_MONOTONIC) >= [start + 90, @deadline].min
              Process.kill("TERM", -pid)
              sleep 0.2
              Process.kill("KILL", -pid) rescue Errno::ESRCH
              Process.waitpid(pid)
              raise "Remy rates fit exceeded its 90-second limit"
            end
            sleep 0.02
          end
        ensure
          if status.nil?
            Process.kill("KILL", -pid) rescue Errno::ESRCH
            Process.waitpid(pid) rescue Errno::ECHILD
          end
          File.write(File.join(folder, "gpu-fdinfo.json"), JSON.pretty_generate(samples) + "\n")
        end
        wall = Process.clock_gettime(Process::CLOCK_MONOTONIC) - start
        raise "recipe rates fit failed; inspect #{error}" unless status.success?
        raise "recipe rates fit has no measured amdgpu engine activity" unless RemyFit.engine_activity?(samples, @backend.fetch("pci"))
        proposal_lines = File.readlines(output).select { |line| line.start_with?("remy-guess\t") }
        raise "recipe guess sequence is incomplete" unless proposal_lines.map { |line| Integer(line.split("\t")[1]) } == (1..24).to_a
        guesses = proposal_lines.filter_map do |line|
          next unless line.start_with?("remy-guess\t")
          _, number, parameters, score, seconds = line.strip.split("\t")
          next if score == "invalid"
          values = parameters.split(",").to_h { |entry| k, v = entry.split("=", 2); [k, Float(v)] }
          {"guess" => Integer(number), "rates" => values, "score" => Float(score), "proposal_seconds" => Float(seconds)}
        end
        raise "recipe fit did not complete 24 guesses" unless proposal_lines.length == 24
        raise "recipe fit has no usable finite guesses" if guesses.empty? || guesses.any? { |g| !g["score"].finite? }
        raise "recipe rates fit returned invalid guesses" unless allow_invalid || guesses.length == 24
        best = guesses.min_by { |g| g["score"] }
        value = scorer.call(problem, best.fetch("rates"))
        objective = value[:score] || value.fetch("score")
        raise "adapter result does not match the selected recipe guess" unless (objective - best["score"]).abs <= 1e-10 * [objective.abs, 1.0].max
        result = {"rates" => best["rates"], "objective" => objective, "rmse_pp" => value[:rmse], "objective_details" => value,
                  "proof" => @backend.merge("pid" => pid, "wall_seconds" => wall, "guesses" => proposal_lines.length, "valid_guesses" => guesses.length,
                                            "fdinfo" => File.join(folder, "gpu-fdinfo.json"), "recipe_log" => output)}
        File.write(File.join(folder, "result.json"), JSON.pretty_generate(result) + "\n")
        result
      end
    end

    def objective(problem, rates)
      types = problem.fetch("types")
      raise ArgumentError, "rate names differ from the problem" unless rates.keys.sort == types.sort
      values = types.map { |k| Float(rates.fetch(k)) }
      raise ArgumentError, "rates must be finite" unless values.all?(&:finite?)
      error = problem.fetch("x").zip(problem.fetch("y")).sum do |row, target|
        prediction = row.zip(values).sum { |exposure, rate| exposure * rate }
        (prediction - target)**2
      end.fdiv(problem.fetch("y").length)
      prior = values.each_index.sum { |j| ((values[j] - problem["centers"][j]) / problem["spans"][j])**2 }.fdiv(values.length)
      {score: error / problem.fetch("quota_scale")**2 + problem.fetch("prior_weight") * prior, rmse: Math.sqrt(error)}
    end

    def fdinfo(group)
      Dir.glob("/proc/[0-9]*/stat").flat_map do |file|
        text = File.read(file)
        tail = text[(text.rindex(")") + 2)..].split
        next [] unless tail[2].to_i == group
        pid = file.split("/")[2].to_i
        Dir.glob("/proc/#{pid}/fdinfo/*").filter_map do |path|
          content = File.read(path)
          next unless content.match?(/^drm-driver:\s+amdgpu$/)
          engines = content.scan(/^drm-engine-(\S+):\s+(\d+) ns$/).to_h.transform_values(&:to_i)
          {"pid" => pid, "fd" => File.basename(path), "at" => Process.clock_gettime(Process::CLOCK_MONOTONIC),
           "pdev" => content[/^drm-pdev:\s+(\S+)/, 1], "engines_ns" => engines}
        rescue Errno::ENOENT, Errno::EACCES
          nil
        end
      rescue Errno::ENOENT, Errno::EACCES
        []
      end
    end

    def engine_activity?(samples, pci)
      samples.select { |s| s["pdev"] == pci }.group_by { |s| [s["pid"], s["fd"], s["pdev"]] }.any? do |_, rows|
        rows.last.fetch("engines_ns").any? { |engine, value| value > rows.first.fetch("engines_ns").fetch(engine, 0) }
      end
    end
  end
end

if $PROGRAM_NAME == __FILE__
  if ARGV[0] == "--preflight"
    puts JSON.generate(Rates::RemyFit.preflight!)
  elsif ARGV[0] == "--evaluate" && ARGV.length == 2
    problem = JSON.parse(File.read(ARGV[1]))
    STDIN.each_line do |line|
      begin
        rates = line.strip.split(",").to_h { |entry| k, v = entry.split("=", 2); [k, Float(v)] }
        puts format("%.17g", Rates::RemyFit.objective(problem, rates)[:score])
      rescue ArgumentError, KeyError, TypeError
        puts "invalid"
      end
      STDOUT.flush
    end
  else
    abort "usage: remy-fit.rb --preflight | --evaluate <problem.json>"
  end
end
