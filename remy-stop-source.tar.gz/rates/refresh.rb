#!/usr/bin/env ruby
# frozen_string_literal: true

# Refresh the rate fit on this host and publish it.
#   refresh.rb          every 5 minutes: live/latest.json and live/DAILY.md
#   refresh.rb --daily  21:00 Los Angeles: also the RATECARD.md row and live/status-section.json
# Replaces remote-refresh.mjs, which copied the inputs to sentry and ran the fit under Node there.

require "socket"
require_relative "live-fit"
require_relative "remy-fit"

JS = Rates::JS

base = ARGV.include?("--base") ? File.expand_path(ARGV[ARGV.index("--base") + 1]) : Rates::BASE
daily = ARGV.include?("--daily")
live = File.join(base, "live")
lock = File.join(live, ".refresh.lock")

def acquire(lock)
  2.times do
    File.open(lock, File::WRONLY | File::CREAT | File::EXCL) { |f| f.write(Process.pid.to_s) }
    return true
  rescue Errno::EEXIST
    pid = File.read(lock).to_i
    begin
      Process.kill(0, pid)
      return false
    rescue Errno::ESRCH
      File.unlink(lock)
    end
  end
  false
end

unless acquire(lock)
  puts JS.stringify({"state" => "already_running"})
  exit(daily ? 1 : 0)
end

status = 0
begin
  wall = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  cutoff = JS.now_ms
  engine = Rates::RemyFit::Engine.new(base)
  result = Rates.analyze_root(base, cutoff, token_fitter: engine.method(:fit))
  Rates.atomic(File.join(live, "latest.json"), JS.stringify(result, 2))
  compute = {
    "host" => Socket.gethostname, "pid" => Process.pid, "cutoff" => cutoff,
    "cards" => result["cards"].length, "requests" => result["input_summary"]["n_unique_requests"],
    "wall_s" => (Process.clock_gettime(Process::CLOCK_MONOTONIC) - wall).round(3),
    "cpu_s" => Process.clock_gettime(Process::CLOCK_PROCESS_CPUTIME_ID).round(3)
  }
  publication = begin
    daily ? Rates.persist_daily(base, result) : Rates.publish_readable(base, result)
  rescue StandardError => e
    status = 1 if daily
    {"state" => "held", "reason" => "Error: #{e.message}"}
  end
  Rates.atomic(File.join(live, "publication-state.json"), JS.stringify(publication.merge("at" => JS.iso(JS.now_ms)), 2))
  puts JS.stringify({"state" => "computed", "compute" => compute, "publication" => publication})
rescue StandardError => e
  status = 1
  failure = {"state" => e.message.include?(Rates::RemyFit::ISSUE) ? "blocked" : "failed", "method" => "remy_recipe_gpu", "reason" => e.message,
             "at" => JS.iso(JS.now_ms), "gpu_execution" => "not measured"}
  Rates.atomic(File.join(live, "remy-fit-state.json"), JS.stringify(failure, 2))
  warn JS.stringify(failure)
ensure
  File.unlink(lock) if File.exist?(lock) && File.read(lock) == Process.pid.to_s
end
exit status
