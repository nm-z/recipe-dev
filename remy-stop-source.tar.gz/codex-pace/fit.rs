// Remy chooses signed quota rates; the adapter measures their window error.
use recipe::*;

fn main() {
	let directory = std::env::args().nth(1).expect("usage: remy-fit.rs <problem directory>");
	assert_eq!(std::env::var("RECIPE_DEVICE").as_deref(), Ok("amd0"), "rates require amd0");
	let evaluator = recipe.model().layer(32).fp(32).gelu().layer(1).fp(32).loss(mse);
	let validity = recipe.model().layer(32).fp(32).gelu().layer(1).fp(32).sigmoid().loss(bce);
	let proposer = recipe.model().layer(32).fp(32).gelu().layer(640).fp(32).loss(&evaluator);
	let data = recipe.data(format!("{directory}/context.csv"));
	let epochs = std::env::var("REMY_RATE_EPOCHS").ok()
		.and_then(|s| s.parse::<usize>().ok()).unwrap_or(23);
	assert!((1..=23).contains(&epochs), "rates fit allows 1 to 23 epochs");
	let report = recipe.train()
		.seed(20261006)
		.epochs(epochs)
		.lr(0.03)
		.space(format!("{directory}/knobs.tsv"))
		.valid(&validity)
		.rat_steps(20, 50)
		.entropy(10.0)
		.target(-1000.0)
		.rat(history, format!("{directory}/objective.sh"))
		.run(&proposer, &data);
	println!("remy-best\t{}", report.final_loss());
}
