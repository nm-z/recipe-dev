# Codex pacing

This job queues behind the rates fit and recipe-dev issue #994. The CEO's interim target is 1.1 percentage points per hour. That value is an order, not a fitted recommendation.

`extract.rb` scans every local rollout incrementally and records only selected token/quota data. It writes normalized events, hourly quota/activity data, reset candidates, current banked credits, and a one-line `latest.json`. It reuses the rates collector's read-only app-server handshake. It never redeems a credit or changes the fleet.

`objective.rb --build` prepares the knob space and real-data environment. The objective scores reset-time prediction error, quota left at reset, time exhausted before reset, concentrated burn, agent/burn mismatch, and idle time at full allowance. More than 20% unused at the scheduled weekly reset is invalid. The remaining 20% uses a separately fitted coast rate. Burn and agent counts are chosen by Remy, not calculated as a fixed pacing rule.

`fit.rs` reuses the rates fit's 26-line recipe program with the pacing knob table and adapter. Once rates is verified on a compliant GPU backend, the fit can run through that same public recipe entrypoint:

```bash
RECIPE_DEVICE=amd0 recipe run /home/nate/ceo-orders/codex-pace/fit.rs --device amd0 -- /home/nate/ceo-orders/codex-pace/problem
```

Do not run this command until #994 lands and the rates fit has GPU proof. The hourly runner performs these checks and calls the shared GPU executor once they pass. Until then, it refreshes data and labels the interim target. Rates and pacing share a GPU-fit lock. Pacing starts four minutes past each hour to avoid the normal rates-refresh start.

## Sources and limits

- Public reset history is archived with fetch time and SHA-256. Banked grants are excluded from automatic-reset intervals. Public announcements are scenarios for forecasting, not proof of an account reset.
- Local quota drops are reset candidates. They can reflect early resets, banked resets, or changes to an allowance. They are not labeled as confirmed resets without additional evidence.
- Activity counts sessions producing tokens in an hour, not running processes. It does not establish complete account usage or exact process concurrency.
- Banked-credit outcome data come from observed count decreases paired with quota drops. No confirmed banked redemption is currently recorded. For an available Full reset, the objective can extrapolate its effect from same-bucket full-refill candidates in the rollout history. That transfer is an explicit prediction assumption; it is not labeled a measured banked-redemption outcome. Without either source of effect data, a spend-now candidate remains invalid. The objective also counts idle time when the allowance starts exhausted and the loss of a banked credit that expires before the planned cycle ends.
- `scheduled_reset_hours` is arithmetic from the API's deadline. It is separate from the model's `predicted_time_to_next_reset_hours`.
- Learned outputs, GPU activity, and fit time remain unmeasured while queued.
