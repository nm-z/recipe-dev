#!/usr/bin/env ruby
# frozen_string_literal: true
require_relative "extract"
require_relative "objective"
require_relative "fit"
lock=File.open(File.join(CodexPace::BASE,".extract.lock"),"w")
abort "another extraction is running" unless lock.flock(File::LOCK_EX|File::LOCK_NB)
result=CodexPace.run
problem=CodexPace.build_problem
result["objective_data"]={"reset_scenarios"=>problem["reset_scenarios"].length,
 "agent_burn_observations"=>problem["agent_burn_observations"].length,"bank_outcomes"=>problem["bank_outcomes"].length,"bank_effect_candidates"=>problem["bank_effect_observations"].length}
result["gpu_fit_state"]="queued behind rates-fit.service and recipe-dev#994"
result=CodexPace.fit_after_rates(result,problem)
CodexPace.atomic(File.join(CodexPace::BASE,"latest.json"),result)
puts JSON.generate(result.slice("state","data_counts","objective_data","extraction_wall_seconds"))
