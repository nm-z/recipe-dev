require_relative "objective"
p={"remaining_percent"=>100,"scheduled_hours"=>10,"reset_scenarios"=>[{"hours"=>10,"kind"=>"scheduled_weekly"}],
   "agent_burn_observations"=>[{"burn_per_active_session"=>1,"observed_hours"=>1}],"bank_outcomes"=>[],"available_banked_resets"=>1,
   "policy"=>{"maximum_unused_at_weekly_reset"=>20,"coast_boundary_remaining"=>20}}
c={"next_reset_hours"=>10,"burn_pp_per_hour"=>10,"coast_pp_per_hour"=>10,"active_agents"=>10,"spend_banked_reset"=>0}
balanced=CodexPace.policy_score(p,c)
raise "coast does not reach reset" unless balanced["weekly_unused_percent"].zero?
rushed=CodexPace.policy_score(p,c.merge("burn_pp_per_hour"=>80,"coast_pp_per_hour"=>20.0/9,"active_agents"=>80))
raise "rush not penalized" unless rushed["score"]>balanced["score"]
exhausted=CodexPace.policy_score(p,c.merge("burn_pp_per_hour"=>20,"coast_pp_per_hour"=>20,"active_agents"=>20))
raise "early exhaustion not penalized" unless exhausted["score"]>balanced["score"]
idle=CodexPace.policy_score(p,c.merge("active_agents"=>0))
raise "idle fleet at full quota not penalized" unless idle["score"]>balanced["score"]
tail=CodexPace.policy_score(p.merge("remaining_percent"=>17),c.merge("burn_pp_per_hour"=>80,"coast_pp_per_hour"=>2,"active_agents"=>2))
raise "agents do not match current coast burn" unless tail["terms"]["agent_burn_match"].zero? && tail["effective_current_rate"]==2
proxy=p.merge("remaining_percent"=>0,"bank_effect_observations"=>[{"after_remaining"=>100,"after_regular_hours"=>10}])
hold=CodexPace.policy_score(proxy,c.merge("burn_pp_per_hour"=>0,"coast_pp_per_hour"=>0,"active_agents"=>0))
refill=CodexPace.policy_score(proxy,c.merge("spend_banked_reset"=>1))
raise "empty allowance idle or refill consequence missing" unless hold["score"]>refill["score"]
expiry=p.merge("remaining_percent"=>20,"built_at"=>"2026-10-08T00:00:00Z","credit_expires_at"=>Time.iso8601("2026-10-08T01:00:00Z").to_i,
  "bank_effect_observations"=>[{"after_remaining"=>100,"after_regular_hours"=>10}])
hold=CodexPace.policy_score(expiry,c.merge("burn_pp_per_hour"=>2,"coast_pp_per_hour"=>2,"active_agents"=>2))
refill=CodexPace.policy_score(expiry,c.merge("spend_banked_reset"=>1))
raise "unused banked allowance expiry not evaluated" unless hold["score"]>refill["score"]
rejected=0
[c.merge("burn_pp_per_hour"=>5,"coast_pp_per_hour"=>5),c.merge("spend_banked_reset"=>1),c.merge("active_agents"=>1.5)].each do |bad|
  begin
    CodexPace.policy_score(p,bad)
    raise "invalid policy accepted"
  rescue ArgumentError
    rejected+=1
  end
end
public=CodexPace.public_history
raise "reset archive rows lost" unless public["events"].length==File.read(File.join(CodexPace::BASE,"archive/reset-history.html")).scan(/<li[^>]*data-tweet-id=/).length
regular=public["events"].select{|e|e["kind"]=="regular"}
raise "banked grant entered automatic intervals" unless public["automatic_announcement_intervals"].all?{|i|regular.any?{|r|r["at"]==i["from"]}&&regular.any?{|r|r["at"]==i["to"]}}
result={"state"=>"passed","checks"=>["weekly unused cap","coast endpoint","rush penalty","exhaustion penalty","idle fleet at full allowance","unknown bank effect rejected","full-refill extrapolation","empty allowance idle time","banked allowance expiry","discrete outputs","current coast agent calibration","complete public archive parsing"],
        "balanced_score"=>balanced["score"],"rushed_score"=>rushed["score"],"exhausted_score"=>exhausted["score"],"rejections"=>rejected,"public_events"=>public["events"].length,"gpu_execution"=>"not measured"}
CodexPace.atomic(File.join(CodexPace::BASE,"objective-check.json"),result)
puts JSON.generate(result)
