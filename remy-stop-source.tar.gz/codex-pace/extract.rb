#!/usr/bin/env ruby
# frozen_string_literal: true
require "json"
require "time"
require "digest"
require "fileutils"
require "io/wait"
require "cgi"

module CodexPace
  BASE = File.expand_path(__dir__)
  ROOT = File.expand_path("~/.codex/sessions")
  module_function
  def atomic(path, value)
    temporary = "#{path}.#{Process.pid}.tmp"
    File.write(temporary, JSON.generate(value) + "\n")
    File.rename(temporary, path)
  end
  def weekly(raw)
    bucket = raw.dig("rateLimitsByLimitId", "codex") || raw["rateLimits"] || raw
    %w[primary secondary].filter_map do |which|
      w = bucket[which]
      next unless w && (w["windowDurationMins"] || w["window_minutes"]).to_i == 10_080
      used = w["usedPercent"] || w["used_percent"]
      reset = w["resetsAt"] || w["resets_at"]
      next unless used.is_a?(Numeric) && used.finite? && used.between?(0,100) && reset.is_a?(Numeric)
      {"used_percent" => used, "remaining_percent" => 100-used, "resets_at" => reset.to_i,
       "limit_id" => bucket["limitId"] || bucket["limit_id"], "plan_type" => bucket["planType"] || bucket["plan_type"]}
    end.first
  end
  # Reuse the rates collector's initialize/read handshake; no inference or redemption.
  def read_account
    ir, iw = IO.pipe
    or_, ow = IO.pipe
    pid = Process.spawn("codex", "app-server", "--stdio", in: ir, out: ow, err: File::NULL)
    ir.close; ow.close
    deadline = Process.clock_gettime(Process::CLOCK_MONOTONIC) + 20
    send = ->(message) { iw.write(JSON.generate(message)+"\n"); iw.flush }
    send.call({"id"=>1,"method"=>"initialize","params"=>{"clientInfo"=>{"name"=>"codex-pace-observer","version"=>"1.0.0"},"capabilities"=>{"experimentalApi"=>true}}})
    buffer = +""
    loop do
      left = deadline-Process.clock_gettime(Process::CLOCK_MONOTONIC)
      raise "quota read timed out" unless left.positive? && or_.wait_readable(left)
      bytes = or_.read_nonblock(65_536, exception:false)
      next if bytes == :wait_readable
      raise "app-server closed before quota read" if bytes.nil?
      buffer << bytes
      while (i=buffer.index("\n"))
        message = JSON.parse(buffer.slice!(0,i+1)) rescue next
        next unless message.is_a?(Hash)
        if message["id"]==1
          raise "app-server initialization failed" if message["error"]
          send.call({"method"=>"initialized","params"=>{}})
          send.call({"id"=>2,"method"=>"account/rateLimits/read","params"=>{}})
        elsif message["id"]==2
          raise "quota read failed" if message["error"]
          return message.fetch("result")
        end
      end
    end
  ensure
    Process.kill("TERM",pid) rescue Errno::ESRCH if pid
    Process.detach(pid) if pid
    [iw,or_].each { |io| io&.close unless io&.closed? }
  end
  def fetch_public_if_stale
    file=File.join(BASE,"archive/reset-history.html")
    metadata=JSON.parse(File.read(file+".json")) if File.exist?(file+".json")
    if metadata
      original=File.join(BASE,"archive","public-#{Time.iso8601(metadata["fetched_at"]).utc.strftime('%Y%m%dT%H%M%S')}.html")
      unless File.exist?(original)
        FileUtils.cp(file,original)
        atomic(original+".json",metadata)
      end
      return if Time.now.to_i-Time.iso8601(metadata["fetched_at"]).to_i<3600
    end
    archive=File.join(BASE,"archive","public-#{Time.now.utc.strftime('%Y%m%dT%H%M%S')}.html")
    raise "public reset-history fetch failed" unless system("/usr/bin/curl","--fail","--silent","--show-error","--location","--max-time","20","https://codex-resets.com/","--output",archive)
    metadata={"url"=>"https://codex-resets.com/","fetched_at"=>Time.now.utc.iso8601,"sha256"=>Digest::SHA256.file(archive).hexdigest,"bytes"=>File.size(archive)}
    atomic(archive+".json",metadata)
    FileUtils.cp(archive,file+".tmp")
    File.rename(file+".tmp",file)
    atomic(file+".json",metadata)
  end
  def public_history
    html = File.read(File.join(BASE,"archive/reset-history.html"))
    meta = JSON.parse(File.read(File.join(BASE,"archive/reset-history.html.json")))
    kinds = {}
    html.scan(/<a\b[^>]*class="cg-cell"[^>]*>/m).each do |tag|
      id = tag[/\/status\/(\d+)/,1]
      kinds[id] = tag[/data-reset-type="([^"]+)"/,1] if id
    end
    events = html.scan(/<li class="log-item" data-tweet-id="([^"]+)"[^>]*>(.*?)<\/li>/m).filter_map do |id, block|
      at = block[/data-datetime="([^"]+)"/,1]
      next unless at
      text = CGI.unescapeHTML(block[/<p class="log-item-text"[^>]*>(.*?)<\/p>/m,1].to_s.gsub(/<[^>]*>/,""))
      url = block[/class="log-item-link" href="([^"]+)"/,1]
      kind = kinds[id] || kinds[url.to_s[/\/status\/(\d+)/,1]] || "unknown"
      kind = "banked" if text.match?(/\bbanked\b/i)
      {"at"=>Time.iso8601(at).to_i,"kind"=>kind,"source_kind"=>kinds[id],"announcement_id"=>id,
       "source_url"=>url,"scope"=>"public_announcement_not_account_reset"}
    end.sort_by { |x|x["at"] }
    regular = events.select { |x|x["kind"]=="regular" }
    intervals = regular.each_cons(2).map { |a,b|{"from"=>a["at"],"to"=>b["at"],"hours"=>(b["at"]-a["at"])/3600.0} }
    result = {"source"=>meta,"events"=>events,"automatic_announcement_intervals"=>intervals}
    atomic(File.join(BASE,"public-resets.json"),result)
    result
  end
  def scan
    state_path = File.join(BASE,"scan-state.json")
    state = File.exist?(state_path) ? JSON.parse(File.read(state_path)) : {"files"=>{}}
    stats = {"files_seen"=>0,"files_read"=>0,"bytes_read"=>0,"token_events_added"=>0,"quota_events_added"=>0,"parse_errors"=>0,"inherited_records_skipped"=>0}
    File.open(File.join(BASE,"events.jsonl"),"a") do |output|
      Dir.glob(File.join(ROOT,"**/*.jsonl")).sort.each do |path|
        stat = File.stat(path)
        stats["files_seen"]+=1
        f = state["files"][path] ||= {"offset"=>0,"session"=>File.basename(path,".jsonl"),"birth"=>nil,"parent"=>nil,"total"=>nil,"model"=>nil}
        if stat.size < f["offset"] || (f["inode"] && f["inode"]!=stat.ino)
          f["offset"]=0; f["total"]=nil
        end
        f["inode"]=stat.ino
        next if f["offset"]==stat.size
        stats["files_read"]+=1
        File.open(path,"rb") do |input|
          input.seek(f["offset"])
          while (line=input.gets)
            break if input.pos>stat.size || !line.end_with?("\n")
            f["offset"]=input.pos
            stats["bytes_read"]+=line.bytesize
            next unless line.match?(/"type"\s*:\s*"(?:session_meta|turn_context|event_msg)"/) && (line.include?("token_count") || line.include?("session_meta") || line.include?("turn_context"))
            begin
              j=JSON.parse(line); p=j["payload"]
              next unless p.is_a?(Hash)
              t=Time.iso8601(j.fetch("timestamp")).to_f
              if j["type"]=="session_meta"
                f["session"]=p["id"] || f["session"]
                f["birth"]=Time.iso8601(p["timestamp"] || j["timestamp"]).to_f
                f["parent"]=p["parent_thread_id"] || (p["source"].is_a?(Hash) ? p.dig("source","subagent","thread_spawn","parent_thread_id") : nil)
                next
              elsif j["type"]=="turn_context"
                f["model"]=p["model"] || f["model"]
                next
              end
              next unless j["type"]=="event_msg" && p["type"]=="token_count"
              total=p.dig("info","total_token_usage","total_tokens")
              inherited=f["parent"] && f["birth"] && t<f["birth"]
              previous=f["total"]
              f["total"]=total if total.is_a?(Numeric)
              if inherited
                stats["inherited_records_skipped"]+=1
                next
              end
              quota=weekly(p["rate_limits"]) if p["rate_limits"].is_a?(Hash)
              changed=total.is_a?(Numeric) && total!=previous
              delta = if changed
                        previous.is_a?(Numeric) && total>=previous ? total-previous : p.dig("info","last_token_usage","total_tokens") || total
                      end
              record={"at"=>t,"session"=>f["session"],"model"=>f["model"],"total_tokens"=>total,
                      "token_delta"=>delta,"weekly"=>quota,"counter_restart"=>previous.is_a?(Numeric) && total.is_a?(Numeric) && total<previous}
              record["id"]=Digest::SHA256.hexdigest(JSON.generate(record))
              if quota || changed
                output.puts(JSON.generate(record))
                stats["quota_events_added"]+=1 if quota
                stats["token_events_added"]+=1 if changed
              end
            rescue JSON::ParserError, ArgumentError, KeyError, TypeError
              stats["parse_errors"]+=1
            end
          end
        end
      end
    end
    state["updated_at"]=Time.now.utc.iso8601
    atomic(state_path,state)
    atomic(File.join(BASE,"scan-receipt.json"),stats.merge("at"=>state["updated_at"],"root"=>ROOT))
    stats
  end
  def materialize
    quota={}; activity={}; seen={}; sessions={}
    File.foreach(File.join(BASE,"events.jsonl")) do |line|
      e=JSON.parse(line)
      next if seen[e["id"]]
      seen[e["id"]]=true
      hour=(e["at"]/3600).floor*3600
      if e["token_delta"].is_a?(Numeric) && e["token_delta"]>0
        a=activity[hour] ||= {"tokens"=>0,"sessions"=>{}}
        a["tokens"]+=e["token_delta"]
        a["sessions"][e["session"]]=true
        sessions[e["session"]]={"last_token_at"=>e["at"],"total_tokens"=>e["total_tokens"],"model"=>e["model"]}
      end
      if e["weekly"]
        key=[hour,e["weekly"]["resets_at"],e["weekly"]["limit_id"],e["weekly"]["plan_type"]]
        q=quota[key] ||= {"first"=>e,"last"=>e,"min_used"=>e["weekly"]["used_percent"],"max_used"=>e["weekly"]["used_percent"],"samples"=>0}
        q["first"]=e if e["at"]<q["first"]["at"]
        q["last"]=e if e["at"]>q["last"]["at"]
        q["min_used"]=[q["min_used"],e["weekly"]["used_percent"]].min
        q["max_used"]=[q["max_used"],e["weekly"]["used_percent"]].max
        q["samples"]+=1
      end
    end
    hours=quota.map do |key,q|
      first=q["first"]; last=q["last"]; elapsed=(last["at"]-first["at"])/3600.0
      delta=last["weekly"]["used_percent"]-first["weekly"]["used_percent"]
      a=activity[key[0]] || {"tokens"=>0,"sessions"=>{}}
      {"hour"=>key[0],"first_at"=>first["at"],"last_at"=>last["at"],"first_used_percent"=>first["weekly"]["used_percent"],
       "last_used_percent"=>last["weekly"]["used_percent"],"remaining_percent"=>last["weekly"]["remaining_percent"],
       "resets_at"=>key[1],"limit_id"=>key[2],"plan_type"=>key[3],"samples"=>q["samples"],"elapsed_hours"=>elapsed,
       "burn_pp_per_hour"=>elapsed>0 && delta>=0 && q["max_used"]<100 ? delta/elapsed : nil,
       "token_delta"=>a["tokens"],"active_token_sessions"=>a["sessions"].length,
       "activity_scope"=>"sessions producing tokens in the UTC hour; account attribution not proved",
       "quota_monotone_within_hour"=>q["min_used"]==first["weekly"]["used_percent"] && q["max_used"]==last["weekly"]["used_percent"]}
    end.sort_by { |h|h["first_at"] }
    resets=hours.each_cons(2).filter_map do |a,b|
      next unless a["limit_id"]==b["limit_id"] && a["plan_type"]==b["plan_type"] && b["first_used_percent"]<a["last_used_percent"]
      {"previous_sample_at"=>a["last_at"],"at"=>b["first_at"],"previous_resets_at"=>a["resets_at"],
       "new_resets_at"=>b["resets_at"],"drop_pp"=>a["last_used_percent"]-b["first_used_percent"],
       "kind"=>b["first_at"]>=a["resets_at"] ? "scheduled_reset_candidate" : "early_or_banked_reset_candidate"}
    end
    data={"at"=>Time.now.utc.iso8601,"hourly"=>hours,"reset_candidates"=>resets,"sessions"=>sessions,
          "limitations"=>["Activity counts token-producing sessions, not running processes.","Quota drops are reset candidates, not confirmed reset or bank-credit consumption.","Local rollout history does not prove complete account usage."]}
    atomic(File.join(BASE,"history.json"),data)
    data
  end
  def run
    started=Process.clock_gettime(Process::CLOCK_MONOTONIC)
    fetch_public_if_stale
    public=public_history
    receipt=scan
    history=materialize
    now=Time.now.to_i
    account=read_account
    stamp=Time.now.utc.strftime("%Y%m%dT%H%M%S")
    archive=File.join(BASE,"archive","account-#{stamp}.json")
    atomic(archive,{"fetched_at"=>Time.now.utc.iso8601,"method"=>"account/rateLimits/read","result"=>account.slice("rateLimits","rateLimitsByLimitId","rateLimitResetCredits","accountId")})
    current=weekly(account)
    credits=account["rateLimitResetCredits"]
    latest={"generated_at"=>Time.now.utc.iso8601,"state"=>"queued_behind_rates_and_recipe_994",
            "fit_method"=>"Remy recipe GPU; not run", "predicted_time_to_next_reset_hours"=>nil,
            "target_burn_pp_per_hour"=>1.1,"target_burn_source"=>"CEO interim order, not model output",
            "active_agent_count"=>nil,"spend_banked_reset"=>nil,"weekly"=>current,
            "scheduled_reset_hours"=>current ? (current["resets_at"]-now)/3600.0 : nil,
            "banked_resets"=>credits,"sources"=>{"account_archive"=>archive,"public_history"=>public["source"],"scan"=>receipt},
            "data_counts"=>{"hours"=>history["hourly"].length,"sessions"=>history["sessions"].length,"reset_candidates"=>history["reset_candidates"].length},
            "extraction_wall_seconds"=>Process.clock_gettime(Process::CLOCK_MONOTONIC)-started}
    atomic(File.join(BASE,"latest.json"),latest)
    latest
  end
end
if $PROGRAM_NAME==__FILE__
  FileUtils.mkdir_p(File.join(CodexPace::BASE,"archive"))
  lock=File.open(File.join(CodexPace::BASE,".extract.lock"),"w")
  abort "another extraction is running" unless lock.flock(File::LOCK_EX|File::LOCK_NB)
  result=CodexPace.run
  puts JSON.generate(result.slice("state","data_counts","extraction_wall_seconds"))
end
