# frozen_string_literal: true
require_relative "objective"
require "/home/nate/ceo-orders/rates/remy-fit"

module CodexPace
  module_function
  def fit_after_rates(result, problem)
    rate_file="/home/nate/ceo-orders/rates/live/latest.json"
    rates=JSON.parse(File.read(rate_file))
    proofs=rates.fetch("cards").filter_map{|card|card.dig("pooled_fit","remy_execution")}
    rate_age=Time.now.to_i-Time.iso8601(rates.fetch("generated_at")).to_i
    unless rate_age>=0 && rate_age<3600 && !proofs.empty? && proofs.all?{|p|p["device"]=="amd0" && p["gfx"]=="gfx1101" && File.exist?(p.fetch("fdinfo")) && Rates::RemyFit.engine_activity?(JSON.parse(File.read(p["fdinfo"])),p.fetch("pci"))}
      result["gpu_fit_state"]="queued: rates has not published fresh GPU proof"
      return result
    end
    engine=Rates::RemyFit::Engine.new(BASE)
    actual=engine.execute(File.join(BASE,"problem"), problem, script:File.join(BASE,"fit.rs"),
                          scorer:method(:policy_score), allow_invalid:true)
    policy=actual.fetch("rates")
    result["state"]="remy_gpu_fit_published"
    result["fit_method"]="Remy recipe GPU"
    result["gpu_fit_state"]="verified by process amdgpu engine-time increase"
    result["predicted_time_to_next_reset_hours"]=policy.fetch("next_reset_hours")
    result["target_burn_pp_per_hour"]=actual.fetch("objective_details").fetch("effective_current_rate")
    result["target_burn_source"]="Remy GPU policy fit"
    result["active_agent_count"]=policy.fetch("active_agents").to_i
    result["active_agent_count_scope"]="prediction calibrated to local token-producing session counts"
    result["spend_banked_reset"]=problem["available_banked_resets"].to_i>0 && problem.fetch("bank_effect_observations",problem["bank_outcomes"]).empty? ? nil : policy.fetch("spend_banked_reset")==1
    result["bank_decision_status"]=problem["bank_effect_source"] || "Remy GPU policy fit"
    result["policy_parameters"]=policy
    result["fit_proof"]=actual.fetch("proof")
    result["objective_score"]=actual.fetch("objective")
    result["objective_details"]=actual.fetch("objective_details")
    result["rates_fit_source"]={"path"=>rate_file,"generated_at"=>rates["generated_at"]}
    result
  rescue StandardError => e
    result["gpu_fit_state"]="queued or failed: #{e.message}"
    result["fit_error_at"]=Time.now.utc.iso8601
    result
  end
end
