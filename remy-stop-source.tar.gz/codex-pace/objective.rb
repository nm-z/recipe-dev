#!/usr/bin/env ruby
# frozen_string_literal: true
require_relative "extract"

module CodexPace
  module_function
  def bank_outcomes
    prior={}; outcomes=[]
    File.foreach("/home/nate/ceo-orders/rates/live/samples.jsonl") do |line|
      j=JSON.parse(line)
      next unless j["provider"]=="codex" && j["fresh"]
      raw=j["rate_limits"]; next unless raw.is_a?(Hash)
      q=weekly(raw); c=raw["rateLimitResetCredits"]
      next unless q && c && c["availableCount"].is_a?(Numeric)
      at=j["t"].to_f/1000
      account=j["account"]
      old=prior[account]
      if old && c["availableCount"]<old["count"] && q["used_percent"]<old["quota"]["used_percent"] && at<old["quota"]["resets_at"]
        outcomes << {"at"=>at,"before_remaining"=>old["quota"]["remaining_percent"],"after_remaining"=>q["remaining_percent"],
                     "after_regular_hours"=>(q["resets_at"]-at)/3600.0,"kind"=>"credit_decrease_and_quota_drop_candidate"}
      end
      prior[account]={"at"=>at,"count"=>c["availableCount"],"quota"=>q}
    rescue JSON::ParserError, TypeError
      next
    end
    outcomes
  end
  def full_refill_candidates(history, quota)
    history.fetch("hourly").each_cons(2).filter_map do |a,b|
      next unless a["limit_id"]==quota["limit_id"] && b["limit_id"]==quota["limit_id"] &&
        a["plan_type"]==quota["plan_type"] && b["plan_type"]==quota["plan_type"] &&
        b["first_used_percent"]==0 && a["last_used_percent"]>0 && b["resets_at"]>b["first_at"]
      {"at"=>b["first_at"],"before_remaining"=>100-a["last_used_percent"],"after_remaining"=>100,
       "after_regular_hours"=>(b["resets_at"]-b["first_at"])/3600.0,
       "observation_gap_hours"=>(b["first_at"]-a["last_at"])/3600.0,
       "kind"=>"same_bucket_full_refill_candidate_not_confirmed_banked_redemption"}
    end
  end
  def build_problem
    latest=JSON.parse(File.read(File.join(BASE,"latest.json")))
    history=JSON.parse(File.read(File.join(BASE,"history.json")))
    public=public_history
    now=Time.now.to_i
    quota=latest.fetch("weekly")
    raise "fresh weekly quota unavailable" unless quota && now-Time.iso8601(latest.fetch("generated_at")).to_i<3600
    horizon=(quota.fetch("resets_at")-now)/3600.0
    raise "weekly reset deadline has passed" unless horizon.positive?
    announcements=public["events"].select { |e|e["kind"]=="regular" }
    elapsed=announcements.empty? ? nil : (now-announcements.last["at"])/3600.0
    residuals=public["automatic_announcement_intervals"].filter_map do |i|
      remaining=i["hours"]-elapsed if elapsed
      [remaining,horizon].min if remaining && remaining.positive?
    end
    scenarios=residuals.map { |h|{"hours"=>h,"kind"=>"public_announcement_residual_scenario"} }
    scenarios << {"hours"=>horizon,"kind"=>"scheduled_weekly"}
    burn=history["hourly"].select do |h|
      h["burn_pp_per_hour"] && h["quota_monotone_within_hour"] && h["active_token_sessions"]>0 && h["elapsed_hours"]>0
    end.map { |h|{"burn_per_active_session"=>h["burn_pp_per_hour"]/h["active_token_sessions"],
                 "active_sessions"=>h["active_token_sessions"],"observed_hours"=>h["elapsed_hours"]} }
    banks=bank_outcomes
    full_refills=full_refill_candidates(history,quota)
    full_credit=latest.dig("banked_resets","credits")&.any?{|c|c["status"]=="available" && c["title"]=="Full reset"}
    bank_effects=banks.empty? && full_credit ? full_refills : banks
    problem={"built_at"=>Time.now.utc.iso8601,"remaining_percent"=>quota["remaining_percent"],"scheduled_hours"=>horizon,
      "reset_scenarios"=>scenarios,"agent_burn_observations"=>burn,"bank_outcomes"=>banks,
      "bank_effect_observations"=>bank_effects,"bank_effect_source"=>bank_effects.empty? ? "not measured: no eligible reset effect observations" : (banks.empty? ? "same-bucket full-refill extrapolation; not confirmed banked redemptions" : "credit-decrease/refill candidates"),
      "available_banked_resets"=>latest.dig("banked_resets","availableCount"),
      "credit_expires_at"=>latest.dig("banked_resets","credits")&.filter_map{|c|c["expiresAt"]}.min,
      "policy"=>{"maximum_unused_at_weekly_reset"=>20,"coast_boundary_remaining"=>20},
      "limitations"=>["Public reset announcements are forecasting scenarios, not observed account resets.",
        "Burn calibration uses local token-producing session counts, not proven running-agent counts.",
        "A Full reset effect may be extrapolated from same-bucket full-refill candidates; this prediction is not a measured banked-redemption outcome."]}
    atomic(File.join(BASE,"problem.json"),problem)
    FileUtils.mkdir_p(File.join(BASE,"problem"))
    File.write(File.join(BASE,"problem/context.csv"),"context\n1\n")
    max_burn=burn.map{|b|b["burn_per_active_session"]*b["active_sessions"]}.max
    raise "no measured agent/burn observations" unless max_burn && max_burn.positive?
    max_agents=burn.map{|b|b["active_sessions"]}.max
    continuous={"next_reset_hours"=>[0,horizon],"burn_pp_per_hour"=>[0,max_burn],"coast_pp_per_hour"=>[0,max_burn]}
    knobs=continuous.map do |name,(lo,hi)|
      if name=="next_reset_hours"
        points=(0..20).map{|i|hi*i/20.0}
      else
      minimum=burn.map{|b|b["burn_per_active_session"]}.select(&:positive?).min
      points=(0..36).map{|i|Math.exp(Math.log(minimum)+(Math.log(hi)-Math.log(minimum))*i/36.0)}
      # Include a deadline-feasible configuration in the search space. Remy
      # still selects the rate by scoring all of its proposed configurations.
      points=([0.0,quota["remaining_percent"]/horizon]+points).uniq.sort
      end
      positions=points.each_index.map{|i|format("%.17g",i.to_f/(points.length-1))}
      values=points.map{|v|format("%.17g",v)}
      [name,1,-1,"",positions.join(","),values.join("|"),10].join("\t")
    end
    agents=(0..39).map{|i|(max_agents*i/39.0).round}.uniq
    knobs << ["active_agents",0,-1,"",agents.map{|n|n.to_f/max_agents}.join(","),agents.join("|"),0].join("\t")
    knobs << ["spend_banked_reset",0,-1,"","0,1","0|1",0].join("\t")
    File.write(File.join(BASE,"problem/knobs.tsv"),knobs.join("\n")+"\n")
    adapter=File.join(BASE,"problem/objective.sh")
    File.write(adapter,"#!/bin/bash\nexec /usr/bin/ruby #{BASE}/objective.rb --evaluate #{BASE}/problem.json\n")
    File.chmod(0o700,adapter)
    problem
  end
  def policy_score(problem, candidate)
    names=%w[next_reset_hours burn_pp_per_hour coast_pp_per_hour active_agents spend_banked_reset]
    raise ArgumentError,"incorrect policy outputs" unless candidate.keys.sort==names.sort
    values=names.map{|k|Float(candidate.fetch(k))}
    raise ArgumentError,"invalid policy outputs" unless values.all?{|v|v.finite? && v>=0}
    predicted,rate,coast,agents,spend=values
    raise ArgumentError,"agent count or spend flag is not discrete" unless agents==agents.round && [0,1].include?(spend)
    remaining=problem.fetch("remaining_percent")
    regular=problem.fetch("scheduled_hours")
    bank_cost=0.0
    bank_expiry_waste=0.0
    expiry=problem["credit_expires_at"]
    if spend==0 && problem["available_banked_resets"].to_i>0 && expiry && expiry<=Time.iso8601(problem.fetch("built_at")).to_i+regular*3600
      bank_expiry_waste=1.0
    end
    if spend==1
      raise ArgumentError,"no banked reset available" unless problem["available_banked_resets"].to_i>0
      banks=problem["bank_effect_observations"] || problem.fetch("bank_outcomes")
      raise ArgumentError,"banked reset outcome is not measured" if banks.empty?
      remaining=banks.sum{|b|b["after_remaining"]}.fdiv(banks.length)
      regular=banks.sum{|b|b["after_regular_hours"]}.fdiv(banks.length)
      bank_cost=problem.fetch("remaining_percent")/100.0
    end
    boundary=problem.fetch("policy").fetch("coast_boundary_remaining")
    # Rates are policy outputs. The environment measures depletion, smoothness,
    # wasted quota, and exhaustion time; it does not fit a model on the CPU.
    depletion=lambda do |hours|
      before=[remaining-boundary,0].max
      above=before.zero? ? 0.0 : (rate.positive? ? [hours,before/rate].min : hours)
      spent=[before,rate*above].min
      tail=[hours-above,0].max
      rest=[remaining-spent-coast*tail,0].max
      coast_hours=remaining==spent ? 0.0 : (coast.positive? ? [tail,(remaining-spent)/coast].min : tail)
      exhausted=remaining==spent || coast.positive? ? tail-coast_hours : 0.0
      energy=above*rate**2+coast_hours*coast**2
      concentrated=[energy*hours-(remaining-rest)**2,0].max/[remaining**2,1e-12].max
      {left:rest,idle:exhausted,rush:concentrated}
    end
    weekly_result=depletion.call(regular)
    raise ArgumentError,"more than 20% remains at the weekly reset" if weekly_result[:left]>problem["policy"]["maximum_unused_at_weekly_reset"]+1e-9
    raise ArgumentError,"the final allowance does not coast to zero at the weekly reset" if weekly_result[:left]>1e-9
    forecast=problem.fetch("reset_scenarios").sum{|s|((predicted-s["hours"])/problem["scheduled_hours"])**2}.fdiv(problem["reset_scenarios"].length)
    paths=problem.fetch("reset_scenarios").map{|s|h=spend==1 ? regular : s["hours"];d=depletion.call(h); (d[:left]/100.0)**2+d[:idle]/h+d[:rush]}
    idle_at_full=remaining>=100 && (agents.zero? || rate.zero?) ? 1.0 : 0.0
    current_rate=remaining<=boundary ? coast : rate
    calibration=problem.fetch("agent_burn_observations")
    weights=calibration.sum{|o|o["observed_hours"]}
    achievable=calibration.sum{|o|o["observed_hours"]*((agents*o["burn_per_active_session"]-current_rate)/[current_rate,1e-6].max)**2}/weights
    {"score"=>forecast+paths.sum.fdiv(paths.length)+achievable+idle_at_full+bank_cost+bank_expiry_waste,
     "terms"=>{"forecast"=>forecast,"quota_path"=>paths.sum.fdiv(paths.length),"agent_burn_match"=>achievable,"idle_at_full"=>idle_at_full,"bank_use"=>bank_cost,"expired_unused_banked_allowance"=>bank_expiry_waste},
     "weekly_unused_percent"=>weekly_result[:left],"effective_current_rate"=>current_rate}
  end
end
if $PROGRAM_NAME==__FILE__
  if ARGV[0]=="--build"
    p=CodexPace.build_problem
    puts JSON.generate({"reset_scenarios"=>p["reset_scenarios"].length,"agent_burn_observations"=>p["agent_burn_observations"].length,"bank_outcomes"=>p["bank_outcomes"].length})
  elsif ARGV[0]=="--evaluate" && ARGV.length==2
    problem=JSON.parse(File.read(ARGV[1]))
    STDIN.each_line do |line|
      begin
        candidate=line.strip.split(",").to_h{|s|k,v=s.split("=",2);[k,Float(v)]}
        puts format("%.17g",CodexPace.policy_score(problem,candidate).fetch("score"))
      rescue ArgumentError,KeyError,TypeError
        puts "invalid"
      end
      STDOUT.flush
    end
  else
    abort "usage: objective.rb --build | --evaluate <problem.json>"
  end
end
