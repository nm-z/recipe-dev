//! remy: Remy's first order. Commands:
//!
//!   remy run --technique <none|first-order> --challenge <space.json> --adapter <command> --out <trace.tsv> [--weights FILE]
//!       24 guesses on one challenge; Remy reads only the space.json knobs and talks to the adapter process.
//!       A challenge under ~/work/remy/holdout needs REMY_EVALUATION=1 (design rule 1: evaluation only).
//!   remy first-guess <space.json>            the design's first guess (no model runs)
//!   remy sample <id> [--out DIR]             write sampler problem <id>'s space.json (to DIR/space.json, or stdout)
//!   remy problem <id>                        serve as sampler problem <id>'s adapter (stdin configurations, stdout scores)
//!   remy synth --technique <list> [--from ID] [--count N] [--weights FILE] [--out TSV]
//!       runs on synthetic problems; techniques: none, first-order, random (comma list, paired on the same problems)
//!   remy pretrain [--out FILE] [--log TSV] [--meta-batch N] [--beta B] [--eval-every N] [--patience N]
//!   remy grad-report [--from ID] [--count N] [--weights FILE]   per-term gradient sizes and finite-difference checks
//!   remy sampler-stats [--from ID] [--count N]
//!   remy selftest
//! Settings flags (all commands that run Remy): --rat-steps --lin-steps --lr-rat --lr-lin --lambda --clip

use remy_core::eval::{self, RunStats, Task, mean, parallel, quantile, random_search, remy_run, tasks};
use remy_core::model::{Models, RatKind};
use remy_core::pretrain::{PretrainCfg, pretrain};
use remy_core::remy::{Guess, Remy, Settings};
use remy_core::rng::{Rng, SEED, mix};
use remy_core::sampler::{Problem, VALID_MIN, percentile};
use remy_core::space::{Config, Space};
use remy_core::tape::{T, Tape};
use remy_core::{sha256, tape};
use std::collections::HashMap;
use std::io::{BufRead, BufReader, Write};

const DEFAULT_WEIGHTS: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/weights/first-order.txt");

struct Args {
	pos: Vec<String>,
	flags: HashMap<String, String>,
}

impl Args {
	fn parse(v: &[String]) -> Args {
		let mut pos = Vec::new();
		let mut flags = HashMap::new();
		let mut i = 0;
		while i < v.len() {
			if let Some(name) = v[i].strip_prefix("--") {
				if i + 1 < v.len() && !v[i + 1].starts_with("--") {
					flags.insert(name.to_string(), v[i + 1].clone());
					i += 2;
				} else {
					flags.insert(name.to_string(), "1".into());
					i += 1;
				}
			} else {
				pos.push(v[i].clone());
				i += 1;
			}
		}
		Args { pos, flags }
	}
	fn get(&self, k: &str) -> Option<&str> {
		self.flags.get(k).map(|s| s.as_str())
	}
	fn req(&self, k: &str) -> Result<&str, String> {
		self.get(k).ok_or(format!("missing --{k}"))
	}
	fn num<N: std::str::FromStr>(&self, k: &str, default: N) -> N {
		self.get(k).map(|s| s.parse().unwrap_or_else(|_| panic!("--{k}: bad number {s}"))).unwrap_or(default)
	}
}

fn settings(a: &Args) -> Settings {
	let d = Settings::default();
	Settings {
		guesses: a.num("guesses", d.guesses),
		rat_steps: a.num("rat-steps", d.rat_steps),
		lin_steps: a.num("lin-steps", d.lin_steps),
		lr_rat: a.num("lr-rat", d.lr_rat),
		lr_lin: a.num("lr-lin", d.lr_lin),
		lambda: a.num("lambda", d.lambda),
		clip: a.num("clip", d.clip),
		score_scale: a.num("score-scale", d.score_scale),
		smooth: a.num("smooth", d.smooth),
		tau: a.num("tau", d.tau),
		tau_ordered: a.num("tau-ordered", d.tau_ordered),
		mean_decode: a.num("mean-decode", d.mean_decode),
		oracle: a.num("oracle", d.oracle),
	}
}

fn load_models(technique: &str, a: &Args) -> Result<(Models, String), String> {
	match technique {
		"none" => Ok((Models::new(SEED), "none (no pretraining: the fixed values are the seeded initialization)".into())),
		"first-order" => {
			let path = a.get("weights").unwrap_or(DEFAULT_WEIGHTS);
			let text = std::fs::read_to_string(path).map_err(|e| format!("{path}: {e}"))?;
			let mut m = Models::new(SEED);
			m.load_text(&text)?;
			Ok((m, format!("{path} sha256 {}", sha256::hex(text.as_bytes()))))
		}
		other => Err(format!("unknown technique {other}")),
	}
}

fn civil(days: i64) -> (i64, u32, u32) {
	let z = days + 719468;
	let era = z.div_euclid(146097);
	let doe = z - era * 146097;
	let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
	let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
	let mp = (5 * doy + 2) / 153;
	let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
	let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
	(yoe + era * 400 + (m <= 2) as i64, m, d)
}

fn utc_now() -> String {
	let s = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_secs() as i64;
	let (y, m, d) = civil(s.div_euclid(86400));
	let r = s.rem_euclid(86400);
	format!("{y:04}-{m:02}-{d:02}T{:02}:{:02}:{:02}Z", r / 3600, r % 3600 / 60, r % 60)
}

fn cmd_run(a: &Args) -> Result<(), String> {
	let technique = a.req("technique")?;
	let challenge = a.req("challenge")?;
	let adapter = a.req("adapter")?;
	let out = a.req("out")?;
	let canon = std::fs::canonicalize(challenge).map_err(|e| format!("{challenge}: {e}"))?;
	if canon.to_string_lossy().contains("/work/remy/holdout/") && std::env::var("REMY_EVALUATION").as_deref() != Ok("1") {
		return Err(format!(
			"{} is a holdout challenge. Design rule 1: Remy runs on the holdout only in evaluation. Set REMY_EVALUATION=1 for the evaluation run.",
			canon.display()
		));
	}
	let space_text = std::fs::read(challenge).map_err(|e| format!("{challenge}: {e}"))?;
	let space = Space::load(challenge)?;
	let st = settings(a);
	let (models, wdesc) = load_models(technique, a)?;
	let mut child = std::process::Command::new("sh")
		.arg("-c")
		.arg(adapter)
		.stdin(std::process::Stdio::piped())
		.stdout(std::process::Stdio::piped())
		.stderr(std::process::Stdio::inherit())
		.spawn()
		.map_err(|e| format!("adapter: {e}"))?;
	let mut to = child.stdin.take().unwrap();
	let mut from = BufReader::new(child.stdout.take().unwrap());
	let mut w = std::fs::File::create(out).map_err(|e| format!("{out}: {e}"))?;
	writeln!(w, "# remy run: technique {technique}, seed {SEED}, weights {wdesc}").unwrap();
	writeln!(w, "# challenge {} sha256 {} (Remy reads only its knobs list)", canon.display(), sha256::hex(&space_text)).unwrap();
	writeln!(w, "# adapter: {adapter}").unwrap();
	writeln!(w, "# settings: {}", st.describe()).unwrap();
	writeln!(w, "# started {}", utc_now()).unwrap();
	writeln!(w, "guess\tconfig\tscore\tbest_so_far\tvalid\tpropose_seconds").unwrap();
	w.flush().ok();
	let mut remy = Remy::new(&space, models, st);
	let sp = &space;
	let mut measure = |cfg: &Config| -> Option<f64> {
		let line = sp.config_text(cfg);
		writeln!(to, "{line}").and_then(|_| to.flush()).expect("write to the adapter");
		let mut reply = String::new();
		let got = from.read_line(&mut reply).expect("read from the adapter");
		if got == 0 {
			panic!("the adapter closed its output after {line}");
		}
		let reply = reply.trim();
		if reply == "invalid" {
			return None;
		}
		match reply.parse::<f64>() {
			Ok(x) if x.is_finite() => Some(x),
			_ => {
				eprintln!("remy: adapter reply {reply:?} is not a score; counted invalid");
				None
			}
		}
	};
	let mut best: Option<f64> = None;
	let mut total = 0.0;
	let mut on_guess = |t: usize, g: &Guess| {
		if let Some(s) = g.score {
			best = Some(best.map_or(s, |b: f64| b.min(s)));
		}
		total += g.secs;
		let f = |x: Option<f64>| x.map(|v| format!("{v}")).unwrap_or_default();
		writeln!(w, "{t}\t{}\t{}\t{}\t{}\t{:.6}", sp.config_text(&g.cfg), f(g.score), f(best), g.score.is_some() as u8, g.secs).unwrap();
		w.flush().ok();
	};
	remy.run(&mut measure, &mut on_guess);
	writeln!(w, "# finished {}; propose seconds total {total:.6}; best {}; repeats {}; nonfinite steps {}; fallbacks {}", utc_now(), best.map(|b| b.to_string()).unwrap_or("none".into()), remy.diag.repeats, remy.diag.nonfinite, remy.diag.fallbacks).unwrap();
	drop(to);
	let _ = child.wait();
	eprintln!("remy: wrote {out}; best {best:?}; propose seconds total {total:.3}");
	Ok(())
}

fn cmd_first_guess(a: &Args) -> Result<(), String> {
	let path = a.pos.get(1).ok_or("usage: remy first-guess <space.json>")?;
	let space = Space::load(path)?;
	let cfg = space.first_guess(SEED);
	println!("{}", space.config_text(&cfg));
	for (k, kn) in space.knobs.iter().enumerate() {
		let how = match kn.kind {
			remy_core::space::Kind::Categorical => "seeded pick",
			_ => "median",
		};
		match cfg[k] {
			Some(o) => eprintln!("  {} = {} ({how}; option {} of {})", kn.name, kn.text[o], o + 1, kn.n()),
			None => eprintln!("  {} inactive", kn.name),
		}
	}
	Ok(())
}

fn cmd_sample(a: &Args) -> Result<(), String> {
	let id: u64 = a.pos.get(1).ok_or("usage: remy sample <id>")?.parse().map_err(|_| "bad id")?;
	let p = Problem::new(id);
	match a.get("out") {
		Some(dir) => {
			std::fs::create_dir_all(dir).map_err(|e| e.to_string())?;
			std::fs::write(format!("{dir}/space.json"), p.space_json()).map_err(|e| e.to_string())?;
			eprintln!("wrote {dir}/space.json ({} knobs; known optimum score {})", p.space.k(), p.optimum());
		}
		None => print!("{}", p.space_json()),
	}
	Ok(())
}

fn ids(a: &Args, from: u64, count: usize) -> Vec<u64> {
	let from: u64 = a.num("from", from);
	let count: usize = a.num("count", count);
	(from..from + count as u64).collect()
}

fn sign_test(wins: usize, losses: usize) -> f64 {
	// two-sided binomial p-value with p = 1/2 over the non-tied pairs
	let n = wins + losses;
	if n == 0 {
		return 1.0;
	}
	let k = wins.min(losses);
	let mut lc = vec![0.0f64; n + 1];
	for i in 1..=n {
		lc[i] = lc[i - 1] + (i as f64).ln();
	}
	let mut p = 0.0;
	for i in 0..=k {
		p += (lc[n] - lc[i] - lc[n - i] - n as f64 * 2f64.ln()).exp();
	}
	(2.0 * p).min(1.0)
}

fn summarize_remy(name: &str, runs: &[RunStats]) {
	let pct: Vec<f64> = runs.iter().map(|r| r.pct).collect();
	let ent: Vec<f64> = runs.iter().map(|r| r.entropy).collect();
	let secs: Vec<f64> = runs.iter().flat_map(|r| r.secs[1..].iter().cloned()).collect();
	let first: Vec<f64> = runs.iter().map(|r| r.secs[0]).collect();
	let per_run: Vec<f64> = runs.iter().map(|r| r.secs.iter().sum()).collect();
	let repeats: usize = runs.iter().map(|r| r.diag.repeats).sum();
	let nonfinite: usize = runs.iter().map(|r| r.diag.nonfinite).sum();
	let fallbacks: usize = runs.iter().map(|r| r.diag.fallbacks).sum();
	let nan_best = runs.iter().filter(|r| r.best.is_some_and(|b| b.is_nan())).count();
	println!("== {name}: {} problems", runs.len());
	println!("  mean best percentile {:.4} (median {:.4}, min {:.4})", mean(&pct), quantile(&pct, 0.5), quantile(&pct, 0.0));
	println!("  repeated guesses {repeats}; non-finite training steps {nonfinite}; NaN best scores {nan_best}; decode fallbacks {fallbacks}");
	println!("  final exploration entropy: mean {:.4}, min {:.4}; runs with entropy 0: {}", mean(&ent), quantile(&ent, 0.0), ent.iter().filter(|&&e| e <= 0.0).count());
	let with: Vec<&RunStats> = runs.iter().filter(|r| r.region).collect();
	let share = |rs: &[&RunStats], lo: usize, hi: usize| {
		let mut bad = 0;
		let mut all = 0;
		for r in rs {
			for t in lo..hi.min(r.invalid.len()) {
				all += 1;
				bad += r.invalid[t] as usize;
			}
		}
		bad as f64 / all.max(1) as f64
	};
	println!(
		"  invalid share on the {} problems with an invalid region: guesses 1-8 {:.4}, 9-16 {:.4}, 17-24 {:.4}; 1-12 {:.4}, 13-24 {:.4}",
		with.len(),
		share(&with, 0, 8),
		share(&with, 8, 16),
		share(&with, 16, 24),
		share(&with, 0, 12),
		share(&with, 12, 24)
	);
	println!(
		"  t_propose per guess (guesses 2-24): mean {:.4} s, median {:.4} s, p95 {:.4} s, max {:.4} s; first guess mean {:.6} s; per run total mean {:.3} s",
		mean(&secs),
		quantile(&secs, 0.5),
		quantile(&secs, 0.95),
		quantile(&secs, 1.0),
		mean(&first),
		mean(&per_run)
	);
}

fn cmd_synth(a: &Args) -> Result<(), String> {
	let ids = ids(a, VALID_MIN, 50);
	let st = settings(a);
	let th = eval::threads();
	let techniques: Vec<String> = a.get("technique").unwrap_or("none").split(',').map(|s| s.to_string()).collect();
	let ts = tasks(&ids, th);
	println!("# synthetic runs: problems {}..={} ({}), seed {SEED}, settings {}", ids[0], ids[ids.len() - 1], ids.len(), st.describe());
	let mut columns: Vec<(String, Vec<f64>)> = Vec::new();
	let mut details: Vec<(String, Vec<RunStats>)> = Vec::new();
	for t in &techniques {
		if t == "gp" {
			let start = std::time::Instant::now();
			let pct: Vec<f64> = parallel(ts.len(), th, |i| {
				let task = &ts[i];
				let space = &task.p.space;
				let mut measure = |c: &Config| task.p.score(&space.values(c));
				let h = remy_core::gp::gp_run(space, st.guesses, SEED, &mut measure);
				let b = h.iter().filter_map(|x| x.1).min_by(f64::total_cmp);
				percentile(b, &task.reference)
			});
			println!("== gp (Gaussian-process bandit, a stand-in for Vizier): mean best percentile {:.4} (median {:.4}, min {:.4}); wall {:.1} s", mean(&pct), quantile(&pct, 0.5), pct.iter().cloned().fold(1.0, f64::min), start.elapsed().as_secs_f64());
			columns.push(("gp".into(), pct));
			continue;
		}
		if t == "random" {
			let r = parallel(ts.len(), th, |i| random_search(&ts[i], 20, st.guesses));
			let pct: Vec<f64> = r.iter().map(|x| x.0).collect();
			let inv: Vec<f64> = ts.iter().zip(&r).filter(|(t, _)| t.p.has_invalid_region()).map(|(_, x)| x.1).collect();
			println!("== random search (uniform over the reference, 20 runs per problem): mean best percentile {:.4} (median {:.4}); invalid share on problems with an invalid region {:.4}", mean(&pct), quantile(&pct, 0.5), mean(&inv));
			columns.push(("random".into(), pct));
		} else {
			let (models, wdesc) = load_models(t, a)?;
			let start = std::time::Instant::now();
			let runs: Vec<RunStats> = parallel(ts.len(), th, |i| remy_run(&ts[i], &models, &st).0);
			println!("# {t}: weights {wdesc}; wall {:.1} s on {th} threads", start.elapsed().as_secs_f64());
			summarize_remy(&format!("remy {t}"), &runs);
			columns.push((t.clone(), runs.iter().map(|r| r.pct).collect()));
			details.push((t.clone(), runs));
		}
	}
	for i in 0..columns.len() {
		for j in i + 1..columns.len() {
			let (na, va) = &columns[i];
			let (nb, vb) = &columns[j];
			let (mut w, mut l, mut tie) = (0, 0, 0);
			let d: Vec<f64> = va.iter().zip(vb).map(|(x, y)| x - y).collect();
			for x in &d {
				if *x > 1e-12 {
					w += 1
				} else if *x < -1e-12 {
					l += 1
				} else {
					tie += 1
				}
			}
			let sd = (d.iter().map(|x| (x - mean(&d)).powi(2)).sum::<f64>() / (d.len().max(2) - 1) as f64).sqrt();
			println!(
				"== {na} vs {nb}: mean percentile {:.4} vs {:.4}, difference {:+.4} (standard error {:.4}); {na} higher on {w}, lower on {l}, tied on {tie}; sign test p = {:.3}",
				mean(va),
				mean(vb),
				mean(&d),
				sd / (d.len() as f64).sqrt(),
				sign_test(w, l)
			);
		}
	}
	if let Some(out) = a.get("out") {
		let mut f = std::fs::File::create(out).map_err(|e| e.to_string())?;
		writeln!(f, "# remy synth, seed {SEED}, settings {}", st.describe()).unwrap();
		write!(f, "id\tknobs\tregion").unwrap();
		for (n, _) in &columns {
			write!(f, "\t{n}_pct").unwrap();
		}
		for (n, _) in &details {
			write!(f, "\t{n}_best\t{n}_invalid\t{n}_entropy\t{n}_propose_s").unwrap();
		}
		writeln!(f).unwrap();
		for (i, t) in ts.iter().enumerate() {
			write!(f, "{}\t{}\t{}", t.p.id, t.p.space.k(), t.p.has_invalid_region() as u8).unwrap();
			for (_, v) in &columns {
				write!(f, "\t{:.5}", v[i]).unwrap();
			}
			for (_, runs) in &details {
				let r = &runs[i];
				write!(f, "\t{}\t{}\t{:.4}\t{:.4}", r.best.map(|b| b.to_string()).unwrap_or_default(), r.invalid.iter().filter(|&&x| x).count(), r.entropy, r.secs.iter().sum::<f64>()).unwrap();
			}
			writeln!(f).unwrap();
		}
		// per-guess traces, for inspection
		for (n, runs) in &details {
			let path = format!("{out}.{n}.guesses.tsv");
			let mut g = std::fs::File::create(&path).map_err(|e| e.to_string())?;
			writeln!(g, "id\tguess\tconfig\tscore\tvalid\tpropose_seconds").unwrap();
			for (i, r) in runs.iter().enumerate() {
				for (t, x) in r.guesses.iter().enumerate() {
					writeln!(g, "{}\t{}\t{}\t{}\t{}\t{:.5}", r.id, t + 1, ts[i].p.space.config_text(&x.cfg), x.score.map(|s| s.to_string()).unwrap_or_default(), x.score.is_some() as u8, x.secs).unwrap();
				}
			}
		}
	}
	Ok(())
}

fn cmd_pretrain(a: &Args) -> Result<(), String> {
	if a.get("method").unwrap_or("meta") == "meta" {
		return cmd_pretrain_meta(a);
	}
	let st = settings(a);
	let from: u64 = a.num("stop-from", 950_000);
	let n: usize = a.num("stop-count", 64);
	let cfg = PretrainCfg {
		meta_batch: a.num("meta-batch", 16),
		beta: a.num("beta", 0.5),
		eval_every: a.num("eval-every", 10),
		patience: a.num("patience", 8),
		max_iters: a.num("max-iters", 100_000),
		stop_ids: (from..from + n as u64).collect(),
	};
	let out = a.get("out").unwrap_or(DEFAULT_WEIGHTS).to_string();
	let log = a.get("log").map(|s| s.to_string()).unwrap_or(format!("{}/logs/pretrain.tsv", env!("CARGO_MANIFEST_DIR")));
	let start = std::time::Instant::now();
	pretrain(&cfg, &st, &out, &log, eval::threads());
	println!("pretraining done in {:.1} s; weights {out} sha256 {}; log {log}", start.elapsed().as_secs_f64(), sha256::file_hex(&out).map_err(|e| e.to_string())?);
	Ok(())
}

fn partial_run<'a>(task: &'a Task, models: &Models, st: &Settings, guesses: usize) -> (Remy<'a>, Vec<Guess>) {
	let space = &task.p.space;
	let mut remy = Remy::new(space, models.clone(), st.clone());
	let mut hist: Vec<Guess> = Vec::new();
	for _ in 0..guesses {
		let cfg = remy.propose(&hist);
		let score = task.p.score(&space.values(&cfg));
		hist.push(Guess { cfg, score, secs: 0.0 });
	}
	(remy, hist)
}

fn cmd_grad_report(a: &Args) -> Result<(), String> {
	let ids = ids(a, 1000, 20);
	let st = settings(a);
	let th = eval::threads();
	let technique = a.get("technique").unwrap_or("none");
	let (models, wdesc) = load_models(technique, a)?;
	let ts = tasks(&ids, th);
	println!("# Linguini loss terms: gradient sizes (global L2 norm over Linguini's parameters) at the first Linguini step of each guess");
	println!("# technique {technique} (weights {wdesc}); training problems {}..={}; settings {}", ids[0], ids[ids.len() - 1], st.describe());
	let probes: Vec<Vec<[f64; 7]>> = parallel(ts.len(), th, |i| {
		let space = &ts[i].p.space;
		let mut remy = Remy::new(space, models.clone(), st.clone());
		remy.probe = Some(Vec::new());
		let mut measure = |cfg: &Config| ts[i].p.score(&space.values(cfg));
		remy.run(&mut measure, &mut |_, _| {});
		remy.probe.unwrap()
	});
	let names = ["s_hat", "-ln P_valid", "-lambda*H"];
	for (lo, hi, label) in [(0usize, 23usize, "guesses 2-24"), (0, 7, "guesses 2-8"), (7, 15, "guesses 9-16"), (15, 23, "guesses 17-24")] {
		println!("  {label}:");
		for t in 0..3 {
			let g: Vec<f64> = probes.iter().flat_map(|p| p[lo.min(p.len())..hi.min(p.len())].iter().map(move |x| x[t])).collect();
			let v: Vec<f64> = probes.iter().flat_map(|p| p[lo.min(p.len())..hi.min(p.len())].iter().map(move |x| x[t + 3])).collect();
			println!("    {:12} gradient norm median {:.3e}, mean {:.3e}, p10 {:.3e}, p90 {:.3e}; term value mean {:+.4}", names[t], quantile(&g, 0.5), mean(&g), quantile(&g, 0.1), quantile(&g, 0.9), mean(&v));
		}
	}
	let ratio = |a: usize, b: usize| {
		let r: Vec<f64> = probes.iter().flat_map(|p| p.iter().filter(|x| x[b] > 0.0).map(move |x| x[a] / x[b])).collect();
		quantile(&r, 0.5)
	};
	for (flag, label) in [(1.0, "guesses whose history holds an invalid guess"), (0.0, "guesses whose history is all valid")] {
		let sel: Vec<[f64; 7]> = probes.iter().flatten().filter(|x| x[6] == flag).cloned().collect();
		println!("  {label} ({}):", sel.len());
		for t in 0..3 {
			let g: Vec<f64> = sel.iter().map(|x| x[t]).collect();
			println!("    {:12} gradient norm median {:.3e}, mean {:.3e}, p10 {:.3e}, p90 {:.3e}", names[t], quantile(&g, 0.5), mean(&g), quantile(&g, 0.1), quantile(&g, 0.9));
		}
		let r: Vec<f64> = sel.iter().filter(|x| x[0] > 0.0).map(|x| x[1] / x[0]).collect();
		let r2: Vec<f64> = sel.iter().filter(|x| x[0] > 0.0).map(|x| x[2] / x[0]).collect();
		println!("    per-guess ratio to s_hat: -ln P_valid median {:.3e} (p90 {:.3e}), -lambda*H median {:.3e} (p90 {:.3e})", quantile(&r, 0.5), quantile(&r, 0.9), quantile(&r2, 0.5), quantile(&r2, 0.9));
	}
	println!("  median per-guess ratios: s_hat / -lnP {:.3e}, s_hat / -lambda*H {:.3e}, -lnP / -lambda*H {:.3e}", ratio(0, 1), ratio(0, 2), ratio(1, 2));
	// finite-difference checks of each term's straight-through gradient
	println!("# finite-difference check (central, h = 1e-5) of each term's gradient through the straight-through decode; 2 coordinates of every Linguini parameter tensor");
	let fd_tasks: Vec<usize> = (0..ts.len().min(a.num("fd-problems", 4))).collect();
	let mut worst = [0.0f64; 3];
	let mut worst_big = [0.0f64; 3];
	let mut sign_bad = [0usize; 3];
	let mut checked = [0usize; 3];
	let mut bias_checked = [0usize; 3];
	for &i in &fd_tasks {
		for at in [6usize, 16] {
			let (mut remy, hist) = partial_run(&ts[i], &models, &st, at);
			remy.train_rats_on(&hist);
			let rows = remy.check_term_gradients(&hist, 2);
			for (term, name, j, an, num) in rows {
				let scale = an.abs().max(num.abs());
				if scale < 1e-9 {
					continue;
				}
				let rel = (an - num).abs() / scale;
				worst[term] = worst[term].max(rel);
				if scale > 1e-6 {
					worst_big[term] = worst_big[term].max(rel);
				}
				checked[term] += 1;
				if an.signum() != num.signum() && scale > 1e-7 {
					sign_bad[term] += 1;
				}
				if name.ends_with("_b") || name.starts_with("null") {
					bias_checked[term] += 1;
				}
				if a.get("fd-verbose").is_some() {
					println!("    problem {} at guess {at}: {} {name}[{j}] analytic {an:+.6e} numeric {num:+.6e} rel {rel:.2e}", ts[i].p.id, names[term]);
				}
			}
		}
	}
	for t in 0..3 {
		println!("  {:12} {} coordinates checked ({} in bias or null parameters): max relative error {:.2e} (where |gradient| > 1e-6: {:.2e}), sign disagreements {}", names[t], checked[t], bias_checked[t], worst[t], worst_big[t], sign_bad[t]);
	}
	Ok(())
}

fn cmd_sampler_stats(a: &Args) -> Result<(), String> {
	let ids = ids(a, 1, 1000);
	let th = eval::threads();
	struct S {
		k: usize,
		valid: f64,
		first_better: f64,
		exhaustive: bool,
		cond: bool,
		region: bool,
		types: [usize; 4],
	}
	let rows = parallel(ids.len(), th, |i| {
		let t = Task::new(ids[i]);
		let sp = &t.p.space;
		let valid = t.reference.iter().filter(|x| x.is_finite()).count() as f64 / t.reference.len() as f64;
		let fg = t.p.score(&sp.values(&sp.first_guess(SEED))).unwrap_or(f64::INFINITY);
		let first_better = t.reference.iter().filter(|&&x| x < fg).count() as f64 / t.reference.len() as f64;
		let mut types = [0; 4];
		for kn in &sp.knobs {
			types[match kn.kind {
				remy_core::space::Kind::Float { log: false, .. } => 0,
				remy_core::space::Kind::Float { log: true, .. } => 1,
				remy_core::space::Kind::Ordinal | remy_core::space::Kind::Int { .. } => 2,
				remy_core::space::Kind::Categorical => 3,
			}] += 1;
		}
		S { k: sp.k(), valid, first_better, exhaustive: t.reference.len() != remy_core::sampler::REF_SAMPLE, cond: sp.knobs.iter().any(|k| k.cond.is_some()), region: t.p.has_invalid_region(), types }
	});
	let n = rows.len() as f64;
	let ks: Vec<f64> = rows.iter().map(|r| r.k as f64).collect();
	let vs: Vec<f64> = rows.iter().map(|r| r.valid).collect();
	println!("# sampler problems {}..={} ({})", ids[0], ids[ids.len() - 1], rows.len());
	println!("  knobs: mean {:.2}, min {}, max {}", mean(&ks), quantile(&ks, 0.0), quantile(&ks, 1.0));
	let tt: Vec<usize> = (0..4).map(|j| rows.iter().map(|r| r.types[j]).sum()).collect();
	println!("  knob types: continuous linear {}, continuous log {}, ordinal {}, categorical {}", tt[0], tt[1], tt[2], tt[3]);
	println!("  problems with conditional knobs {:.3}, with an invalid region {:.3}, with an exhaustive reference {:.3}", rows.iter().filter(|r| r.cond).count() as f64 / n, rows.iter().filter(|r| r.region).count() as f64 / n, rows.iter().filter(|r| r.exhaustive).count() as f64 / n);
	println!("  valid share of the reference: mean {:.3}, min {:.3}; problems under 20% valid: {}", mean(&vs), quantile(&vs, 0.0), vs.iter().filter(|&&v| v < 0.2).count());
	println!("  first guess (median configuration) in the best 5% of the reference: {} of {} problems", rows.iter().filter(|r| r.first_better < 0.05).count(), rows.len());
	Ok(())
}

fn fd_check(name: &str, shapes: &[(usize, usize)], positive: bool, f: impl Fn(&mut Tape, &[usize]) -> usize) -> f64 {
	let mut rng = Rng::new(mix(SEED, remy_core::rng::hash_str(name)));
	let vals: Vec<T> = shapes.iter().map(|&(r, c)| T::new(r, c, (0..r * c).map(|_| if positive { rng.range(0.2, 2.0) } else { rng.normal() }).collect())).collect();
	let eval = |vals: &[T]| {
		let mut tp = Tape::new();
		let ids: Vec<usize> = vals.iter().enumerate().map(|(i, v)| tp.param(v.clone(), i)).collect();
		let out = f(&mut tp, &ids);
		(tp.val(out).v[0], tp)
	};
	let (_, tp) = eval(&vals);
	let mut tp2 = Tape::new();
	let ids: Vec<usize> = vals.iter().enumerate().map(|(i, v)| tp2.param(v.clone(), i)).collect();
	let out = f(&mut tp2, &ids);
	let _ = tp;
	let grads = tp2.backward(out);
	let mut worst: f64 = 0.0;
	for (pi, v) in vals.iter().enumerate() {
		let an: Vec<f64> = grads.iter().filter(|(i, _)| *i == pi).fold(vec![0.0; v.v.len()], |mut acc, (_, g)| {
			acc.iter_mut().zip(&g.v).for_each(|(a, b)| *a += b);
			acc
		});
		for j in 0..v.v.len() {
			let h = 1e-6;
			let mut p = vals.to_vec();
			p[pi].v[j] += h;
			let mut m = vals.to_vec();
			m[pi].v[j] -= h;
			let num = (eval(&p).0 - eval(&m).0) / (2.0 * h);
			let rel = (an[j] - num).abs() / an[j].abs().max(num.abs()).max(1e-6);
			worst = worst.max(rel);
		}
	}
	println!("  {name:20} max relative error {worst:.2e}");
	worst
}

fn cmd_selftest() -> Result<(), String> {
	let mut ok = true;
	println!("# sha256(\"abc\") = {}", sha256::hex(b"abc"));
	ok &= sha256::hex(b"abc") == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
	println!("# tape operations: analytic vs central finite differences");
	let mut worst: f64 = 0.0;
	worst = worst.max(fd_check("matmul", &[(3, 4), (4, 2)], false, |t, p| {
		let m = t.matmul(p[0], p[1]);
		let s = t.square(m);
		t.sum(s)
	}));
	worst = worst.max(fd_check("matmul_t+transpose", &[(3, 4), (2, 4)], false, |t, p| {
		let m = t.matmul_t(p[0], p[1]);
		let tr = t.transpose(m);
		let g = t.gelu(tr);
		t.sum(g)
	}));
	worst = worst.max(fd_check("add/sub/mul", &[(2, 3), (2, 3), (2, 3)], false, |t, p| {
		let a = t.add(p[0], p[1]);
		let b = t.sub(a, p[2]);
		let c = t.mul(b, p[0]);
		let c = t.scale(c, 0.3);
		let d = t.tanh(c);
		t.sum(d)
	}));
	worst = worst.max(fd_check("add_row/add_col/mul_col", &[(3, 4), (1, 4), (3, 1), (3, 1)], false, |t, p| {
		let a = t.add_row(p[0], p[1]);
		let b = t.add_col(a, p[2]);
		let c = t.mul_col(b, p[3]);
		let s = t.sigmoid(c);
		t.sum(s)
	}));
	worst = worst.max(fd_check("mul_scalar/scale", &[(2, 3), (1, 1)], false, |t, p| {
		let a = t.mul_scalar(p[0], p[1]);
		let b = t.scale(a, -0.7);
		let c = t.softplus(b);
		t.sum(c)
	}));
	worst = worst.max(fd_check("ln", &[(2, 3)], true, |t, p| {
		let a = t.ln(p[0]);
		let b = t.mul(a, p[0]);
		t.sum(b)
	}));
	worst = worst.max(fd_check("softmax_rows", &[(3, 5), (3, 5)], false, |t, p| {
		let a = t.softmax_rows(p[0]);
		let b = t.mul(a, p[1]);
		t.sum(b)
	}));
	worst = worst.max(fd_check("row_sq", &[(3, 4), (3, 1)], false, |t, p| {
		let a = t.row_sq(p[0]);
		let b = t.mul(a, p[1]);
		t.sum(b)
	}));
	worst = worst.max(fd_check("concat/slice", &[(2, 3), (2, 2), (1, 5)], false, |t, p| {
		let a = t.concat_cols(&[p[0], p[1]]);
		let b = t.concat_rows(&[a, p[2]]);
		let c = t.slice_rows(b, 1, 2);
		let d = t.square(c);
		let e = t.mul(d, c);
		t.sum(e)
	}));
	worst = worst.max(fd_check("shift/blocks/broadcast", &[(6, 2), (1, 4), (3, 4)], false, |t, p| {
		let a = t.shift_rows(p[0], 2);
		let b = t.shift_rows(p[0], -1);
		let c = t.add(a, b);
		let d = t.blocks_to_cols(c, 2);
		let e = t.broadcast_rows(p[1], 3);
		let f = t.add(d, e);
		let g = t.mul(f, p[2]);
		let h = t.gelu(g);
		t.sum(h)
	}));
	worst = worst.max(fd_check("exp", &[(2, 3)], false, |t, p| {
		let a = t.scale(p[0], 0.5);
		let b = t.exp(a);
		let c = t.mul(b, p[0]);
		t.sum(c)
	}));
	worst = worst.max(fd_check("standardize_rows", &[(3, 5), (3, 5)], false, |t, p| {
		let a = t.standardize_rows(p[0], 1e-6);
		let b = t.mul(a, p[1]);
		let c = t.softmax_rows(b);
		let d = t.mul(c, p[1]);
		t.sum(d)
	}));
	println!("  worst {worst:.2e}");
	ok &= worst < 1e-5;
	// RAT training losses: gradient with respect to every RAT parameter
	println!("# RAT training losses: analytic vs finite differences over every parameter tensor (3 coordinates each)");
	let task = Task::new(VALID_MIN + 7);
	for kind in [RatKind::Score, RatKind::Validity] {
		let mut m = Models::new(SEED);
		let rat = if kind == RatKind::Score { &mut m.srat } else { &mut m.vrat };
		let mut rng = Rng::new(9);
		for v in rat.ps.live.iter_mut() {
			for x in v.iter_mut() {
				*x = 0.1 * rng.normal();
			}
		}
		let space = &task.p.space;
		let mut r = Rng::new(3);
		let hist: Vec<Config> = (0..9).map(|_| space.random_config(&mut r)).collect();
		let scores: Vec<Option<f64>> = hist.iter().map(|c| task.p.score(&space.values(c))).collect();
		let ctx = remy_core::model::Ctx::new(space);
		let refs: Vec<&Config> = hist.iter().collect();
		let b = ctx.encode(&refs);
		let n = hist.len();
		let sig = T::new(n, 3, (0..3 * n).map(|_| r.normal() * 0.3).collect());
		let chan: Vec<f64> = scores.iter().map(|s| if s.is_some() { r.normal() * 0.5 } else { -1.0 }).collect();
		let valid: Vec<bool> = scores.iter().map(|s| s.is_some()).collect();
		let rh = remy_core::model::RatHist { b: b.clone(), sig, chan, valid, n };
		let target: Vec<f64> = (0..n).map(|_| r.normal()).collect();
		let loss = |rat: &remy_core::model::Rat, tp: &mut Tape, trainable: bool| {
			let p = rat.ps.nodes(tp, trainable);
			let c = tp.constant(b.clone());
			let out = rat.forward(tp, &p, &ctx, c, n, &rh, true);
			let tg = tp.constant(T::new(n, 1, target.clone()));
			let d = tp.sub(out, tg);
			let s = tp.square(d);
			tp.sum(s)
		};
		let mut tp = Tape::new();
		let out = loss(rat, &mut tp, true);
		let grads = tp.backward(out);
		let mut w: f64 = 0.0;
		let mut checked = 0;
		for pi in 0..rat.ps.names.len() {
			let an = grads.iter().find(|(i, _)| *i == pi).map(|(_, t)| t.v.clone()).unwrap_or(vec![0.0; rat.ps.live[pi].len()]);
			let nz: Vec<usize> = (0..an.len()).filter(|&j| an[j] != 0.0).collect();
			for c in 0..3.min(an.len()) {
				let j = if nz.is_empty() { (c * 7919) % an.len() } else { nz[(c * 7919) % nz.len()] };
				let base = rat.ps.live[pi][j];
				let h = 1e-6;
				rat.ps.live[pi][j] = base + h;
				let mut t1 = Tape::new();
				let o1 = loss(rat, &mut t1, false);
				let plus = t1.val(o1).v[0];
				rat.ps.live[pi][j] = base - h;
				let mut t2 = Tape::new();
				let o2 = loss(rat, &mut t2, false);
				let minus = t2.val(o2).v[0];
				rat.ps.live[pi][j] = base;
				let num = (plus - minus) / (2.0 * h);
				let rel = (an[j] - num).abs() / an[j].abs().max(num.abs()).max(1e-6);
				w = w.max(rel);
				checked += 1;
			}
		}
		println!("  {kind:?} RAT: {checked} coordinates, max relative error {w:.2e}");
		ok &= w < 1e-4;
	}
	// exploration entropy end points
	let even: Vec<f64> = (0..9).map(|i| i as f64 / 8.0).collect();
	let same = vec![0.3; 9];
	let ce = remy_core::space::continuous_entropy(&even);
	let cs = remy_core::space::continuous_entropy(&same);
	let de = remy_core::space::discrete_entropy(&[2.0, 2.0, 2.0]);
	let ds = remy_core::space::discrete_entropy(&[6.0, 0.0, 0.0]);
	let mut rr = Rng::new(5);
	let worst_rand = (0..2000).map(|_| { let n = 2 + rr.below(23); let v: Vec<f64> = (0..n).map(|_| rr.f64()).collect(); remy_core::space::continuous_entropy(&v) }).fold(0.0f64, f64::max);
	println!("# exploration entropy: continuous evenly spread {ce:.6}, identical {cs:.6}, max over 2000 random sets {worst_rand:.4}; options evenly spread {de:.6}, identical {ds:.6}");
	ok &= (ce - 1.0).abs() < 1e-9 && cs.abs() < 1e-12 && worst_rand <= 1.0 + 1e-9 && (de - 1.0).abs() < 1e-12 && ds == 0.0;
	// the continuous entropy node against finite differences in the candidate's position
	{
		let sp = Space::from_json(&remy_core::json::parse(r#"{"knobs": [{"name": "a", "type": "float", "low": 0, "high": 1}]}"#).unwrap()).unwrap();
		let mut worst: f64 = 0.0;
		let mut rr = Rng::new(17);
		for _ in 0..200 {
			let n = 1 + rr.below(10);
			let grid = rr.chance(0.5);
			let q = |x: f64| if grid { (x * 20.0).round() / 20.0 } else { (x * 1000.0).round() / 1000.0 };
			let us: Vec<f64> = (0..n).map(|_| q(rr.f64())).collect();
			let ux = if grid { q(rr.f64()) } else { rr.f64() };
			let kh = vec![remy_core::model::KnobHist { counts: vec![], us: us.clone() }];
			let f = |x: f64| {
				let mut tp = Tape::new();
				let u = tp.param(T::scalar(x), 0);
				let h = remy_core::model::entropy_node(&mut tp, &sp, &kh, &[remy_core::model::KnobIn::Cont(u)]).unwrap();
				let g = tp.backward(h);
				(tp.val(h).v[0], g.first().map(|(_, t)| t.v[0]).unwrap_or(0.0))
			};
			let (v0, an) = f(ux);
			let mut all = us.clone();
			all.push(ux);
			let exact = remy_core::space::continuous_entropy(&all);
			let hh: f64 = std::env::var("DBG_H").ok().and_then(|s| s.parse().ok()).unwrap_or(1e-7);
			let num = (f(ux + hh).0 - f(ux - hh).0) / (2.0 * hh);
			let rel = (an - num).abs() / an.abs().max(num.abs()).max(1e-4);
			if rel > 1e-3 && std::env::var("DBG_ENT").is_ok() {
				eprintln!("us {us:?} ux {ux} analytic {an} numeric {num}");
			}
			worst = worst.max(rel).max((v0 - exact).abs());
		}
		println!("# continuous entropy node: value vs space::continuous_entropy and gradient vs finite differences, 200 random cases (half on a 0.05 grid with ties): worst {worst:.2e}");
		ok &= worst < 1e-4;
	}
	// decode never repeats
	println!("# decoding rejects past guesses");
	let space = &task.p.space;
	let logp: Vec<Vec<(usize, f64)>> = space.knobs.iter().map(|k| (0..k.n()).map(|o| (o, -(o as f64))).collect()).collect();
	let mut seen = std::collections::HashSet::new();
	let mut distinct = true;
	for _ in 0..200 {
		let (c, _) = remy_core::model::decode(space, &logp, &seen, 1);
		distinct &= seen.insert(c);
	}
	println!("  200 decodes from fixed probabilities, all distinct: {distinct}");
	ok &= distinct;
	// determinism: the same problem twice gives the same guesses
	let st = Settings { guesses: 6, ..Settings::default() };
	let m = Models::new(SEED);
	let (a1, _) = remy_run(&task, &m, &st);
	let (a2, _) = remy_run(&task, &m, &st);
	let same = a1.guesses.iter().zip(&a2.guesses).all(|(x, y)| x.cfg == y.cfg);
	println!("# determinism: two 6-guess runs on problem {} give the same guesses: {same}", task.p.id);
	ok &= same;
	let _ = tape::softplus(0.0);
	println!("{}", if ok { "selftest PASS" } else { "selftest FAIL" });
	if ok { Ok(()) } else { Err("selftest failed".into()) }
}

fn main() {
	let argv: Vec<String> = std::env::args().skip(1).collect();
	let a = Args::parse(&argv);
	let cmd = a.pos.first().cloned().unwrap_or_default();
	let r = match cmd.as_str() {
		"run" => cmd_run(&a),
		"first-guess" => cmd_first_guess(&a),
		"sample" => cmd_sample(&a),
		"problem" => {
			let id: u64 = a.pos.get(1).and_then(|s| s.parse().ok()).expect("usage: remy problem <id>");
			Problem::new(id).serve();
			Ok(())
		}
		"synth" => cmd_synth(&a),
		"pretrain" => cmd_pretrain(&a),
		"grad-report" => cmd_grad_report(&a),
		"sampler-stats" => cmd_sampler_stats(&a),
		"rat-report" => cmd_rat_report(&a),
		"selftest" => cmd_selftest(),
		_ => Err("usage: remy run|first-guess|sample|problem|synth|pretrain|grad-report|sampler-stats|selftest (see src/main.rs)".into()),
	};
	if let Err(e) = r {
		eprintln!("remy: {e}");
		std::process::exit(1);
	}
	let _ = percentile;
}

fn ranks(v: &[f64]) -> Vec<f64> {
	let mut idx: Vec<usize> = (0..v.len()).collect();
	idx.sort_by(|&a, &b| v[a].total_cmp(&v[b]));
	let mut r = vec![0.0; v.len()];
	let mut i = 0;
	while i < idx.len() {
		let mut j = i;
		while j + 1 < idx.len() && v[idx[j + 1]] == v[idx[i]] {
			j += 1;
		}
		for t in i..=j {
			r[idx[t]] = (i + j) as f64 / 2.0;
		}
		i = j + 1;
	}
	r
}

fn spearman(a: &[f64], b: &[f64]) -> f64 {
	let (ra, rb) = (ranks(a), ranks(b));
	let (ma, mb) = (mean(&ra), mean(&rb));
	let cov: f64 = ra.iter().zip(&rb).map(|(x, y)| (x - ma) * (y - mb)).sum();
	let va: f64 = ra.iter().map(|x| (x - ma).powi(2)).sum();
	let vb: f64 = rb.iter().map(|y| (y - mb).powi(2)).sum();
	if va == 0.0 || vb == 0.0 { 0.0 } else { cov / (va * vb).sqrt() }
}

/// How well the RATs predict fresh configurations: the score RAT's rank correlation with the true score, and the
/// validity RAT's AUC, on 300 random grid configurations, after the RATs train on a run's first t guesses.
fn cmd_rat_report(a: &Args) -> Result<(), String> {
	let ids = ids(a, 1, 32);
	let st = settings(a);
	let th = eval::threads();
	let technique = a.get("technique").unwrap_or("none");
	let (models, _) = load_models(technique, a)?;
	let ts = tasks(&ids, th);
	println!("# RAT quality on 300 random configurations per problem; technique {technique}; problems {}..={}; settings {}", ids[0], ids[ids.len() - 1], st.describe());
	for at in [4usize, 8, 12, 23] {
		let rows = parallel(ts.len(), th, |i| {
			let (mut remy, hist) = partial_run(&ts[i], &models, &st, at);
			remy.train_rats_on(&hist);
			let space = &ts[i].p.space;
			let mut r = Rng::new(mix(ts[i].p.id, 0x7E57));
			let cands: Vec<Config> = (0..300).map(|_| space.random_config(&mut r)).collect();
			let truth: Vec<Option<f64>> = cands.iter().map(|c| ts[i].p.score(&space.values(c))).collect();
			let pred = remy.predict(&hist, &cands);
			let (ps, ts_): (Vec<f64>, Vec<f64>) = pred.iter().zip(&truth).filter_map(|(p, t)| t.map(|t| (p.0, t))).unzip();
			let rho = spearman(&ps, &ts_);
			let pos: Vec<f64> = pred.iter().zip(&truth).filter(|(_, t)| t.is_some()).map(|(p, _)| p.1).collect();
			let neg: Vec<f64> = pred.iter().zip(&truth).filter(|(_, t)| t.is_none()).map(|(p, _)| p.1).collect();
			let auc = if pos.is_empty() || neg.is_empty() || !hist.iter().any(|g| g.score.is_none()) {
				f64::NAN
			} else {
				let mut c = 0.0;
				for p in &pos {
					for q in &neg {
						c += if p > q { 1.0 } else if p == q { 0.5 } else { 0.0 };
					}
				}
				c / (pos.len() * neg.len()) as f64
			};
			let mean_pv = mean(&pred.iter().map(|p| p.1).collect::<Vec<_>>());
			(rho, auc, mean_pv)
		});
		let rho: Vec<f64> = rows.iter().map(|r| r.0).collect();
		let auc: Vec<f64> = rows.iter().map(|r| r.1).filter(|x| x.is_finite()).collect();
		let pv: Vec<f64> = rows.iter().map(|r| r.2).collect();
		println!("  after {at:2} guesses: score RAT Spearman with the true score mean {:.3} (median {:.3}); validity RAT AUC mean {:.3} over {} problems with an invalid guess so far; mean predicted P(valid) {:.3}", mean(&rho), quantile(&rho, 0.5), mean(&auc), auc.len(), mean(&pv));
	}
	Ok(())
}

fn cmd_pretrain_meta(a: &Args) -> Result<(), String> {
	let st = settings(a);
	let from: u64 = a.num("stop-from", 950_000);
	let n: usize = a.num("stop-count", 64);
	let cfg = remy_core::pretrain::MetaPretrainCfg {
		meta_batch: a.num("meta-batch", 16),
		lr: a.num("meta-lr", 0.003),
		clip: a.num("meta-clip", 1.0),
		eval_every: a.num("eval-every", 10),
		patience: a.num("patience", 10),
		max_iters: a.num("max-iters", 100_000),
		stop_ids: (from..from + n as u64).collect(),
		mc: remy_core::remy::MetaCfg { queries: a.num("queries", 16), lin: a.num::<u8>("meta-lin", 1) == 1, rats: a.num::<u8>("meta-rats", 1) == 1 },
	};
	let init = match a.get("init") {
		Some(path) => {
			let mut m = Models::new(SEED);
			m.load_text(&std::fs::read_to_string(path).map_err(|e| format!("{path}: {e}"))?)?;
			m
		}
		None => Models::new(SEED),
	};
	let out = a.get("out").unwrap_or(DEFAULT_WEIGHTS).to_string();
	let log = a.get("log").map(|s| s.to_string()).unwrap_or(format!("{}/logs/pretrain-meta.tsv", env!("CARGO_MANIFEST_DIR")));
	let start = std::time::Instant::now();
	remy_core::pretrain::pretrain_meta(&cfg, &st, init, &out, &log, eval::threads());
	println!("pretraining done in {:.1} s; weights {out} sha256 {}; log {log}", start.elapsed().as_secs_f64(), sha256::file_hex(&out).map_err(|e| e.to_string())?);
	Ok(())
}
