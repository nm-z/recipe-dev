//! The first order's three models: Linguini, the score RAT, and the validity RAT.
//!
//! Every parameter has a fixed value (set by pretraining, or the seeded initialization without it) and a live
//! value (0 at the start of each run, and the only value that learns during a run). The model uses fixed + live.
//!
//! Reading (design, One guess). Each model has an embedding table shared by every challenge: one row per (continuous: space.knobs.iter().map(|kn| kn.continuous()).collect(), ordered: space.knobs.iter().map(|kn| kn.ordered()).collect(), cont_uob
//! position, option) for knobs with options, one "continuous" row per position that a continuous knob's exact value
//! (scaled to [0, 1] on its own scale) multiplies, one "inactive" row per position for an inactive conditional knob,
//! and one row per knob type. A configuration's token is the sum of its knobs' rows (plus the type rows and the
//! challenge's range features); a past guess's token also holds its valid bit and score features. A causal
//! convolution (width 3) runs along the sequence of past guesses followed by the candidate, and one attention head
//! runs between the candidate and the past guesses.

use crate::rng::{Rng, hash_str, mix};
use crate::space::{Config, ENT_DELTA, MAXK, Space, continuous_entropy, discrete_entropy};
use crate::tape::{Id, T, Tape};
use std::collections::{BinaryHeap, HashSet};

/// Embedding width.
pub const D: usize = 32;
/// Attention key width.
pub const DA: usize = 16;
/// Attention value width.
pub const DV: usize = 16;
/// Hidden width of the RATs' output layer.
pub const HID: usize = 32;
/// Score features of a past guess: valid bit, rank score, relative score.
pub const NSIG: usize = 3;
/// Option rows per knob position (an option index at or above this wraps around).
pub const MAXOPT: usize = 40;
/// Rows per knob position: the options, then the inactive row, then the continuous row.
pub const ROWS: usize = MAXOPT + 2;
const INACTIVE: usize = MAXOPT;
const CONT: usize = MAXOPT + 1;
/// Type rows: continuous linear, continuous log, integer, ordinal, categorical, conditional.
pub const NTYPES: usize = 6;
pub const NTABLE: usize = MAXK * ROWS + NTYPES;
const TYPE_BASE: usize = MAXK * ROWS;
/// Linguini's softmax temperature: each knob's logits are standardized across its options, then scaled by
/// this, so a knob's softmax never collapses to one option and the straight-through gradient stays alive.
pub const LOGIT_TEMP: f64 = 1.5;
/// Softmax temperature for ordered knobs (see `Lin::tau_ordered`).
pub const ORDERED_TEMP: f64 = 5.0;
/// A large negative attention logit for masked entries.
const MASKED: f64 = -1e30;

#[derive(Clone, Debug)]
pub struct ParamSet {
	pub model: String,
	pub names: Vec<String>,
	pub shapes: Vec<(usize, usize)>,
	pub fixed: Vec<Vec<f64>>,
	pub live: Vec<Vec<f64>>,
}

enum Init {
	Normal(f64),
	Const(f64),
	Values(Vec<f64>),
}

impl ParamSet {
	fn new(model: &str) -> ParamSet {
		ParamSet { model: model.into(), names: vec![], shapes: vec![], fixed: vec![], live: vec![] }
	}
	fn rng(&self, name: &str, seed: u64) -> Rng {
		Rng::new(mix(seed, hash_str(&format!("{}.{}", self.model, name))))
	}
	fn add(&mut self, name: &str, r: usize, c: usize, init: Init, seed: u64) -> usize {
		let mut rng = self.rng(name, seed);
		let v: Vec<f64> = match init {
			Init::Normal(s) => (0..r * c).map(|_| s * rng.normal()).collect(),
			Init::Const(x) => vec![x; r * c],
			Init::Values(v) => v,
		};
		assert_eq!(v.len(), r * c, "{name} init size");
		self.names.push(name.into());
		self.shapes.push((r, c));
		self.live.push(vec![0.0; v.len()]);
		self.fixed.push(v);
		self.names.len() - 1
	}
	pub fn value(&self, i: usize) -> T {
		let (r, c) = self.shapes[i];
		T::new(r, c, self.fixed[i].iter().zip(&self.live[i]).map(|(f, l)| f + l).collect())
	}
	pub fn reset_live(&mut self) {
		for l in &mut self.live {
			l.iter_mut().for_each(|x| *x = 0.0);
		}
	}
	pub fn count(&self) -> usize {
		self.fixed.iter().map(|v| v.len()).sum()
	}
	/// Load every parameter onto the tape: as trainable parameters, or as constants (a frozen model).
	pub fn nodes(&self, tape: &mut Tape, trainable: bool) -> Vec<Id> {
		(0..self.names.len()).map(|i| if trainable { tape.param(self.value(i), i) } else { tape.constant(self.value(i)) }).collect()
	}
	pub fn finite(&self) -> bool {
		self.fixed.iter().chain(&self.live).all(|v| v.iter().all(|x| x.is_finite()))
	}
}

/// The seeded initialization of an embedding table. Option rows of a position vary smoothly with the option index
/// (a Gaussian-process draw over the index, length scale 2, plus independent noise), so neighboring options of an
/// ordered knob start out similar; the inactive, continuous and type rows are independent draws.
fn table_init(rng: &mut Rng) -> Vec<f64> {
	let s = 0.5;
	let mut v = vec![0.0; NTABLE * D];
	let feats = 64;
	for k in 0..MAXK {
		for c in 0..D {
			let w: Vec<(f64, f64, f64)> = (0..feats).map(|_| (rng.normal() / 2.0, rng.range(0.0, std::f64::consts::TAU), rng.normal())).collect();
			for o in 0..MAXOPT {
				let gp: f64 = w.iter().map(|(om, ph, a)| a * (om * o as f64 + ph).cos()).sum::<f64>() * (2.0 / feats as f64).sqrt();
				v[(k * ROWS + o) * D + c] = s * (0.7f64.sqrt() * gp + 0.3f64.sqrt() * rng.normal());
			}
			v[(k * ROWS + INACTIVE) * D + c] = s * rng.normal();
			v[(k * ROWS + CONT) * D + c] = 1.4 * s * rng.normal();
		}
	}
	for t in 0..NTYPES {
		for c in 0..D {
			v[(TYPE_BASE + t) * D + c] = s * rng.normal();
		}
	}
	v
}

/// Adam on the live values.
#[derive(Clone, Debug)]
pub struct Adam {
	m: Vec<Vec<f64>>,
	v: Vec<Vec<f64>>,
	t: i32,
}

impl Adam {
	pub fn new(ps: &ParamSet) -> Adam {
		Adam { m: ps.fixed.iter().map(|f| vec![0.0; f.len()]).collect(), v: ps.fixed.iter().map(|f| vec![0.0; f.len()]).collect(), t: 0 }
	}
	/// One step; returns false (and changes nothing) if a gradient is not finite.
	pub fn step(&mut self, ps: &mut ParamSet, grads: Vec<(usize, T)>, lr: f64, clip: f64) -> bool {
		let mut g: Vec<Option<Vec<f64>>> = vec![None; ps.names.len()];
		for (i, t) in grads {
			match &mut g[i] {
				Some(v) => v.iter_mut().zip(&t.v).for_each(|(a, b)| *a += b),
				slot => *slot = Some(t.v),
			}
		}
		let norm: f64 = g.iter().flatten().flat_map(|v| v.iter()).map(|x| x * x).sum::<f64>().sqrt();
		if !norm.is_finite() {
			return false;
		}
		let k = if norm > clip { clip / norm } else { 1.0 };
		self.t += 1;
		let (b1, b2, eps): (f64, f64, f64) = (0.9, 0.999, 1e-8);
		let c1 = 1.0 - b1.powi(self.t);
		let c2 = 1.0 - b2.powi(self.t);
		for (i, gi) in g.iter().enumerate() {
			let Some(gi) = gi else { continue };
			for j in 0..gi.len() {
				let x = gi[j] * k;
				self.m[i][j] = b1 * self.m[i][j] + (1.0 - b1) * x;
				self.v[i][j] = b2 * self.v[i][j] + (1.0 - b2) * x * x;
				ps.live[i][j] -= lr * (self.m[i][j] / c1) / ((self.v[i][j] / c2).sqrt() + eps);
			}
		}
		true
	}
}

/// The challenge's constant inputs.
pub struct Ctx {
	pub k: usize,
	/// Per knob: each softmax point's selector over the embedding table [out_k x NTABLE]: 1 on the option's row (knob
	/// with options), or the point's [0,1] position on the knob's continuous row (continuous knob).
	pub sel: Vec<T>,
	/// Per knob: the continuous row's selector [1 x NTABLE] (a continuous value multiplies it).
	pub cont_unit: Vec<T>,
	/// Per knob: the selector of its inactive row [1 x NTABLE].
	pub inactive: Vec<T>,
	/// The challenge's type rows [1 x NTABLE] (in every token).
	pub type_sel: T,
	/// The challenge's range features [1 x 2] (in every token).
	pub range: T,
	/// Per knob: u^2 of each softmax point on the knob's position column [out_k x MAXK] (continuous knobs; Linguini's output).
	pub quad: Vec<T>,
	pub continuous: Vec<bool>,
	cont_u: Vec<Vec<f64>>,
	/// Per knob: ordered (continuous or ordinal), decoded at its softmax's mean position.
	pub ordered: Vec<bool>,
}

impl Ctx {
	pub fn new(space: &Space) -> Ctx {
		let k = space.k();
		let mut sel = Vec::new();
		let mut cont_unit = Vec::new();
		let mut inactive = Vec::new();
		let mut quad = Vec::new();
		let mut type_sel = T::zeros(1, NTABLE);
		for i in 0..k {
			let kn = &space.knobs[i];
			let base = (i % MAXK) * ROWS;
			let out = kn.out_u();
			let mut s = T::zeros(out.len(), NTABLE);
			let mut q = T::zeros(out.len(), MAXK);
			for (o, &v) in out.iter().enumerate() {
				if kn.continuous() {
					s.v[o * NTABLE + base + CONT] = v;
					q.v[o * MAXK + i % MAXK] = v * v;
				} else {
					s.v[o * NTABLE + base + o % MAXOPT] = 1.0;
				}
			}
			sel.push(s);
			quad.push(q);
			let mut cu = T::zeros(1, NTABLE);
			cu.v[base + CONT] = 1.0;
			cont_unit.push(cu);
			let mut ia = T::zeros(1, NTABLE);
			ia.v[base + INACTIVE] = 1.0;
			inactive.push(ia);
			type_sel.v[TYPE_BASE + kn.type_index()] += 1.0;
			if kn.cond.is_some() {
				type_sel.v[TYPE_BASE + 5] += 1.0;
			}
		}
		let rf = space.range_features();
		Ctx { k, sel, cont_unit, inactive, type_sel, range: T::new(1, 2, rf.to_vec()), quad, continuous: space.knobs.iter().map(|kn| kn.continuous()).collect(), ordered: space.knobs.iter().map(|kn| kn.ordered()).collect(), cont_u: space.knobs.iter().map(|kn| if kn.continuous() { kn.u.clone() } else { vec![] }).collect() }
	}
	/// Embedding-table selectors of m configurations [m x NTABLE]: the sum of their knobs' rows and the type rows.
	pub fn encode(&self, configs: &[&Config]) -> T {
		let m = configs.len();
		let mut b = T::zeros(m, NTABLE);
		for (j, cfg) in configs.iter().enumerate() {
			let row = &mut b.v[j * NTABLE..(j + 1) * NTABLE];
			for (x, t) in row.iter_mut().zip(&self.type_sel.v) {
				*x += t;
			}
			for k in 0..self.k {
				match cfg[k] {
					Some(o) if self.continuous[k] => {
						let c = self.cont_unit[k].v.iter().position(|&x| x != 0.0).unwrap();
						row[c] += self.cont_u[k][o];
					}
					Some(o) => {
						for (x, s) in row.iter_mut().zip(&self.sel[k].v[o * NTABLE..(o + 1) * NTABLE]) {
							*x += s;
						}
					}
					None => {
						for (x, s) in row.iter_mut().zip(&self.inactive[k].v) {
							*x += s;
						}
					}
				}
			}
		}
		b
	}
}

#[derive(Clone, Debug)]
struct ReaderIx {
	table: usize,
	range_w: usize,
	conv0: usize,
	conv1: usize,
	conv2: usize,
	conv_b: usize,
}

fn add_reader(ps: &mut ParamSet, seed: u64) -> ReaderIx {
	let mut rng = ps.rng("table", seed);
	let tv = table_init(&mut rng);
	let s = 0.5 / ((D + NSIG) as f64).sqrt();
	ReaderIx {
		table: ps.add("table", NTABLE, D, Init::Values(tv), seed),
		range_w: ps.add("range_w", 2, D, Init::Normal(0.3), seed),
		conv0: ps.add("conv_t", D + NSIG, D, Init::Normal(s), seed),
		conv1: ps.add("conv_t1", D + NSIG, D, Init::Normal(s), seed),
		conv2: ps.add("conv_t2", D + NSIG, D, Init::Normal(s), seed),
		conv_b: ps.add("conv_b", 1, D, Init::Const(0.0), seed),
	}
}

/// Tokens' configuration part: the table rows the selectors pick, summed, plus the range features embedded.
fn config_part(tape: &mut Tape, p: &[Id], ix: &ReaderIx, ctx: &Ctx, b: Id) -> Id {
	let rows = tape.val(b).r;
	let c = tape.matmul(b, p[ix.table]);
	let rg = tape.constant(ctx.range.clone());
	let re = tape.matmul(rg, p[ix.range_w]);
	let rb = tape.broadcast_rows(re, rows);
	tape.add(c, rb)
}

/// Sequences for m candidates: block j holds the past guesses in order (without past guess j when the candidates
/// are the history itself, for leave-one-out training), then candidate j.
struct Seq {
	len: usize,
	/// Source row (0..n history, n..n+m candidates) of each sequence row.
	src: Vec<usize>,
	sel: T,
	last: T,
	m1: T,
	m2: T,
}

fn seq_layout(n: usize, m: usize, loo: bool) -> Seq {
	let len = if loo { n } else { n + 1 };
	let mut src = Vec::with_capacity(m * len);
	for j in 0..m {
		for i in 0..n {
			if loo && i == j {
				continue;
			}
			src.push(i);
		}
		src.push(n + j);
	}
	let rows = m * len;
	let mut sel = T::zeros(rows, n + m);
	let mut m1 = T::zeros(rows, 1);
	let mut m2 = T::zeros(rows, 1);
	for (r, &s) in src.iter().enumerate() {
		sel.v[r * (n + m) + s] = 1.0;
		m1.v[r] = if r % len >= 1 { 1.0 } else { 0.0 };
		m2.v[r] = if r % len >= 2 { 1.0 } else { 0.0 };
	}
	let mut last = T::zeros(m, rows);
	for j in 0..m {
		last.v[j * rows + j * len + len - 1] = 1.0;
	}
	Seq { len, src, sel, last, m1, m2 }
}

/// The causal convolution along each sequence (taps at t, t-1, t-2 within the block) with a residual path into the
/// configuration part. `x_all` [(n+m) x (D+NSIG)] holds every source token; returns the convolved configuration
/// part of every sequence row [m*len x D].
fn conv_seq(tape: &mut Tape, p: &[Id], ix: &ReaderIx, x_all: Id, c_all: Id, seq: &Seq) -> Id {
	let sel = tape.constant(seq.sel.clone());
	let s = tape.matmul(sel, x_all);
	let c = tape.matmul(sel, c_all);
	let m1 = tape.constant(seq.m1.clone());
	let m2 = tape.constant(seq.m2.clone());
	let s1 = tape.shift_rows(s, 1);
	let s1 = tape.mul_col(s1, m1);
	let s2 = tape.shift_rows(s, 2);
	let s2 = tape.mul_col(s2, m2);
	let a = tape.matmul(s, p[ix.conv0]);
	let b = tape.matmul(s1, p[ix.conv1]);
	let d = tape.matmul(s2, p[ix.conv2]);
	let h = tape.add(a, b);
	let h = tape.add(h, d);
	let h = tape.add_row(h, p[ix.conv_b]);
	let g = tape.gelu(h);
	tape.add(c, g)
}

/// What a RAT reads about the history.
pub struct RatHist {
	/// Selectors of the past guesses [n x NTABLE].
	pub b: T,
	/// Score features [n x NSIG]: valid bit, rank score, relative score.
	pub sig: T,
	/// The channel the attention averages: the rank score (score RAT) or 2 * valid - 1 (validity RAT).
	pub chan: Vec<f64>,
	pub valid: Vec<bool>,
	pub n: usize,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum RatKind {
	Score,
	Validity,
}

#[derive(Clone, Debug)]
pub struct Rat {
	pub kind: RatKind,
	pub ps: ParamSet,
	rd: ReaderIx,
	wa: usize,
	sharp: usize,
	null_logit: usize,
	null_chan: usize,
	null_v: usize,
	wv: usize,
	bv: usize,
	w1: usize,
	b1: usize,
	w2: usize,
	b2: usize,
	gain: usize,
}

impl Rat {
	pub fn new(kind: RatKind, seed: u64) -> Rat {
		let mut ps = ParamSet::new(if kind == RatKind::Score { "score_rat" } else { "validity_rat" });
		let rd = add_reader(&mut ps, seed);
		let score = kind == RatKind::Score;
		Rat {
			kind,
			wa: ps.add("att_w", D, DA, Init::Normal(1.0 / (D as f64).sqrt()), seed),
			sharp: ps.add("att_sharpness", 1, 1, Init::Const(0.5413), seed),
			null_logit: ps.add("null_logit", 1, 1, Init::Const(-2.0), seed),
			null_chan: ps.add("null_chan", 1, 1, Init::Const(if score { 0.0 } else { 1.0 }), seed),
			null_v: ps.add("null_v", 1, DV, Init::Const(0.0), seed),
			wv: ps.add("val_w", D + NSIG, DV, Init::Normal(1.0 / ((D + NSIG) as f64).sqrt()), seed),
			bv: ps.add("val_b", 1, DV, Init::Const(0.0), seed),
			w1: ps.add("out1_w", D + DV, HID, Init::Normal(1.0 / ((D + DV) as f64).sqrt()), seed),
			b1: ps.add("out1_b", 1, HID, Init::Const(0.0), seed),
			w2: ps.add("out2_w", HID, 1, Init::Normal(0.1 / (HID as f64).sqrt()), seed),
			b2: ps.add("out2_b", 1, 1, Init::Const(if score { 0.0 } else { 1.0 }), seed),
			gain: ps.add("chan_gain", 1, 1, Init::Const(if score { 1.0 } else { 2.0 }), seed),
			ps,
			rd,
		}
	}

	/// Predictions for m candidates [m x 1]: the score RAT's predicted rank score, or the validity RAT's logit.
	/// `cand` holds the candidates' selectors [m x NTABLE]. With `loo`, the candidates are the history itself and
	/// each one's sequence leaves it out. The score RAT doesn't attend to invalid past guesses.
	pub fn forward(&self, tape: &mut Tape, p: &[Id], ctx: &Ctx, cand: Id, m: usize, hist: &RatHist, loo: bool) -> Id {
		let n = hist.n;
		let seq = seq_layout(n, m, loo);
		let rows = m * seq.len;
		let hb = tape.constant(hist.b.clone());
		let b_all = tape.concat_rows(&[hb, cand]);
		let c_all = config_part(tape, p, &self.rd, ctx, b_all);
		let mut sig_all = T::zeros(n + m, NSIG);
		sig_all.v[..n * NSIG].copy_from_slice(&hist.sig.v);
		let sa = tape.constant(sig_all);
		let x_all = tape.concat_cols(&[c_all, sa]);
		let cp = conv_seq(tape, p, &self.rd, x_all, c_all, &seq);
		let last = tape.constant(seq.last.clone());
		let q = tape.matmul(last, cp);
		// attention logits: minus the squared distance between projected tokens, times a learned sharpness
		let aq = tape.matmul(q, p[self.wa]);
		let ak = tape.matmul(cp, p[self.wa]);
		let cross = tape.matmul_t(aq, ak);
		let cross = tape.scale(cross, -2.0);
		let sqq = tape.row_sq(aq);
		let sqk = tape.row_sq(ak);
		let sqk = tape.transpose(sqk);
		let d = tape.add_col(cross, sqq);
		let d = tape.add_row(d, sqk);
		let sh = tape.softplus(p[self.sharp]);
		let d = tape.mul_scalar(d, sh);
		let logits = tape.scale(d, -1.0 / DA as f64);
		let mut mask = T::filled(m, rows, MASKED);
		for j in 0..m {
			for r in j * seq.len..j * seq.len + seq.len - 1 {
				let s = seq.src[r];
				if self.kind == RatKind::Validity || hist.valid[s] {
					mask.v[j * rows + r] = 0.0;
				}
			}
		}
		let mk = tape.constant(mask);
		let logits = tape.add(logits, mk);
		let nl = tape.broadcast_rows(p[self.null_logit], m);
		let full = tape.concat_cols(&[nl, logits]);
		let alpha = tape.softmax_rows(full);
		// values: each past guess's convolved token and score features
		let mut srows = T::zeros(rows, NSIG);
		let mut crow = T::zeros(rows, 1);
		for (r, &s) in seq.src.iter().enumerate() {
			if s < n {
				srows.v[r * NSIG..(r + 1) * NSIG].copy_from_slice(&hist.sig.v[s * NSIG..(s + 1) * NSIG]);
				crow.v[r] = hist.chan[s];
			}
		}
		let sr = tape.constant(srows);
		let vin = tape.concat_cols(&[cp, sr]);
		let vh = tape.matmul(vin, p[self.wv]);
		let vh = tape.add_row(vh, p[self.bv]);
		let vall = tape.concat_rows(&[p[self.null_v], vh]);
		let ctxv = tape.matmul(alpha, vall);
		let ch = tape.constant(crow);
		let chall = tape.concat_rows(&[p[self.null_chan], ch]);
		let cy = tape.matmul(alpha, chall);
		let hin = tape.concat_cols(&[q, ctxv]);
		let h = tape.matmul(hin, p[self.w1]);
		let h = tape.add_row(h, p[self.b1]);
		let h = tape.gelu(h);
		let out = tape.matmul(h, p[self.w2]);
		let out = tape.add_row(out, p[self.b2]);
		let g = tape.mul_scalar(cy, p[self.gain]);
		tape.add(g, out)
	}
}

/// What Linguini reads about the history.
pub struct LinHist {
	pub b: T,
	pub sig: T,
	pub n: usize,
}

#[derive(Clone, Debug)]
pub struct Lin {
	/// Softmax temperature applied to a categorical knob's standardized logits.
	pub tau: f64,
	/// Softmax temperature for an ordered knob (continuous or ordinal), decoded at the mean position: larger, so the
	/// mean can reach near either end of the range.
	pub tau_ordered: f64,
	/// Which knobs decode at the mean (see `Settings::mean_decode`); those use `tau_ordered`.
	pub mean_decode: u8,
	pub ps: ParamSet,
	rd: ReaderIx,
	slot: usize,
	wq: usize,
	wk: usize,
	wv: usize,
	bv: usize,
	null_logit: usize,
	null_v: usize,
	w1: usize,
	b1: usize,
	wo: usize,
	quad: usize,
}

impl Lin {
	pub fn new(seed: u64) -> Lin {
		let mut ps = ParamSet::new("linguini");
		let rd = add_reader(&mut ps, seed);
		let du = D + NSIG;
		Lin {
			tau: LOGIT_TEMP,
			tau_ordered: ORDERED_TEMP,
			mean_decode: 0,
			slot: ps.add("candidate_slot", 1, D, Init::Normal(0.5), seed),
			wq: ps.add("query_w", D, DA, Init::Normal(1.0 / (D as f64).sqrt()), seed),
			wk: ps.add("key_w", du, DA, Init::Normal(1.0 / (du as f64).sqrt()), seed),
			wv: ps.add("val_w", du, DV, Init::Normal(1.0 / (du as f64).sqrt()), seed),
			bv: ps.add("val_b", 1, DV, Init::Const(0.0), seed),
			null_logit: ps.add("null_logit", 1, 1, Init::Const(0.0), seed),
			null_v: ps.add("null_v", 1, DV, Init::Const(0.0), seed),
			w1: ps.add("out1_w", D + DV, D, Init::Normal(1.0 / ((D + DV) as f64).sqrt()), seed),
			b1: ps.add("out1_b", 1, D, Init::Const(0.0), seed),
			wo: ps.add("out2_w", D, D, Init::Normal(1.0 / (D as f64).sqrt()), seed),
			quad: ps.add("out_quadratic", MAXK, D, Init::Normal(0.7), seed),
			ps,
			rd,
		}
	}

	/// One logit row [1 x n_k] per knob. The candidate slot (the challenge's type rows plus a learned slot row) ends
	/// the sequence of past guesses; after the convolution it queries one attention head over the past guesses, and
	/// the result is compared with every option's row (for a continuous knob, the option's u times the knob's
	/// continuous row plus u^2 times a learned output row, so a peak can sit inside the range). Each knob's logits
	/// are standardized and scaled by the temperature.
	pub fn forward(&self, tape: &mut Tape, p: &[Id], ctx: &Ctx, hist: &LinHist) -> Vec<Id> {
		let n = hist.n;
		let mut b = T::zeros(n + 1, NTABLE);
		b.v[..n * NTABLE].copy_from_slice(&hist.b.v);
		b.v[n * NTABLE..].copy_from_slice(&ctx.type_sel.v);
		let bn = tape.constant(b);
		let c_all = config_part(tape, p, &self.rd, ctx, bn);
		let ch = tape.slice_rows(c_all, 0, n);
		let cs = tape.slice_rows(c_all, n, 1);
		let cs = tape.add(cs, p[self.slot]);
		let c_all = tape.concat_rows(&[ch, cs]);
		let mut sig_all = T::zeros(n + 1, NSIG);
		sig_all.v[..n * NSIG].copy_from_slice(&hist.sig.v);
		let sa = tape.constant(sig_all);
		let x_all = tape.concat_cols(&[c_all, sa]);
		let seq = seq_layout(n, 1, false);
		let cp = conv_seq(tape, p, &self.rd, x_all, c_all, &seq);
		let q = tape.slice_rows(cp, n, 1);
		let hc = tape.slice_rows(cp, 0, n);
		let hs = tape.constant(hist.sig.clone());
		let u = tape.concat_cols(&[hc, hs]);
		let qa = tape.matmul(q, p[self.wq]);
		let ka = tape.matmul(u, p[self.wk]);
		let att = tape.matmul_t(qa, ka);
		let att = tape.scale(att, 1.0 / (DA as f64).sqrt());
		let full = tape.concat_cols(&[p[self.null_logit], att]);
		let alpha = tape.softmax_rows(full);
		let vh = tape.matmul(u, p[self.wv]);
		let vh = tape.add_row(vh, p[self.bv]);
		let vall = tape.concat_rows(&[p[self.null_v], vh]);
		let ctxv = tape.matmul(alpha, vall);
		let zin = tape.concat_cols(&[q, ctxv]);
		let z = tape.matmul(zin, p[self.w1]);
		let z = tape.add_row(z, p[self.b1]);
		let z = tape.gelu(z);
		let o = tape.matmul(z, p[self.wo]);
		let mut out = Vec::with_capacity(ctx.k);
		for k in 0..ctx.k {
			let sk = tape.constant(ctx.sel[k].clone());
			let mut rk = tape.matmul(sk, p[self.rd.table]);
			if ctx.quad[k].v.iter().any(|&x| x != 0.0) {
				let qk = tape.constant(ctx.quad[k].clone());
				let qr = tape.matmul(qk, p[self.quad]);
				rk = tape.add(rk, qr);
			}
			let lg = tape.matmul_t(o, rk);
			let lg = tape.scale(lg, 1.0 / (D as f64).sqrt());
			let lg = tape.standardize_rows(lg, 1e-6);
			let by_mean = (self.mean_decode >= 1 && ctx.continuous[k]) || (self.mean_decode >= 2 && ctx.ordered[k]);
			out.push(tape.scale(lg, if by_mean { self.tau_ordered } else { self.tau }));
		}
		out
	}
}

/// The three first-order models.
#[derive(Clone, Debug)]
pub struct Models {
	pub lin: Lin,
	pub srat: Rat,
	pub vrat: Rat,
}

impl Models {
	/// The seeded initialization: the fixed values of Remy with no pretraining.
	pub fn new(seed: u64) -> Models {
		Models { lin: Lin::new(seed), srat: Rat::new(RatKind::Score, seed), vrat: Rat::new(RatKind::Validity, seed) }
	}
	pub fn sets(&self) -> [&ParamSet; 3] {
		[&self.lin.ps, &self.srat.ps, &self.vrat.ps]
	}
	pub fn sets_mut(&mut self) -> [&mut ParamSet; 3] {
		[&mut self.lin.ps, &mut self.srat.ps, &mut self.vrat.ps]
	}
	pub fn reset_live(&mut self) {
		for s in self.sets_mut() {
			s.reset_live();
		}
	}
	pub fn count(&self) -> usize {
		self.sets().iter().map(|s| s.count()).sum()
	}
	pub fn finite(&self) -> bool {
		self.sets().iter().all(|s| s.finite())
	}
	/// The fixed values as text: one line per parameter, `model.name rows cols values...`.
	pub fn save_text(&self, header: &str) -> String {
		let mut out = String::new();
		for line in header.lines() {
			out.push_str(&format!("# {line}\n"));
		}
		for s in self.sets() {
			for i in 0..s.names.len() {
				let (r, c) = s.shapes[i];
				out.push_str(&format!("{}.{} {} {}", s.model, s.names[i], r, c));
				for x in &s.fixed[i] {
					out.push_str(&format!(" {x:?}"));
				}
				out.push('\n');
			}
		}
		out
	}
	pub fn load_text(&mut self, text: &str) -> Result<(), String> {
		let mut seen = 0;
		for line in text.lines() {
			if line.starts_with('#') || line.trim().is_empty() {
				continue;
			}
			let mut it = line.split_whitespace();
			let key = it.next().ok_or("empty line")?;
			let (model, name) = key.split_once('.').ok_or(format!("bad key {key}"))?;
			let r: usize = it.next().ok_or("no rows")?.parse().map_err(|_| "bad rows")?;
			let c: usize = it.next().ok_or("no cols")?.parse().map_err(|_| "bad cols")?;
			let vals: Vec<f64> = it.map(|x| x.parse::<f64>().map_err(|_| format!("bad value in {key}"))).collect::<Result<_, _>>()?;
			let set = self.sets_mut().into_iter().find(|s| s.model == model).ok_or(format!("unknown model {model}"))?;
			let i = set.names.iter().position(|n| n == name).ok_or(format!("unknown parameter {key}"))?;
			if set.shapes[i] != (r, c) || vals.len() != r * c {
				return Err(format!("{key}: shape mismatch"));
			}
			set.fixed[i] = vals;
			seen += 1;
		}
		let total: usize = self.sets().iter().map(|s| s.names.len()).sum();
		if seen != total {
			return Err(format!("weights file has {seen} of {total} parameters"));
		}
		self.reset_live();
		Ok(())
	}
}

/// History values per knob, for the exploration entropy: option counts (knob with options) or [0,1] positions
/// (continuous knob), over the past guesses where the knob is active.
pub struct KnobHist {
	pub counts: Vec<f64>,
	pub us: Vec<f64>,
}

/// The candidate's value of one knob, as the loss sees it.
#[derive(Clone, Copy, Debug)]
pub enum KnobIn {
	/// Inactive conditional knob.
	Off,
	/// A knob with options: the (straight-through) one-hot over its options [1 x n_k].
	Disc(Id),
	/// A continuous knob: its (straight-through) [0,1] position [1 x 1].
	Cont(Id),
}

/// The term H(x): the run's exploration entropy with the candidate added, as a node that is differentiable with
/// respect to the candidate's values `inputs[k]`.
///
/// A knob with options: the candidate's one-hot e enters linearly as H_k(e) = sum_o e_o H_k(o), where H_k(o) is the
/// exact count entropy with the candidate at option o (so the forward value is exact and every option's gradient is
/// finite). A continuous knob: the candidate's position u enters the nearest-neighbor estimate
/// (`space::continuous_entropy`) through its distance to its nearest past guess and, where it is closer, through
/// past guesses' nearest-neighbor distances; this is differentiable in u almost everywhere, and at an exact tie the
/// derivative is the symmetric one (the mean of the left and right derivatives).
pub fn entropy_node(tape: &mut Tape, space: &Space, hist: &[KnobHist], inputs: &[KnobIn]) -> Option<Id> {
	let mut terms = Vec::new();
	for (k, kn) in space.knobs.iter().enumerate() {
		let h = &hist[k];
		if !kn.continuous() {
			if kn.n() < 2 {
				continue;
			}
			let node = match inputs[k] {
				KnobIn::Disc(e) => {
					let per: Vec<f64> = (0..kn.n())
						.map(|o| {
							let mut c = h.counts.clone();
							c[o] += 1.0;
							discrete_entropy(&c)
						})
						.collect();
					let col = tape.constant(T::new(kn.n(), 1, per));
					tape.matmul(e, col)
				}
				_ => tape.constant(T::scalar(discrete_entropy(&h.counts))),
			};
			terms.push(node);
			continue;
		}
		let node = match inputs[k] {
			KnobIn::Cont(_) if h.us.is_empty() => tape.constant(T::scalar(0.0)),
			KnobIn::Cont(u) => {
				// S(u) = sum of ln(rho + delta) over the candidate and the past guesses, built as its exact value plus
				// its derivative in u. At an exact tie (common on a value grid) the derivative is the symmetric one,
				// the mean of the left and right derivatives, which is what a central difference measures.
				let ux = tape.val(u).v[0];
				let us = &h.us;
				let n = us.len();
				let tie = 1e-12;
				let side = |a: f64, b: f64, at_tie: f64| if a > b + tie { 1.0 } else if a < b - tie { -1.0 } else { at_tie };
				let mut s = 0.0;
				let mut kx = 0.0;
				// the candidate's nearest distance: min over past guesses of |u - u_j|
				let rx = us.iter().map(|&v| (ux - v).abs()).fold(f64::INFINITY, f64::min);
				let near: Vec<f64> = us.iter().cloned().filter(|&v| ((ux - v).abs() - rx).abs() <= tie).collect();
				let right = near.iter().map(|&v| side(ux, v, 1.0)).fold(f64::INFINITY, f64::min);
				let left = near.iter().map(|&v| side(ux, v, -1.0)).fold(f64::NEG_INFINITY, f64::max);
				s += (rx + ENT_DELTA).ln();
				kx += 0.5 * (right + left) / (rx + ENT_DELTA);
				// each past guess's nearest distance: min(its distance to the other past guesses, |u_i - u|)
				for i in 0..n {
					let ri = (0..n).filter(|&j| j != i).map(|j| (us[i] - us[j]).abs()).fold(f64::INFINITY, f64::min);
					let t = (us[i] - ux).abs();
					let (fp, fm) = (side(ux, us[i], 1.0), side(ux, us[i], -1.0));
					let (rho, slope) = if t < ri - tie {
						(t, 0.5 * (fp + fm))
					} else if (t - ri).abs() <= tie {
						(t, 0.5 * (fp.min(0.0) + fm.max(0.0)))
					} else {
						(ri, 0.0)
					};
					s += (rho + ENT_DELTA).ln();
					kx += slope / (rho + ENT_DELTA);
				}
				let c = tape.constant(T::scalar(s - kx * ux));
				let lin = tape.scale(u, kx);
				let sn = tape.add(c, lin);
				let mean = tape.scale(sn, 1.0 / (n + 1) as f64);
				let gm = tape.exp(mean);
				let c = tape.constant(T::scalar(-ENT_DELTA));
				let g = tape.add(gm, c);
				tape.scale(g, n as f64)
			}
			_ => tape.constant(T::scalar(continuous_entropy(&h.us))),
		};
		terms.push(node);
	}
	if terms.is_empty() {
		return None;
	}
	let mut acc = terms[0];
	for &t in &terms[1..] {
		acc = tape.add(acc, t);
	}
	Some(tape.scale(acc, 1.0 / terms.len() as f64))
}

#[derive(PartialEq)]
struct Cand {
	score: f64,
	ranks: Vec<u16>,
}
impl Eq for Cand {}
impl PartialOrd for Cand {
	fn partial_cmp(&self, o: &Self) -> Option<std::cmp::Ordering> {
		Some(self.cmp(o))
	}
}
impl Ord for Cand {
	fn cmp(&self, o: &Self) -> std::cmp::Ordering {
		self.score.total_cmp(&o.score).then_with(|| o.ranks.cmp(&self.ranks))
	}
}

/// Decode to the best configuration the run hasn't guessed yet. `alts[k]` lists knob k's alternatives best first,
/// as (option, score): a categorical knob's options by log-probability; an ordered knob's options by closeness to
/// its decoded value. Configurations are enumerated best first by the sum of their knobs' scores (only knobs that
/// are active change), and the first one not yet guessed is returned, with whether it fell back to a seeded
/// random configuration.
pub fn decode(space: &Space, alts: &[Vec<(usize, f64)>], seen: &HashSet<Config>, fallback_seed: u64) -> (Config, bool) {
	let k = space.k();
	let build = |ranks: &[u16]| -> Config {
		let full: Config = (0..k).map(|i| Some(alts[i][ranks[i] as usize].0)).collect();
		space.canonical(&full)
	};
	let score = |ranks: &[u16]| -> f64 { (0..k).map(|i| alts[i][ranks[i] as usize].1).sum() };
	let mut heap = BinaryHeap::new();
	let mut visited: HashSet<Vec<u16>> = HashSet::new();
	let start = vec![0u16; k];
	visited.insert(start.clone());
	heap.push(Cand { score: score(&start), ranks: start });
	let mut pops = 0;
	while let Some(c) = heap.pop() {
		pops += 1;
		let cfg = build(&c.ranks);
		if !seen.contains(&cfg) {
			return (cfg, false);
		}
		if pops > 20000 {
			break;
		}
		for i in 0..k {
			if cfg[i].is_none() || (c.ranks[i] as usize) + 1 >= alts[i].len() {
				continue;
			}
			let mut r = c.ranks.clone();
			r[i] += 1;
			if visited.insert(r.clone()) {
				heap.push(Cand { score: score(&r), ranks: r });
			}
		}
	}
	let mut rng = Rng::new(fallback_seed);
	for _ in 0..100000 {
		let cfg = space.random_config(&mut rng);
		if !seen.contains(&cfg) {
			return (cfg, true);
		}
	}
	(space.random_config(&mut rng), true)
}
