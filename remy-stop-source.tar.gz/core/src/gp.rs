//! A Gaussian-process bandit on synthetic problems: a free stand-in for Vizier's default algorithm (Song et al.,
//! 2024, "The Vizier Gaussian Process Bandit Algorithm"). Matern-5/2 kernel with one length scale per knob, chosen
//! by marginal likelihood; output warping by rank to normal quantiles; upper confidence bound with coefficient 1.8;
//! the first guess at the center of the space; the acquisition maximized over random and local candidates.
//! Diagnostic only: it never runs on a holdout challenge.

use crate::rng::{Rng, mix};
use crate::space::{Config, Kind, Space};
use std::collections::HashSet;

const LENGTHS: [f64; 8] = [0.05, 0.1, 0.2, 0.35, 0.6, 1.0, 2.0, 4.0];
const NOISE: f64 = 1e-4;
const BETA: f64 = 1.8;

/// Feature groups: one group per knob (its coordinates), so each knob gets its own length scale.
fn features(space: &Space, c: &Config) -> Vec<Vec<f64>> {
	space
		.knobs
		.iter()
		.enumerate()
		.map(|(k, kn)| {
			let mut f = Vec::new();
			match kn.kind {
				Kind::Categorical => {
					for o in 0..kn.n() {
						f.push(if c[k] == Some(o) { std::f64::consts::FRAC_1_SQRT_2 } else { 0.0 });
					}
				}
				_ => f.push(c[k].map(|o| kn.u[o]).unwrap_or(0.5)),
			}
			if kn.cond.is_some() {
				f.push(if c[k].is_some() { 1.0 } else { 0.0 });
			}
			f
		})
		.collect()
}

fn kernel(a: &[Vec<f64>], b: &[Vec<f64>], ls: &[f64]) -> f64 {
	let mut r2 = 0.0;
	for k in 0..a.len() {
		let d: f64 = a[k].iter().zip(&b[k]).map(|(x, y)| (x - y) * (x - y)).sum();
		r2 += d / (ls[k] * ls[k]);
	}
	let r = (5.0 * r2).sqrt();
	(1.0 + r + r * r / 3.0) * (-r).exp()
}

/// Lower Cholesky factor of a symmetric positive definite matrix (row-major n x n); None if it fails.
fn cholesky(a: &[f64], n: usize) -> Option<Vec<f64>> {
	let mut l = vec![0.0; n * n];
	for i in 0..n {
		for j in 0..=i {
			let s: f64 = (0..j).map(|k| l[i * n + k] * l[j * n + k]).sum();
			if i == j {
				let d = a[i * n + i] - s;
				if d <= 0.0 || !d.is_finite() {
					return None;
				}
				l[i * n + i] = d.sqrt();
			} else {
				l[i * n + j] = (a[i * n + j] - s) / l[j * n + j];
			}
		}
	}
	Some(l)
}

fn solve_lower(l: &[f64], n: usize, b: &[f64]) -> Vec<f64> {
	let mut x = vec![0.0; n];
	for i in 0..n {
		let s: f64 = (0..i).map(|k| l[i * n + k] * x[k]).sum();
		x[i] = (b[i] - s) / l[i * n + i];
	}
	x
}

fn solve_upper_t(l: &[f64], n: usize, b: &[f64]) -> Vec<f64> {
	let mut x = vec![0.0; n];
	for i in (0..n).rev() {
		let s: f64 = (i + 1..n).map(|k| l[k * n + i] * x[k]).sum();
		x[i] = (b[i] - s) / l[i * n + i];
	}
	x
}

/// Inverse of the standard normal distribution function (Acklam's rational approximation).
fn norm_ppf(p: f64) -> f64 {
	let a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.383577518672690e2, -3.066479806614716e1, 2.506628277459239];
	let b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1];
	let c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
	let d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416];
	let pl = 0.02425;
	if p < pl {
		let q = (-2.0 * p.ln()).sqrt();
		(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0)
	} else if p <= 1.0 - pl {
		let q = p - 0.5;
		let r = q * q;
		(((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1.0)
	} else {
		-norm_ppf(1.0 - p)
	}
}

struct Fit {
	l: Vec<f64>,
	alpha: Vec<f64>,
	ls: Vec<f64>,
	x: Vec<Vec<Vec<f64>>>,
}

fn fit_with(x: &[Vec<Vec<f64>>], y: &[f64], ls: &[f64]) -> Option<(f64, Vec<f64>, Vec<f64>)> {
	let n = x.len();
	let mut kmat = vec![0.0; n * n];
	for i in 0..n {
		for j in 0..n {
			kmat[i * n + j] = kernel(&x[i], &x[j], ls) + if i == j { NOISE } else { 0.0 };
		}
	}
	let l = cholesky(&kmat, n)?;
	let z = solve_lower(&l, n, y);
	let alpha = solve_upper_t(&l, n, &z);
	let logdet: f64 = (0..n).map(|i| l[i * n + i].ln()).sum();
	let lml = -0.5 * z.iter().map(|v| v * v).sum::<f64>() - logdet;
	Some((lml, l, alpha))
}

fn fit(x: Vec<Vec<Vec<f64>>>, y: &[f64]) -> Fit {
	let k = x[0].len();
	let mut ls = vec![0.35; k];
	let mut best = fit_with(&x, y, &ls).map(|f| f.0).unwrap_or(f64::NEG_INFINITY);
	for _sweep in 0..2 {
		for kk in 0..k {
			for &v in &LENGTHS {
				let old = ls[kk];
				ls[kk] = v;
				match fit_with(&x, y, &ls) {
					Some((lml, _, _)) if lml > best + 1e-9 => best = lml,
					_ => ls[kk] = old,
				}
			}
		}
	}
	let (_, l, alpha) = fit_with(&x, y, &ls).unwrap_or_else(|| {
		ls = vec![1.0; k];
		fit_with(&x, y, &ls).expect("GP fit")
	});
	Fit { l, alpha, ls, x }
}

impl Fit {
	/// Posterior mean and standard deviation of the warped target at features f.
	fn predict(&self, f: &[Vec<f64>]) -> (f64, f64) {
		let n = self.x.len();
		let ks: Vec<f64> = self.x.iter().map(|xi| kernel(xi, f, &self.ls)).collect();
		let mu: f64 = ks.iter().zip(&self.alpha).map(|(a, b)| a * b).sum();
		let v = solve_lower(&self.l, n, &ks);
		let var = (1.0 - v.iter().map(|x| x * x).sum::<f64>()).max(1e-12);
		(mu, var.sqrt())
	}
}

/// Vizier's first guess: the center of the space (the upper middle option for an even count, the middle of the
/// scale for a continuous knob, the first option for a categorical knob).
fn center(space: &Space) -> Config {
	let cfg: Config = space
		.knobs
		.iter()
		.map(|kn| {
			Some(match kn.kind {
				Kind::Categorical => 0,
				Kind::Ordinal => kn.n() / 2,
				_ => (0..kn.n()).min_by(|&a, &b| (kn.u[a] - 0.5).abs().total_cmp(&(kn.u[b] - 0.5).abs()).then(b.cmp(&a))).unwrap(),
			})
		})
		.collect();
	space.canonical(&cfg)
}

fn local_move(space: &Space, b: &Config, rng: &mut Rng) -> Config {
	let mut c = b.clone();
	let k = rng.below(space.k());
	let kn = &space.knobs[k];
	c[k] = Some(match (kn.ordered(), c[k]) {
		// an ordered knob moves to a nearby option most of the time
		(true, Some(o)) if rng.chance(0.7) => {
			let span = (kn.n() as f64 * 0.1).ceil().max(1.0) as i64;
			let step = rng.below(2 * span as usize + 1) as i64 - span;
			(o as i64 + step).clamp(0, kn.n() as i64 - 1) as usize
		}
		_ => rng.below(kn.n()),
	});
	let full: Config = c.iter().enumerate().map(|(k, o)| Some(o.unwrap_or_else(|| rng.below(space.knobs[k].n())))).collect();
	space.canonical(&full)
}

/// One run of `guesses` guesses; `measure` returns the score (lower is better) or None for invalid.
pub fn gp_run(space: &Space, guesses: usize, seed: u64, measure: &mut dyn FnMut(&Config) -> Option<f64>) -> Vec<(Config, Option<f64>)> {
	let mut rng = Rng::new(mix(seed, 0x6B));
	let mut hist: Vec<(Config, Option<f64>)> = Vec::new();
	let mut seen: HashSet<Config> = HashSet::new();
	for t in 0..guesses {
		let cfg = if t == 0 {
			center(space)
		} else {
			// warped target: higher is better; ranks of the valid scores to normal quantiles; invalid below the worst
			let valid: Vec<f64> = hist.iter().filter_map(|h| h.1).collect();
			let nv = valid.len() as f64;
			let y: Vec<f64> = hist
				.iter()
				.map(|h| match h.1 {
					Some(s) => {
						let less = valid.iter().filter(|&&v| v < s).count() as f64;
						let eq = valid.iter().filter(|&&v| v == s).count() as f64;
						// rank from the worst: more scores above s means better
						let better_than = nv - less - eq + (eq - 1.0) / 2.0;
						norm_ppf((better_than + 0.5) / nv)
					}
					None => norm_ppf(0.5 / (nv + 1.0)) - 1.0,
				})
				.collect();
			let x: Vec<Vec<Vec<f64>>> = hist.iter().map(|h| features(space, &h.0)).collect();
			let f = fit(x, &y);
			let mut order: Vec<usize> = (0..hist.len()).filter(|&i| hist[i].1.is_some()).collect();
			order.sort_by(|&a, &b| hist[a].1.unwrap().total_cmp(&hist[b].1.unwrap()));
			let mut best_c: Option<Config> = None;
			let mut best_a = f64::NEG_INFINITY;
			for i in 0..2000 {
				let c = if i % 2 == 1 && !order.is_empty() {
					let base = &hist[order[(i / 2) % order.len().min(3)]].0;
					let mut c = local_move(space, base, &mut rng);
					if rng.chance(0.5) {
						c = local_move(space, &c, &mut rng);
					}
					c
				} else {
					space.random_config(&mut rng)
				};
				if seen.contains(&c) {
					continue;
				}
				let (mu, sd) = f.predict(&features(space, &c));
				let a = mu + BETA * sd;
				if a > best_a {
					best_a = a;
					best_c = Some(c);
				}
			}
			best_c.unwrap_or_else(|| loop {
				let c = space.random_config(&mut rng);
				if !seen.contains(&c) {
					break c;
				}
			})
		};
		let s = measure(&cfg).filter(|s| s.is_finite());
		seen.insert(cfg.clone());
		hist.push((cfg, s));
	}
	hist
}
