//! Runs on synthetic sampler problems: Remy (any fixed values) and random search, scored as percentiles within
//! each problem's own reference.

use crate::model::Models;
use crate::remy::{Diag, Guess, Remy, Settings, best};
use crate::rng::{Rng, mix};
use crate::sampler::{Problem, percentile};
use std::sync::Mutex;
use std::sync::atomic::{AtomicUsize, Ordering};

/// Map `f` over 0..n on `threads` threads; results come back in index order, so the outcome is deterministic.
pub fn parallel<R: Send>(n: usize, threads: usize, f: impl Fn(usize) -> R + Sync) -> Vec<R> {
	let next = AtomicUsize::new(0);
	let out: Mutex<Vec<Option<R>>> = Mutex::new((0..n).map(|_| None).collect());
	std::thread::scope(|s| {
		for _ in 0..threads.max(1).min(n.max(1)) {
			s.spawn(|| {
				loop {
					let i = next.fetch_add(1, Ordering::Relaxed);
					if i >= n {
						break;
					}
					let r = f(i);
					out.lock().unwrap()[i] = Some(r);
				}
			});
		}
	});
	out.into_inner().unwrap().into_iter().map(|r| r.expect("job finished")).collect()
}

pub fn threads() -> usize {
	std::env::var("REMY_THREADS").ok().and_then(|t| t.parse().ok()).unwrap_or_else(|| std::thread::available_parallelism().map(|n| n.get()).unwrap_or(4))
}

/// A synthetic problem with its reference, built once.
pub struct Task {
	pub p: Problem,
	pub reference: Vec<f64>,
}

impl Task {
	pub fn new(id: u64) -> Task {
		let p = Problem::new(id);
		let reference = p.reference();
		Task { p, reference }
	}
}

pub fn tasks(ids: &[u64], threads: usize) -> Vec<Task> {
	parallel(ids.len(), threads, |i| Task::new(ids[i]))
}

#[derive(Clone, Debug)]
pub struct RunStats {
	pub id: u64,
	pub best: Option<f64>,
	pub pct: f64,
	pub invalid: Vec<bool>,
	pub entropy: f64,
	pub diag: Diag,
	pub secs: Vec<f64>,
	pub region: bool,
	pub guesses: Vec<Guess>,
}

/// One Remy run on a synthetic problem, measured in-process. Returns the stats and the models at the end of the run
/// (fixed values unchanged, live values as learned).
pub fn remy_run(task: &Task, models: &Models, st: &Settings) -> (RunStats, Models) {
	let space = &task.p.space;
	let mut remy = Remy::new(space, models.clone(), st.clone());
	let mut measure = |cfg: &crate::space::Config| task.p.score(&space.values(cfg));
	let hist = remy.run(&mut measure, &mut |_, _| {});
	let configs: Vec<_> = hist.iter().map(|g| g.cfg.clone()).collect();
	let b = best(&hist);
	let stats = RunStats {
		id: task.p.id,
		best: b,
		pct: percentile(b, &task.reference),
		invalid: hist.iter().map(|g| g.score.is_none()).collect(),
		entropy: space.exploration_entropy(&configs),
		diag: remy.diag.clone(),
		secs: hist.iter().map(|g| g.secs).collect(),
		region: task.p.has_invalid_region(),
		guesses: hist,
	};
	(stats, remy.models)
}

/// Random search as the design defines it: each guess a uniform random row of the reference. Returns the mean
/// best percentile over `seeds` runs, and the share of guesses that were invalid.
pub fn random_search(task: &Task, seeds: usize, guesses: usize) -> (f64, f64) {
	let n = task.reference.len();
	let mut pct = 0.0;
	let mut invalid = 0usize;
	for s in 0..seeds {
		let mut r = Rng::new(mix(task.p.id, 0xBA5E_0000 + s as u64));
		let mut b: Option<f64> = None;
		for _ in 0..guesses {
			let x = task.reference[r.below(n)];
			if x.is_finite() {
				b = Some(b.map_or(x, |y: f64| y.min(x)));
			} else {
				invalid += 1;
			}
		}
		pct += percentile(b, &task.reference);
	}
	(pct / seeds as f64, invalid as f64 / (seeds * guesses) as f64)
}

pub fn mean(v: &[f64]) -> f64 {
	if v.is_empty() { f64::NAN } else { v.iter().sum::<f64>() / v.len() as f64 }
}

pub fn quantile(v: &[f64], q: f64) -> f64 {
	let mut s = v.to_vec();
	s.sort_by(f64::total_cmp);
	if s.is_empty() {
		return f64::NAN;
	}
	let h = (s.len() - 1) as f64 * q;
	let l = h.floor() as usize;
	s[l] + (h - l as f64) * (s[(l + 1).min(s.len() - 1)] - s[l])
}
