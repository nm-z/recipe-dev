//! Reverse-mode automatic differentiation over small row-major matrices, CPU only.
//! A tape is built eagerly (each node's value is computed when it is added) and run backward once.

#[derive(Clone, Debug)]
pub struct T {
	pub r: usize,
	pub c: usize,
	pub v: Vec<f64>,
}

impl T {
	pub fn zeros(r: usize, c: usize) -> T {
		T { r, c, v: vec![0.0; r * c] }
	}
	pub fn new(r: usize, c: usize, v: Vec<f64>) -> T {
		assert_eq!(v.len(), r * c, "tensor shape");
		T { r, c, v }
	}
	pub fn scalar(x: f64) -> T {
		T { r: 1, c: 1, v: vec![x] }
	}
	pub fn filled(r: usize, c: usize, x: f64) -> T {
		T { r, c, v: vec![x; r * c] }
	}
	pub fn at(&self, i: usize, j: usize) -> f64 {
		self.v[i * self.c + j]
	}
	fn add_assign(&mut self, o: &T) {
		debug_assert_eq!((self.r, self.c), (o.r, o.c));
		for (a, b) in self.v.iter_mut().zip(&o.v) {
			*a += b;
		}
	}
}

pub type Id = usize;

#[derive(Clone, Debug)]
enum Op {
	Const,
	Param(usize),
	MatMul(Id, Id),
	MatMulT(Id, Id),
	Transpose(Id),
	Add(Id, Id),
	Sub(Id, Id),
	Mul(Id, Id),
	AddRow(Id, Id),
	AddCol(Id, Id),
	MulCol(Id, Id),
	MulScalar(Id, Id),
	Scale(Id, f64),
	Gelu(Id),
	Tanh(Id),
	Sigmoid(Id),
	Softplus(Id),
	Ln(Id),
	Exp(Id),
	Square(Id),
	SoftmaxRows(Id),
	RowSq(Id),
	Sum(Id),
	ConcatCols(Vec<Id>),
	ConcatRows(Vec<Id>),
	SliceRows(Id, usize),
	ShiftRows(Id, isize),
	BlocksToCols(Id, usize),
	BroadcastRows(Id),
	StandardizeRows(Id, f64),
	StraightThrough(Id),
}

pub struct Tape {
	vals: Vec<T>,
	ops: Vec<Op>,
	rg: Vec<bool>,
}

fn gelu(x: f64) -> (f64, f64) {
	const A: f64 = 0.7978845608028654; // sqrt(2/pi)
	let u = A * (x + 0.044715 * x * x * x);
	let t = u.tanh();
	let y = 0.5 * x * (1.0 + t);
	let dy = 0.5 * (1.0 + t) + 0.5 * x * (1.0 - t * t) * A * (1.0 + 3.0 * 0.044715 * x * x);
	(y, dy)
}

pub fn softplus(x: f64) -> f64 {
	if x > 30.0 { x } else if x < -30.0 { x.exp() } else { (1.0 + x.exp()).ln() }
}

pub fn sigmoid(x: f64) -> f64 {
	if x >= 0.0 {
		1.0 / (1.0 + (-x).exp())
	} else {
		let e = x.exp();
		e / (1.0 + e)
	}
}

fn matmul(a: &T, b: &T) -> T {
	assert_eq!(a.c, b.r, "matmul shape {}x{} . {}x{}", a.r, a.c, b.r, b.c);
	let mut out = T::zeros(a.r, b.c);
	for i in 0..a.r {
		let orow = &mut out.v[i * b.c..(i + 1) * b.c];
		for k in 0..a.c {
			let x = a.v[i * a.c + k];
			if x == 0.0 {
				continue;
			}
			let brow = &b.v[k * b.c..(k + 1) * b.c];
			for (o, y) in orow.iter_mut().zip(brow) {
				*o += x * y;
			}
		}
	}
	out
}

/// a . b^T
fn matmul_t(a: &T, b: &T) -> T {
	assert_eq!(a.c, b.c, "matmul_t shape");
	let mut out = T::zeros(a.r, b.r);
	for i in 0..a.r {
		let arow = &a.v[i * a.c..(i + 1) * a.c];
		for j in 0..b.r {
			let brow = &b.v[j * b.c..(j + 1) * b.c];
			out.v[i * b.r + j] = arow.iter().zip(brow).map(|(x, y)| x * y).sum();
		}
	}
	out
}

/// a^T . b
fn t_matmul(a: &T, b: &T) -> T {
	assert_eq!(a.r, b.r, "t_matmul shape");
	let mut out = T::zeros(a.c, b.c);
	for k in 0..a.r {
		let brow = &b.v[k * b.c..(k + 1) * b.c];
		for i in 0..a.c {
			let x = a.v[k * a.c + i];
			if x == 0.0 {
				continue;
			}
			let orow = &mut out.v[i * b.c..(i + 1) * b.c];
			for (o, y) in orow.iter_mut().zip(brow) {
				*o += x * y;
			}
		}
	}
	out
}

fn transpose(a: &T) -> T {
	let mut out = T::zeros(a.c, a.r);
	for i in 0..a.r {
		for j in 0..a.c {
			out.v[j * a.r + i] = a.v[i * a.c + j];
		}
	}
	out
}

impl Default for Tape {
	fn default() -> Self {
		Self::new()
	}
}

impl Tape {
	pub fn new() -> Tape {
		Tape { vals: Vec::with_capacity(512), ops: Vec::with_capacity(512), rg: Vec::with_capacity(512) }
	}
	pub fn val(&self, id: Id) -> &T {
		&self.vals[id]
	}
	pub fn len(&self) -> usize {
		self.vals.len()
	}
	pub fn is_empty(&self) -> bool {
		self.vals.is_empty()
	}
	fn push(&mut self, v: T, op: Op, rg: bool) -> Id {
		self.vals.push(v);
		self.ops.push(op);
		self.rg.push(rg);
		self.vals.len() - 1
	}
	pub fn constant(&mut self, v: T) -> Id {
		self.push(v, Op::Const, false)
	}
	pub fn param(&mut self, v: T, index: usize) -> Id {
		self.push(v, Op::Param(index), true)
	}
	pub fn matmul(&mut self, a: Id, b: Id) -> Id {
		let v = matmul(&self.vals[a], &self.vals[b]);
		let rg = self.rg[a] || self.rg[b];
		self.push(v, Op::MatMul(a, b), rg)
	}
	/// a . b^T
	pub fn matmul_t(&mut self, a: Id, b: Id) -> Id {
		let v = matmul_t(&self.vals[a], &self.vals[b]);
		let rg = self.rg[a] || self.rg[b];
		self.push(v, Op::MatMulT(a, b), rg)
	}
	pub fn transpose(&mut self, a: Id) -> Id {
		let v = transpose(&self.vals[a]);
		let rg = self.rg[a];
		self.push(v, Op::Transpose(a), rg)
	}
	fn zip(&mut self, a: Id, b: Id, f: impl Fn(f64, f64) -> f64, op: Op) -> Id {
		let (x, y) = (&self.vals[a], &self.vals[b]);
		assert_eq!((x.r, x.c), (y.r, y.c), "elementwise shape {}x{} vs {}x{}", x.r, x.c, y.r, y.c);
		let v = T::new(x.r, x.c, x.v.iter().zip(&y.v).map(|(p, q)| f(*p, *q)).collect());
		let rg = self.rg[a] || self.rg[b];
		self.push(v, op, rg)
	}
	pub fn add(&mut self, a: Id, b: Id) -> Id {
		self.zip(a, b, |p, q| p + q, Op::Add(a, b))
	}
	pub fn sub(&mut self, a: Id, b: Id) -> Id {
		self.zip(a, b, |p, q| p - q, Op::Sub(a, b))
	}
	pub fn mul(&mut self, a: Id, b: Id) -> Id {
		self.zip(a, b, |p, q| p * q, Op::Mul(a, b))
	}
	/// a [r x c] + b [1 x c] on every row
	pub fn add_row(&mut self, a: Id, b: Id) -> Id {
		let (x, y) = (&self.vals[a], &self.vals[b]);
		assert!(y.r == 1 && y.c == x.c, "add_row shape");
		let mut v = x.clone();
		for i in 0..x.r {
			for j in 0..x.c {
				v.v[i * x.c + j] += y.v[j];
			}
		}
		let rg = self.rg[a] || self.rg[b];
		self.push(v, Op::AddRow(a, b), rg)
	}
	/// a [r x c] + b [r x 1] on every column
	pub fn add_col(&mut self, a: Id, b: Id) -> Id {
		let (x, y) = (&self.vals[a], &self.vals[b]);
		assert!(y.c == 1 && y.r == x.r, "add_col shape");
		let mut v = x.clone();
		for i in 0..x.r {
			for j in 0..x.c {
				v.v[i * x.c + j] += y.v[i];
			}
		}
		let rg = self.rg[a] || self.rg[b];
		self.push(v, Op::AddCol(a, b), rg)
	}
	/// a [r x c] * b [r x 1] on every column
	pub fn mul_col(&mut self, a: Id, b: Id) -> Id {
		let (x, y) = (&self.vals[a], &self.vals[b]);
		assert!(y.c == 1 && y.r == x.r, "mul_col shape");
		let mut v = x.clone();
		for i in 0..x.r {
			for j in 0..x.c {
				v.v[i * x.c + j] *= y.v[i];
			}
		}
		let rg = self.rg[a] || self.rg[b];
		self.push(v, Op::MulCol(a, b), rg)
	}
	/// a * s, with s a 1 x 1 node
	pub fn mul_scalar(&mut self, a: Id, s: Id) -> Id {
		let k = self.vals[s].v[0];
		assert_eq!(self.vals[s].v.len(), 1, "mul_scalar takes a 1 x 1 node");
		let x = &self.vals[a];
		let v = T::new(x.r, x.c, x.v.iter().map(|p| p * k).collect());
		let rg = self.rg[a] || self.rg[s];
		self.push(v, Op::MulScalar(a, s), rg)
	}
	pub fn scale(&mut self, a: Id, k: f64) -> Id {
		let x = &self.vals[a];
		let v = T::new(x.r, x.c, x.v.iter().map(|p| p * k).collect());
		let rg = self.rg[a];
		self.push(v, Op::Scale(a, k), rg)
	}
	fn map(&mut self, a: Id, f: impl Fn(f64) -> f64, op: Op) -> Id {
		let x = &self.vals[a];
		let v = T::new(x.r, x.c, x.v.iter().map(|p| f(*p)).collect());
		let rg = self.rg[a];
		self.push(v, op, rg)
	}
	pub fn gelu(&mut self, a: Id) -> Id {
		self.map(a, |x| gelu(x).0, Op::Gelu(a))
	}
	pub fn tanh(&mut self, a: Id) -> Id {
		self.map(a, f64::tanh, Op::Tanh(a))
	}
	pub fn sigmoid(&mut self, a: Id) -> Id {
		self.map(a, sigmoid, Op::Sigmoid(a))
	}
	pub fn softplus(&mut self, a: Id) -> Id {
		self.map(a, softplus, Op::Softplus(a))
	}
	pub fn ln(&mut self, a: Id) -> Id {
		self.map(a, f64::ln, Op::Ln(a))
	}
	pub fn exp(&mut self, a: Id) -> Id {
		self.map(a, f64::exp, Op::Exp(a))
	}
	pub fn square(&mut self, a: Id) -> Id {
		self.map(a, |x| x * x, Op::Square(a))
	}
	pub fn softmax_rows(&mut self, a: Id) -> Id {
		let x = &self.vals[a];
		let mut v = T::zeros(x.r, x.c);
		for i in 0..x.r {
			let row = &x.v[i * x.c..(i + 1) * x.c];
			let m = row.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
			let mut s = 0.0;
			for j in 0..x.c {
				let e = (row[j] - m).exp();
				v.v[i * x.c + j] = e;
				s += e;
			}
			for j in 0..x.c {
				v.v[i * x.c + j] /= s;
			}
		}
		let rg = self.rg[a];
		self.push(v, Op::SoftmaxRows(a), rg)
	}
	/// [r x c] -> [r x 1], the sum of squares of each row
	pub fn row_sq(&mut self, a: Id) -> Id {
		let x = &self.vals[a];
		let v = T::new(x.r, 1, (0..x.r).map(|i| x.v[i * x.c..(i + 1) * x.c].iter().map(|p| p * p).sum()).collect());
		let rg = self.rg[a];
		self.push(v, Op::RowSq(a), rg)
	}
	pub fn sum(&mut self, a: Id) -> Id {
		let s = self.vals[a].v.iter().sum();
		let rg = self.rg[a];
		self.push(T::scalar(s), Op::Sum(a), rg)
	}
	pub fn concat_cols(&mut self, ids: &[Id]) -> Id {
		let r = self.vals[ids[0]].r;
		let c: usize = ids.iter().map(|&i| self.vals[i].c).sum();
		let mut v = T::zeros(r, c);
		let mut off = 0;
		for &id in ids {
			let x = &self.vals[id];
			assert_eq!(x.r, r, "concat_cols rows");
			for i in 0..r {
				v.v[i * c + off..i * c + off + x.c].copy_from_slice(&x.v[i * x.c..(i + 1) * x.c]);
			}
			off += x.c;
		}
		let rg = ids.iter().any(|&i| self.rg[i]);
		self.push(v, Op::ConcatCols(ids.to_vec()), rg)
	}
	pub fn concat_rows(&mut self, ids: &[Id]) -> Id {
		let c = self.vals[ids[0]].c;
		let mut v = Vec::new();
		let mut r = 0;
		for &id in ids {
			let x = &self.vals[id];
			assert_eq!(x.c, c, "concat_rows cols");
			v.extend_from_slice(&x.v);
			r += x.r;
		}
		let rg = ids.iter().any(|&i| self.rg[i]);
		self.push(T::new(r, c, v), Op::ConcatRows(ids.to_vec()), rg)
	}
	pub fn slice_rows(&mut self, a: Id, start: usize, len: usize) -> Id {
		let x = &self.vals[a];
		let v = T::new(len, x.c, x.v[start * x.c..(start + len) * x.c].to_vec());
		let rg = self.rg[a];
		self.push(v, Op::SliceRows(a, start), rg)
	}
	/// out[i] = a[i - s], zero where i - s is out of range
	pub fn shift_rows(&mut self, a: Id, s: isize) -> Id {
		let x = &self.vals[a];
		let mut v = T::zeros(x.r, x.c);
		for i in 0..x.r as isize {
			let src = i - s;
			if src >= 0 && src < x.r as isize {
				let (i, src) = (i as usize, src as usize);
				v.v[i * x.c..(i + 1) * x.c].copy_from_slice(&x.v[src * x.c..(src + 1) * x.c]);
			}
		}
		let rg = self.rg[a];
		self.push(v, Op::ShiftRows(a, s), rg)
	}
	/// [nb*m x c] (nb row blocks of m rows) -> [m x nb*c] (the blocks side by side)
	pub fn blocks_to_cols(&mut self, a: Id, nb: usize) -> Id {
		let x = &self.vals[a];
		assert_eq!(x.r % nb, 0, "blocks_to_cols rows");
		let m = x.r / nb;
		let mut v = T::zeros(m, nb * x.c);
		for b in 0..nb {
			for j in 0..m {
				let src = (b * m + j) * x.c;
				let dst = j * nb * x.c + b * x.c;
				v.v[dst..dst + x.c].copy_from_slice(&x.v[src..src + x.c]);
			}
		}
		let rg = self.rg[a];
		self.push(v, Op::BlocksToCols(a, nb), rg)
	}
	/// Each row centered and divided by its standard deviation (plus eps): (x - mean) / sqrt(var + eps).
	pub fn standardize_rows(&mut self, a: Id, eps: f64) -> Id {
		let x = &self.vals[a];
		let mut v = T::zeros(x.r, x.c);
		for i in 0..x.r {
			let row = &x.v[i * x.c..(i + 1) * x.c];
			let m = row.iter().sum::<f64>() / x.c as f64;
			let var = row.iter().map(|q| (q - m) * (q - m)).sum::<f64>() / x.c as f64;
			let s = (var + eps).sqrt();
			for j in 0..x.c {
				v.v[i * x.c + j] = (row[j] - m) / s;
			}
		}
		let rg = self.rg[a];
		self.push(v, Op::StandardizeRows(a, eps), rg)
	}
	/// [1 x c] -> [r x c]
	pub fn broadcast_rows(&mut self, a: Id, r: usize) -> Id {
		let x = &self.vals[a];
		assert_eq!(x.r, 1, "broadcast_rows takes one row");
		let mut v = Vec::with_capacity(r * x.c);
		for _ in 0..r {
			v.extend_from_slice(&x.v);
		}
		let rg = self.rg[a];
		self.push(T::new(r, x.c, v), Op::BroadcastRows(a), rg)
	}
	/// Straight-through estimator: the forward value is `hard`, and the gradient passes to `soft` unchanged.
	pub fn straight_through(&mut self, soft: Id, hard: T) -> Id {
		let x = &self.vals[soft];
		assert_eq!((x.r, x.c), (hard.r, hard.c), "straight-through shape");
		let rg = self.rg[soft];
		self.push(hard, Op::StraightThrough(soft), rg)
	}

	/// Run backward from the scalar node `out`; returns the gradient of every parameter node as (param index, grad).
	pub fn backward(&self, out: Id) -> Vec<(usize, T)> {
		let n = self.vals.len();
		let mut g: Vec<Option<T>> = vec![None; n];
		g[out] = Some(T::filled(self.vals[out].r, self.vals[out].c, 1.0));
		let mut params = Vec::new();
		for i in (0..=out).rev() {
			if !self.rg[i] {
				continue;
			}
			let Some(gi) = g[i].take() else { continue };
			macro_rules! acc {
				($id:expr, $val:expr) => {{
					let id = $id;
					if self.rg[id] {
						let val = $val;
						match &mut g[id] {
							Some(t) => t.add_assign(&val),
							slot => *slot = Some(val),
						}
					}
				}};
			}
			match &self.ops[i] {
				Op::Const => {}
				Op::Param(p) => params.push((*p, gi)),
				Op::MatMul(a, b) => {
					acc!(*a, matmul_t(&gi, &self.vals[*b]));
					acc!(*b, t_matmul(&self.vals[*a], &gi));
				}
				Op::MatMulT(a, b) => {
					acc!(*a, matmul(&gi, &self.vals[*b]));
					acc!(*b, t_matmul(&gi, &self.vals[*a]));
				}
				Op::Transpose(a) => acc!(*a, transpose(&gi)),
				Op::Add(a, b) => {
					acc!(*a, gi.clone());
					acc!(*b, gi.clone());
				}
				Op::Sub(a, b) => {
					acc!(*a, gi.clone());
					acc!(*b, T::new(gi.r, gi.c, gi.v.iter().map(|x| -x).collect()));
				}
				Op::Mul(a, b) => {
					let (x, y) = (&self.vals[*a], &self.vals[*b]);
					acc!(*a, T::new(gi.r, gi.c, gi.v.iter().zip(&y.v).map(|(p, q)| p * q).collect()));
					acc!(*b, T::new(gi.r, gi.c, gi.v.iter().zip(&x.v).map(|(p, q)| p * q).collect()));
				}
				Op::AddRow(a, b) => {
					acc!(*a, gi.clone());
					let mut gb = T::zeros(1, gi.c);
					for r in 0..gi.r {
						for c in 0..gi.c {
							gb.v[c] += gi.v[r * gi.c + c];
						}
					}
					acc!(*b, gb);
				}
				Op::AddCol(a, b) => {
					acc!(*a, gi.clone());
					let gb = T::new(gi.r, 1, (0..gi.r).map(|r| gi.v[r * gi.c..(r + 1) * gi.c].iter().sum()).collect());
					acc!(*b, gb);
				}
				Op::MulCol(a, b) => {
					let (x, y) = (&self.vals[*a], &self.vals[*b]);
					let mut ga = gi.clone();
					let mut gb = T::zeros(gi.r, 1);
					for r in 0..gi.r {
						for c in 0..gi.c {
							ga.v[r * gi.c + c] *= y.v[r];
							gb.v[r] += gi.v[r * gi.c + c] * x.v[r * gi.c + c];
						}
					}
					acc!(*a, ga);
					acc!(*b, gb);
				}
				Op::MulScalar(a, s) => {
					let k = self.vals[*s].v[0];
					acc!(*a, T::new(gi.r, gi.c, gi.v.iter().map(|p| p * k).collect()));
					let gs: f64 = gi.v.iter().zip(&self.vals[*a].v).map(|(p, q)| p * q).sum();
					acc!(*s, T::scalar(gs));
				}
				Op::Scale(a, k) => acc!(*a, T::new(gi.r, gi.c, gi.v.iter().map(|p| p * k).collect())),
				Op::Gelu(a) => {
					let x = &self.vals[*a];
					acc!(*a, T::new(gi.r, gi.c, gi.v.iter().zip(&x.v).map(|(p, q)| p * gelu(*q).1).collect()));
				}
				Op::Tanh(a) => {
					let y = &self.vals[i];
					acc!(*a, T::new(gi.r, gi.c, gi.v.iter().zip(&y.v).map(|(p, q)| p * (1.0 - q * q)).collect()));
				}
				Op::Sigmoid(a) => {
					let y = &self.vals[i];
					acc!(*a, T::new(gi.r, gi.c, gi.v.iter().zip(&y.v).map(|(p, q)| p * q * (1.0 - q)).collect()));
				}
				Op::Softplus(a) => {
					let x = &self.vals[*a];
					acc!(*a, T::new(gi.r, gi.c, gi.v.iter().zip(&x.v).map(|(p, q)| p * sigmoid(*q)).collect()));
				}
				Op::Ln(a) => {
					let x = &self.vals[*a];
					acc!(*a, T::new(gi.r, gi.c, gi.v.iter().zip(&x.v).map(|(p, q)| p / q).collect()));
				}
				Op::Exp(a) => {
					let y = &self.vals[i];
					acc!(*a, T::new(gi.r, gi.c, gi.v.iter().zip(&y.v).map(|(p, q)| p * q).collect()));
				}
				Op::Square(a) => {
					let x = &self.vals[*a];
					acc!(*a, T::new(gi.r, gi.c, gi.v.iter().zip(&x.v).map(|(p, q)| 2.0 * p * q).collect()));
				}
				Op::SoftmaxRows(a) => {
					let y = &self.vals[i];
					let mut ga = T::zeros(gi.r, gi.c);
					for r in 0..gi.r {
						let row = r * gi.c..(r + 1) * gi.c;
						let dot: f64 = gi.v[row.clone()].iter().zip(&y.v[row.clone()]).map(|(p, q)| p * q).sum();
						for j in row {
							ga.v[j] = y.v[j] * (gi.v[j] - dot);
						}
					}
					acc!(*a, ga);
				}
				Op::RowSq(a) => {
					let x = &self.vals[*a];
					let mut ga = T::zeros(x.r, x.c);
					for r in 0..x.r {
						for c in 0..x.c {
							ga.v[r * x.c + c] = 2.0 * x.v[r * x.c + c] * gi.v[r];
						}
					}
					acc!(*a, ga);
				}
				Op::Sum(a) => {
					let x = &self.vals[*a];
					acc!(*a, T::filled(x.r, x.c, gi.v[0]));
				}
				Op::ConcatCols(ids) => {
					let mut off = 0;
					for &id in ids {
						let xc = self.vals[id].c;
						if self.rg[id] {
							let mut ga = T::zeros(gi.r, xc);
							for r in 0..gi.r {
								ga.v[r * xc..(r + 1) * xc].copy_from_slice(&gi.v[r * gi.c + off..r * gi.c + off + xc]);
							}
							acc!(id, ga);
						}
						off += xc;
					}
				}
				Op::ConcatRows(ids) => {
					let mut off = 0;
					for &id in ids {
						let xr = self.vals[id].r;
						if self.rg[id] {
							acc!(id, T::new(xr, gi.c, gi.v[off * gi.c..(off + xr) * gi.c].to_vec()));
						}
						off += xr;
					}
				}
				Op::SliceRows(a, start) => {
					let x = &self.vals[*a];
					let mut ga = T::zeros(x.r, x.c);
					ga.v[start * x.c..(start + gi.r) * x.c].copy_from_slice(&gi.v);
					acc!(*a, ga);
				}
				Op::ShiftRows(a, s) => {
					let x = &self.vals[*a];
					let mut ga = T::zeros(x.r, x.c);
					for r in 0..x.r as isize {
						let src = r - s;
						if src >= 0 && src < x.r as isize {
							let (r, src) = (r as usize, src as usize);
							for c in 0..x.c {
								ga.v[src * x.c + c] += gi.v[r * x.c + c];
							}
						}
					}
					acc!(*a, ga);
				}
				Op::BlocksToCols(a, nb) => {
					let x = &self.vals[*a];
					let m = x.r / nb;
					let mut ga = T::zeros(x.r, x.c);
					for b in 0..*nb {
						for j in 0..m {
							let dst = (b * m + j) * x.c;
							let src = j * nb * x.c + b * x.c;
							ga.v[dst..dst + x.c].copy_from_slice(&gi.v[src..src + x.c]);
						}
					}
					acc!(*a, ga);
				}
				Op::StandardizeRows(a, eps) => {
					let x = &self.vals[*a];
					let y = &self.vals[i];
					let c = x.c as f64;
					let mut ga = T::zeros(x.r, x.c);
					for r in 0..x.r {
						let row = r * x.c..(r + 1) * x.c;
						let m = x.v[row.clone()].iter().sum::<f64>() / c;
						let var = x.v[row.clone()].iter().map(|q| (q - m) * (q - m)).sum::<f64>() / c;
						let s = (var + eps).sqrt();
						let mg = gi.v[row.clone()].iter().sum::<f64>() / c;
						let mgy = gi.v[row.clone()].iter().zip(&y.v[row.clone()]).map(|(p, q)| p * q).sum::<f64>() / c;
						for j in row {
							ga.v[j] = (gi.v[j] - mg - y.v[j] * mgy) / s;
						}
					}
					acc!(*a, ga);
				}
				Op::BroadcastRows(a) => {
					let mut ga = T::zeros(1, gi.c);
					for r in 0..gi.r {
						for c in 0..gi.c {
							ga.v[c] += gi.v[r * gi.c + c];
						}
					}
					acc!(*a, ga);
				}
				Op::StraightThrough(soft) => acc!(*soft, gi.clone()),
			}
		}
		params
	}
}
