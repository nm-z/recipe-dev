//! Deterministic randomness. Every random choice in Remy derives from the one fixed seed.

/// Remy's one fixed seed (design rule 9). Recorded in every trace header and weights file.
pub const SEED: u64 = 20261006;

#[derive(Clone, Debug)]
pub struct Rng(u64);

/// Combine two values into one well-mixed 64-bit key (splitmix64 finalizer over a combination).
pub fn mix(a: u64, b: u64) -> u64 {
	let mut z = a ^ b.wrapping_mul(0x9E37_79B9_7F4A_7C15).rotate_left(31) ^ 0xD1B5_4A32_D192_ED03;
	z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
	z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
	z ^ (z >> 31)
}

/// FNV-1a of a string, for deriving a stream from a name.
pub fn hash_str(s: &str) -> u64 {
	let mut h: u64 = 0xcbf2_9ce4_8422_2325;
	for b in s.bytes() {
		h ^= b as u64;
		h = h.wrapping_mul(0x0000_0100_0000_01B3);
	}
	h
}

impl Rng {
	pub fn new(seed: u64) -> Rng {
		Rng(mix(seed, 0x5EED))
	}
	pub fn next_u64(&mut self) -> u64 {
		self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
		let mut z = self.0;
		z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
		z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
		z ^ (z >> 31)
	}
	/// Uniform in [0, 1).
	pub fn f64(&mut self) -> f64 {
		(self.next_u64() >> 11) as f64 / (1u64 << 53) as f64
	}
	pub fn range(&mut self, lo: f64, hi: f64) -> f64 {
		lo + (hi - lo) * self.f64()
	}
	/// Uniform integer in [0, n).
	pub fn below(&mut self, n: usize) -> usize {
		((self.f64() * n as f64) as usize).min(n.saturating_sub(1))
	}
	pub fn normal(&mut self) -> f64 {
		let u1 = self.f64().max(1e-300);
		let u2 = self.f64();
		(-2.0 * u1.ln()).sqrt() * (2.0 * std::f64::consts::PI * u2).cos()
	}
	pub fn chance(&mut self, p: f64) -> bool {
		self.f64() < p
	}
}
