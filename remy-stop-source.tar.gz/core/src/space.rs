//! The knob space: what Remy reads from space.json (only the `knobs` list: names, types, ranges, conditions),
//! the first guess, configuration text, the exploration entropy, and the per-knob encodings the models read.

use crate::json::{self, Json};
use crate::rng::{Rng, mix};

/// Linguini's softmax points for a continuous knob: 21 equal steps on its scale. The decoded value is the softmax's
/// mean position.
pub const GRID: usize = 21;
/// Value grid of a continuous knob: 1001 equal steps on its scale (the decoded mean is rounded to it; the middle
/// step is the median).
pub const FINE: usize = 1001;
/// Knob positions with their own rows in the embedding table (a knob at position k uses rows k mod MAXK).
pub const MAXK: usize = 16;
/// Distance floor in a continuous knob's nearest-neighbor entropy, so exact ties stay finite.
pub const ENT_DELTA: f64 = 0.005;

#[derive(Clone, Debug, PartialEq)]
pub enum Kind {
	Float { lo: f64, hi: f64, log: bool },
	Int { lo: f64, hi: f64, log: bool },
	Ordinal,
	Categorical,
}

#[derive(Clone, Debug)]
pub struct Knob {
	pub name: String,
	pub kind: Kind,
	/// Option text as sent to the adapter.
	pub text: Vec<String>,
	/// Option value as a number (NaN for a string).
	pub value: Vec<f64>,
	/// Option position on the knob's scale, in [0, 1].
	pub u: Vec<f64>,
	/// Active only when knob `.0` (an earlier knob) is active and takes one of the options `.1`.
	pub cond: Option<(usize, Vec<usize>)>,
}

impl Knob {
	pub fn n(&self) -> usize {
		self.text.len()
	}
	pub fn ordered(&self) -> bool {
		!matches!(self.kind, Kind::Categorical)
	}
	/// Positions of Linguini's softmax points: GRID equal steps for a continuous knob, the options otherwise.
	pub fn out_u(&self) -> Vec<f64> {
		if self.continuous() { (0..GRID).map(|o| o as f64 / (GRID - 1) as f64).collect() } else { self.u.clone() }
	}
	/// The option whose position is nearest u (the lower one on a tie); options are sorted by position.
	pub fn nearest(&self, u: f64) -> usize {
		let i = self.u.partition_point(|&x| x < u);
		if i == 0 {
			return 0;
		}
		if i >= self.u.len() {
			return self.u.len() - 1;
		}
		if (self.u[i] - u).abs() < (u - self.u[i - 1]).abs() { i } else { i - 1 }
	}
	/// A slider (continuous or integer): embedded by its exact position on its scale, not by option.
	pub fn continuous(&self) -> bool {
		matches!(self.kind, Kind::Float { .. } | Kind::Int { .. })
	}
	/// Row of this knob's type in the embedding table: continuous linear, continuous log, integer, ordinal, categorical.
	pub fn type_index(&self) -> usize {
		match self.kind {
			Kind::Float { log: false, .. } => 0,
			Kind::Float { log: true, .. } => 1,
			Kind::Int { .. } => 2,
			Kind::Ordinal => 3,
			Kind::Categorical => 4,
		}
	}
}

#[derive(Clone, Debug)]
pub struct Space {
	pub name: String,
	pub knobs: Vec<Knob>,
}

/// One option index per knob; None for an inactive conditional knob.
pub type Config = Vec<Option<usize>>;

/// A parsed configuration value.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Val {
	Off,
	Num(f64),
	Idx(usize),
}

pub fn fmt_num(v: f64) -> String {
	format!("{v}")
}

fn same_number(a: f64, b: f64) -> bool {
	a == b || (a - b).abs() <= 1e-9 * a.abs().max(b.abs())
}

impl Space {
	pub fn load(path: &str) -> Result<Space, String> {
		let text = std::fs::read_to_string(path).map_err(|e| format!("{path}: {e}"))?;
		let j = json::parse(&text).map_err(|e| format!("{path}: {e}"))?;
		Space::from_json(&j)
	}

	pub fn from_json(j: &Json) -> Result<Space, String> {
		let name = j.get("challenge").and_then(|c| c.as_str()).unwrap_or("challenge").to_string();
		let list = j.get("knobs").and_then(|k| k.as_arr()).ok_or("space.json has no knobs list")?;
		let mut knobs: Vec<Knob> = Vec::new();
		for (ki, kj) in list.iter().enumerate() {
			let kname = kj.get("name").and_then(|n| n.as_str()).ok_or(format!("knob {ki} has no name"))?.to_string();
			let ty = kj.get("type").and_then(|t| t.as_str()).ok_or(format!("{kname}: no type"))?;
			let num = |key: &str| kj.get(key).and_then(|v| v.as_f64()).ok_or(format!("{kname}: no numeric {key}"));
			let log = kj.get("scale").and_then(|s| s.as_str()) == Some("log");
			let (kind, text, value, u): (Kind, Vec<String>, Vec<f64>, Vec<f64>) = match ty {
				"categorical" | "ordinal" => {
					let vals = kj.get("values").and_then(|v| v.as_arr()).ok_or(format!("{kname}: no values"))?;
					if vals.is_empty() {
						return Err(format!("{kname}: empty values"));
					}
					let n = vals.len();
					let text: Vec<String> = vals.iter().map(|v| v.text()).collect();
					let value: Vec<f64> = vals.iter().map(|v| v.as_f64().unwrap_or(f64::NAN)).collect();
					let u = (0..n).map(|i| if n == 1 { 0.5 } else { i as f64 / (n - 1) as f64 }).collect();
					(if ty == "ordinal" { Kind::Ordinal } else { Kind::Categorical }, text, value, u)
				}
				"float" | "double" | "continuous" => {
					let (lo, hi) = (num("low")?, num("high")?);
					if !(hi > lo) || (log && lo <= 0.0) {
						return Err(format!("{kname}: bad range"));
					}
					let mut value = Vec::new();
					let mut u = Vec::new();
					for o in 0..FINE {
						let t = o as f64 / (FINE - 1) as f64;
						let v = if o == 0 {
							lo
						} else if o == FINE - 1 {
							hi
						} else if log {
							(lo.ln() + t * (hi.ln() - lo.ln())).exp().clamp(lo, hi)
						} else {
							(lo + t * (hi - lo)).clamp(lo, hi)
						};
						value.push(v);
						u.push(t);
					}
					(Kind::Float { lo, hi, log }, value.iter().map(|&v| fmt_num(v)).collect(), value, u)
				}
				"int" | "integer" => {
					let (lo, hi) = (num("low")?.round(), num("high")?.round());
					if !(hi > lo) || (log && lo <= 0.0) {
						return Err(format!("{kname}: bad range"));
					}
					let pos = |v: f64| if log { (v / lo).ln() / (hi / lo).ln() } else { (v - lo) / (hi - lo) };
					let mut value: Vec<f64> = Vec::new();
					if hi - lo + 1.0 <= FINE as f64 {
						let mut v = lo;
						while v <= hi {
							value.push(v);
							v += 1.0;
						}
					} else {
						for o in 0..FINE {
							let t = o as f64 / (FINE - 1) as f64;
							let v = if log { (lo.ln() + t * (hi.ln() - lo.ln())).exp() } else { lo + t * (hi - lo) };
							let v = v.round().clamp(lo, hi);
							if value.last() != Some(&v) {
								value.push(v);
							}
						}
					}
					let u = value.iter().map(|&v| pos(v)).collect();
					(Kind::Int { lo, hi, log }, value.iter().map(|&v| fmt_num(v)).collect(), value, u)
				}
				other => return Err(format!("{kname}: unknown type {other}")),
			};
			let cond = match kj.get("condition") {
				None | Some(Json::Null) => None,
				Some(c) => {
					let pname = c.get("parent").and_then(|p| p.as_str()).ok_or(format!("{kname}: condition without parent"))?;
					let p = knobs.iter().position(|k| k.name == pname).ok_or(format!("{kname}: parent {pname} must come earlier"))?;
					let allowed = c.get("values").and_then(|v| v.as_arr()).ok_or(format!("{kname}: condition without values"))?;
					let parent = &knobs[p];
					let mut idx = Vec::new();
					for a in allowed {
						let t = a.text();
						let hit = (0..parent.n()).find(|&o| parent.text[o] == t || a.as_f64().is_some_and(|x| same_number(x, parent.value[o])));
						idx.push(hit.ok_or(format!("{kname}: condition value {t} is not an option of {pname}"))?);
					}
					Some((p, idx))
				}
			};
			knobs.push(Knob { name: kname, kind, text, value, u, cond });
		}
		if knobs.is_empty() {
			return Err("space.json has no knobs".into());
		}
		Ok(Space { name, knobs })
	}

	pub fn k(&self) -> usize {
		self.knobs.len()
	}

	/// Whether knob k is active given the (already decided) values of the earlier knobs.
	pub fn active(&self, cfg: &[Option<usize>], k: usize) -> bool {
		match &self.knobs[k].cond {
			None => true,
			Some((p, allowed)) => cfg[*p].is_some_and(|o| allowed.contains(&o)),
		}
	}

	/// Set inactive knobs to None, so two configurations that differ only in inactive knobs are equal.
	pub fn canonical(&self, cfg: &[Option<usize>]) -> Config {
		let mut out: Config = cfg.to_vec();
		for k in 0..self.k() {
			if !self.active(&out, k) {
				out[k] = None;
			}
		}
		out
	}

	/// The design's first guess: every ordered knob at its median (the lower middle option for an even count;
	/// the middle of the scale, so the geometric middle on a log scale, for a continuous knob) and a pick from
	/// the fixed seed for each unordered knob.
	pub fn first_guess(&self, seed: u64) -> Config {
		let mut cfg: Config = Vec::with_capacity(self.k());
		for (k, kn) in self.knobs.iter().enumerate() {
			let o = match kn.kind {
				Kind::Categorical => Rng::new(mix(seed, 0xF1257 + k as u64)).below(kn.n()),
				Kind::Ordinal => (kn.n() - 1) / 2,
				Kind::Float { .. } | Kind::Int { .. } => {
					// the option nearest the middle of the scale; the lower one on a tie
					let mut best = 0;
					for o in 1..kn.n() {
						if (kn.u[o] - 0.5).abs() < (kn.u[best] - 0.5).abs() - 1e-12 {
							best = o;
						}
					}
					best
				}
			};
			cfg.push(Some(o));
		}
		self.canonical(&cfg)
	}

	/// `name=value,...` over the active knobs, in knob order.
	pub fn config_text(&self, cfg: &[Option<usize>]) -> String {
		let mut parts = Vec::new();
		for (k, kn) in self.knobs.iter().enumerate() {
			if let Some(o) = cfg[k] {
				parts.push(format!("{}={}", kn.name, kn.text[o]));
			}
		}
		parts.join(",")
	}

	/// The configuration's values (a grid option of a continuous knob becomes its number).
	pub fn values(&self, cfg: &[Option<usize>]) -> Vec<Val> {
		self.knobs
			.iter()
			.zip(cfg)
			.map(|(kn, o)| match o {
				None => Val::Off,
				Some(o) => match kn.kind {
					Kind::Float { .. } | Kind::Int { .. } => Val::Num(kn.value[*o]),
					_ => Val::Idx(*o),
				},
			})
			.collect()
	}

	/// Parse one configuration line, `name=value,...` or a flat JSON object. A discrete knob's value must be one
	/// of its options (else Err); a continuous knob's value is any number (the caller checks the range); a missing
	/// knob is Off.
	pub fn parse_line(&self, line: &str) -> Result<Vec<Val>, String> {
		let line = line.trim();
		let mut pairs: Vec<(String, String, Option<f64>)> = Vec::new();
		if line.starts_with('{') {
			let j = json::parse(line)?;
			if let Json::Obj(fields) = j {
				for (k, v) in fields {
					pairs.push((k, v.text(), v.as_f64()));
				}
			} else {
				return Err("not an object".into());
			}
		} else if !line.is_empty() {
			for field in line.split(',') {
				let (k, v) = field.split_once('=').ok_or(format!("expected name=value, got {field:?}"))?;
				let v = v.trim();
				pairs.push((k.trim().to_string(), v.to_string(), v.parse::<f64>().ok()));
			}
		}
		let mut out = vec![Val::Off; self.k()];
		for (name, text, num) in pairs {
			let k = self.knobs.iter().position(|kn| kn.name == name).ok_or(format!("unknown knob {name}"))?;
			if out[k] != Val::Off {
				return Err(format!("repeated knob {name}"));
			}
			let kn = &self.knobs[k];
			out[k] = match kn.kind {
				Kind::Float { .. } | Kind::Int { .. } => Val::Num(num.ok_or(format!("{name}: not a number"))?),
				_ => {
					let hit = (0..kn.n()).find(|&o| kn.text[o] == text || num.is_some_and(|x| !kn.value[o].is_nan() && same_number(x, kn.value[o])));
					Val::Idx(hit.ok_or(format!("{name}={text} is not one of its values"))?)
				}
			};
		}
		Ok(out)
	}

	/// Exploration entropy (design, Terms), from exact values with no bins: per knob, then averaged over the knobs.
	/// A knob with options: the entropy of the count of guesses per option over ln(option count). A continuous
	/// knob: the nearest-neighbor entropy of its [0,1] positions (see `continuous_entropy`). Inactive values are left
	/// out of a knob; knobs with a single option are left out of the average.
	pub fn exploration_entropy(&self, configs: &[Config]) -> f64 {
		let mut sum = 0.0;
		let mut count = 0;
		for (k, kn) in self.knobs.iter().enumerate() {
			if kn.continuous() {
				let us: Vec<f64> = configs.iter().filter_map(|c| c[k].map(|o| kn.u[o])).collect();
				sum += continuous_entropy(&us);
				count += 1;
			} else if kn.n() >= 2 {
				let mut c = vec![0.0; kn.n()];
				for cfg in configs {
					if let Some(o) = cfg[k] {
						c[o] += 1.0;
					}
				}
				sum += discrete_entropy(&c);
				count += 1;
			}
		}
		if count == 0 { 0.0 } else { sum / count as f64 }
	}

	/// Range features of the challenge (mean over knobs): decades spanned by a log-scale or positive ordinal
	/// knob, and the log of its option count.
	pub fn range_features(&self) -> [f64; 2] {
		let mut f = [0.0; 2];
		for kn in &self.knobs {
			let decades = match kn.kind {
				Kind::Float { lo, hi, log: true } | Kind::Int { lo, hi, log: true } => (hi / lo).log10(),
				Kind::Ordinal if kn.value[0] > 0.0 && kn.value[kn.n() - 1] > 0.0 => (kn.value[kn.n() - 1] / kn.value[0]).log10().abs(),
				_ => 0.0,
			};
			f[0] += (decades / 6.0).min(1.5);
			f[1] += ((kn.n() as f64).ln() / 40f64.ln()).min(1.0);
		}
		let k = self.k() as f64;
		[f[0] / k, f[1] / k]
	}

	pub fn random_config(&self, rng: &mut Rng) -> Config {
		let cfg: Config = self.knobs.iter().map(|kn| Some(rng.below(kn.n()))).collect();
		self.canonical(&cfg)
	}

	/// Number of distinct (canonical) configurations, capped at `cap`.
	pub fn count(&self, cap: f64) -> f64 {
		let mut total = 0.0;
		let mut cfg: Config = vec![Some(0); self.k()];
		self.count_from(0, &mut cfg, 1.0, &mut total, cap);
		total
	}
	fn count_from(&self, k: usize, cfg: &mut Config, mult: f64, total: &mut f64, cap: f64) {
		if *total > cap {
			return;
		}
		if k == self.k() {
			*total += mult;
			return;
		}
		if !self.active(cfg, k) {
			cfg[k] = None;
			self.count_from(k + 1, cfg, mult, total, cap);
			return;
		}
		// knobs that no later knob depends on multiply directly
		let is_parent = self.knobs[k + 1..].iter().any(|kn| kn.cond.as_ref().is_some_and(|(p, _)| *p == k));
		if !is_parent {
			cfg[k] = Some(0);
			self.count_from(k + 1, cfg, mult * self.knobs[k].n() as f64, total, cap);
		} else {
			for o in 0..self.knobs[k].n() {
				cfg[k] = Some(o);
				self.count_from(k + 1, cfg, mult, total, cap);
			}
		}
	}

	/// Every distinct (canonical) configuration.
	pub fn enumerate(&self) -> Vec<Config> {
		let mut out = Vec::new();
		let mut cfg: Config = vec![None; self.k()];
		self.enum_from(0, &mut cfg, &mut out);
		out
	}
	fn enum_from(&self, k: usize, cfg: &mut Config, out: &mut Vec<Config>) {
		if k == self.k() {
			out.push(cfg.clone());
			return;
		}
		if !self.active(cfg, k) {
			cfg[k] = None;
			self.enum_from(k + 1, cfg, out);
			return;
		}
		for o in 0..self.knobs[k].n() {
			cfg[k] = Some(o);
			self.enum_from(k + 1, cfg, out);
		}
		cfg[k] = None;
	}
}

/// Entropy of a knob with options from its per-option counts, over ln(option count): 0 when every guess is the
/// same option, 1 when the guesses spread evenly over the options.
pub fn discrete_entropy(counts: &[f64]) -> f64 {
	let n: f64 = counts.iter().sum();
	if counts.len() < 2 || n <= 0.0 {
		return 0.0;
	}
	let h: f64 = counts.iter().filter(|&&x| x > 0.0).map(|&x| -(x / n) * (x / n).ln()).sum();
	h / (counts.len() as f64).ln()
}

/// Nearest-neighbor (Kozachenko-Leonenko, k = 1, one dimension) entropy of positions on [0, 1], normalized.
/// The estimate is H = psi(N) + gamma + ln 2 + mean_i ln(rho_i), with rho_i the distance from guess i to its closest
/// other guess. Evenly spread guesses (0, 1/(N-1), ..., 1) have every rho_i = 1/(N-1); the normalized value is
/// exp(H - H_even) = (N - 1) * geometric_mean(rho_i): 1 for evenly spread guesses, 0 when they coincide. Exact ties
/// are common on a grid, so distances are floored as (N - 1) * (geometric_mean(rho_i + delta) - delta), which keeps
/// both end points (0 for identical guesses, 1 for evenly spread ones). Fewer than two guesses read 0.
pub fn continuous_entropy(us: &[f64]) -> f64 {
	let n = us.len();
	if n < 2 {
		return 0.0;
	}
	let mut s = us.to_vec();
	s.sort_by(f64::total_cmp);
	let mut lsum = 0.0;
	for i in 0..n {
		let left = if i > 0 { s[i] - s[i - 1] } else { f64::INFINITY };
		let right = if i + 1 < n { s[i + 1] - s[i] } else { f64::INFINITY };
		lsum += (left.min(right) + ENT_DELTA).ln();
	}
	(n - 1) as f64 * ((lsum / n as f64).exp() - ENT_DELTA)
}
