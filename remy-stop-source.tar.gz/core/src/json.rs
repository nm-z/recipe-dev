//! A small JSON reader: enough for space.json files and flat configuration objects.
//! Numbers keep their source text, so a value list prints back exactly as written.

#[derive(Clone, Debug)]
pub enum Json {
	Null,
	Bool(bool),
	Num(f64, String),
	Str(String),
	Arr(Vec<Json>),
	Obj(Vec<(String, Json)>),
}

impl Json {
	pub fn get(&self, key: &str) -> Option<&Json> {
		match self {
			Json::Obj(fields) => fields.iter().find(|(k, _)| k == key).map(|(_, v)| v),
			_ => None,
		}
	}
	pub fn as_str(&self) -> Option<&str> {
		match self {
			Json::Str(s) => Some(s),
			_ => None,
		}
	}
	pub fn as_f64(&self) -> Option<f64> {
		match self {
			Json::Num(v, _) => Some(*v),
			_ => None,
		}
	}
	pub fn as_arr(&self) -> Option<&[Json]> {
		match self {
			Json::Arr(a) => Some(a),
			_ => None,
		}
	}
	/// The value as configuration text: a string without quotes, a number as written.
	pub fn text(&self) -> String {
		match self {
			Json::Null => "null".into(),
			Json::Bool(b) => b.to_string(),
			Json::Num(_, raw) => raw.clone(),
			Json::Str(s) => s.clone(),
			Json::Arr(_) | Json::Obj(_) => String::new(),
		}
	}
}

pub fn parse(text: &str) -> Result<Json, String> {
	let mut p = Parser { s: text.as_bytes(), i: 0 };
	let v = p.value()?;
	p.ws();
	if p.i != p.s.len() {
		return Err(format!("trailing characters at byte {}", p.i));
	}
	Ok(v)
}

struct Parser<'a> {
	s: &'a [u8],
	i: usize,
}

impl Parser<'_> {
	fn ws(&mut self) {
		while self.i < self.s.len() && matches!(self.s[self.i], b' ' | b'\t' | b'\n' | b'\r') {
			self.i += 1;
		}
	}
	fn value(&mut self) -> Result<Json, String> {
		self.ws();
		match self.s.get(self.i) {
			None => Err("unexpected end".into()),
			Some(b'{') => {
				self.i += 1;
				let mut fields = Vec::new();
				self.ws();
				if self.s.get(self.i) == Some(&b'}') {
					self.i += 1;
					return Ok(Json::Obj(fields));
				}
				loop {
					self.ws();
					let k = self.string()?;
					self.ws();
					if self.s.get(self.i) != Some(&b':') {
						return Err(format!("expected ':' at byte {}", self.i));
					}
					self.i += 1;
					let v = self.value()?;
					fields.push((k, v));
					self.ws();
					match self.s.get(self.i) {
						Some(b',') => self.i += 1,
						Some(b'}') => {
							self.i += 1;
							return Ok(Json::Obj(fields));
						}
						_ => return Err(format!("expected ',' or '}}' at byte {}", self.i)),
					}
				}
			}
			Some(b'[') => {
				self.i += 1;
				let mut items = Vec::new();
				self.ws();
				if self.s.get(self.i) == Some(&b']') {
					self.i += 1;
					return Ok(Json::Arr(items));
				}
				loop {
					items.push(self.value()?);
					self.ws();
					match self.s.get(self.i) {
						Some(b',') => self.i += 1,
						Some(b']') => {
							self.i += 1;
							return Ok(Json::Arr(items));
						}
						_ => return Err(format!("expected ',' or ']' at byte {}", self.i)),
					}
				}
			}
			Some(b'"') => Ok(Json::Str(self.string()?)),
			Some(b't') => self.word("true", Json::Bool(true)),
			Some(b'f') => self.word("false", Json::Bool(false)),
			Some(b'n') => self.word("null", Json::Null),
			Some(_) => {
				let start = self.i;
				while self.i < self.s.len() && matches!(self.s[self.i], b'-' | b'+' | b'.' | b'e' | b'E' | b'0'..=b'9') {
					self.i += 1;
				}
				let raw = std::str::from_utf8(&self.s[start..self.i]).map_err(|e| e.to_string())?;
				let v: f64 = raw.parse().map_err(|_| format!("bad number {raw:?} at byte {start}"))?;
				Ok(Json::Num(v, raw.to_string()))
			}
		}
	}
	fn word(&mut self, w: &str, v: Json) -> Result<Json, String> {
		if self.s[self.i..].starts_with(w.as_bytes()) {
			self.i += w.len();
			Ok(v)
		} else {
			Err(format!("bad literal at byte {}", self.i))
		}
	}
	fn hex4(&mut self) -> Result<u32, String> {
		let h = self.s.get(self.i..self.i + 4).ok_or("short \\u escape")?;
		self.i += 4;
		u32::from_str_radix(std::str::from_utf8(h).map_err(|e| e.to_string())?, 16).map_err(|e| e.to_string())
	}
	fn string(&mut self) -> Result<String, String> {
		if self.s.get(self.i) != Some(&b'"') {
			return Err(format!("expected string at byte {}", self.i));
		}
		self.i += 1;
		let mut out: Vec<u8> = Vec::new();
		loop {
			let c = *self.s.get(self.i).ok_or("unterminated string")?;
			self.i += 1;
			match c {
				b'"' => break,
				b'\\' => {
					let e = *self.s.get(self.i).ok_or("bad escape")?;
					self.i += 1;
					match e {
						b'"' => out.push(b'"'),
						b'\\' => out.push(b'\\'),
						b'/' => out.push(b'/'),
						b'b' => out.push(8),
						b'f' => out.push(12),
						b'n' => out.push(b'\n'),
						b'r' => out.push(b'\r'),
						b't' => out.push(b'\t'),
						b'u' => {
							let mut cp = self.hex4()?;
							if (0xD800..0xDC00).contains(&cp) && self.s.get(self.i..self.i + 2) == Some(b"\\u") {
								self.i += 2;
								let lo = self.hex4()?;
								cp = 0x10000 + ((cp - 0xD800) << 10) + (lo.wrapping_sub(0xDC00) & 0x3FF);
							}
							let ch = char::from_u32(cp).unwrap_or('\u{FFFD}');
							let mut buf = [0u8; 4];
							out.extend_from_slice(ch.encode_utf8(&mut buf).as_bytes());
						}
						_ => return Err("bad escape".into()),
					}
				}
				_ => out.push(c),
			}
		}
		String::from_utf8(out).map_err(|e| e.to_string())
	}
}

/// Quote a string for JSON output.
pub fn quote(s: &str) -> String {
	let mut out = String::from("\"");
	for ch in s.chars() {
		match ch {
			'"' => out.push_str("\\\""),
			'\\' => out.push_str("\\\\"),
			'\n' => out.push_str("\\n"),
			'\t' => out.push_str("\\t"),
			c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
			c => out.push(c),
		}
	}
	out.push('"');
	out
}
