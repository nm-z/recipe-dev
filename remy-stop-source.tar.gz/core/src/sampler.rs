//! First-order pretraining's synthetic data: seeded optimization problems that generalize `exp/remy.rs`'s Problem.
//!
//! A problem has 2 to 12 knobs of every type (continuous on a linear or log scale, ordinal, categorical, and
//! conditional knobs that are inactive unless a parent has one of some values), with plateaus, interactions,
//! irrelevant knobs, invalid regions, and a known optimum. Each problem writes its own space.json and acts as its
//! own adapter. Problem ids below 800000 are for training, and 900000 and above are validation.

use crate::json::quote;
use crate::rng::{Rng, mix};
use crate::space::{Space, Val, fmt_num};

pub const TRAIN_MAX: u64 = 800_000;
pub const VALID_MIN: u64 = 900_000;
/// Reference size when the space is too big (or continuous) to enumerate.
pub const REF_SAMPLE: usize = 2000;
/// Enumerate the space as the reference when it has at most this many configurations.
pub const REF_EXHAUSTIVE: f64 = 20_000.0;

#[derive(Clone, Debug)]
enum PKind {
	Float { lo: f64, hi: f64, log: bool },
	Ordinal(Vec<f64>),
	Categorical(Vec<String>),
}

#[derive(Clone, Debug)]
struct PKnob {
	name: String,
	kind: PKind,
	cond: Option<(usize, Vec<usize>)>,
	/// Weight of the main effect (0 for an irrelevant knob).
	w: f64,
	/// Ordered knobs: the optimum's position on the scale, the cost exponent, and the plateau levels (0: none).
	ustar: f64,
	pow: f64,
	q: usize,
	/// Categorical knobs: the optimum option, and every option's cost (0 at the optimum).
	opt: usize,
	catcost: Vec<f64>,
}

impl PKnob {
	fn ordered(&self) -> bool {
		!matches!(self.kind, PKind::Categorical(_))
	}
	fn n(&self) -> usize {
		match &self.kind {
			PKind::Float { .. } => 0,
			PKind::Ordinal(v) => v.len(),
			PKind::Categorical(v) => v.len(),
		}
	}
}

#[derive(Clone, Debug)]
enum Inter {
	/// w |d_a| |d_b|
	Prod(usize, usize, f64),
	/// w (d_a - d_b)^2 with signed distances: the two knobs trade off along a diagonal
	Diff(usize, usize, f64),
	/// w [a off its optimum] |d_b|
	CatOrd(usize, usize, f64),
}

#[derive(Clone, Debug)]
enum Region {
	/// invalid when categorical knob a takes option `bad` and ordered knob b is beyond `thr`
	CatSide { a: usize, bad: usize, b: usize, thr: f64, above: bool },
	/// invalid inside a box in two ordered knobs
	Box { a: usize, b: usize, la: f64, ha: f64, lb: f64, hb: f64 },
	/// invalid beyond a threshold of one ordered knob
	Edge { a: usize, thr: f64, above: bool },
}

#[derive(Clone, Debug)]
enum Out {
	Linear { base: f64, scale: f64 },
	Exp { base: f64, gamma: f64 },
	Sat { base: f64, scale: f64, c: f64 },
}

#[derive(Clone, Debug)]
pub struct Problem {
	pub id: u64,
	knobs: Vec<PKnob>,
	inter: Vec<Inter>,
	regions: Vec<Region>,
	out: Out,
	wsum: f64,
	noise: f64,
	/// The space exactly as Remy reads it, parsed from this problem's space.json.
	pub space: Space,
}

fn sig3(x: f64) -> f64 {
	format!("{x:.2e}").parse().unwrap()
}

const WORDS: [&str; 8] = ["alpha", "beta", "gamma", "delta", "eps", "zeta", "eta", "theta"];

impl Problem {
	/// Problem <id>: drawn from its seed, re-drawn (with the next sub-seed) until Remy's grid over its space has at least
	/// 100 configurations, so a 24-guess run can't exhaust it.
	pub fn new(id: u64) -> Problem {
		for attempt in 0u64.. {
			let p = Problem::generate(id, mix(id, 0x5A3_71E ^ (attempt << 32)));
			if p.space.count(100.0) >= 100.0 {
				return p;
			}
		}
		unreachable!()
	}

	fn generate(id: u64, seed: u64) -> Problem {
		let mut r = Rng::new(seed);
		let k = 2 + r.below(11);
		let mut knobs: Vec<PKnob> = Vec::with_capacity(k);
		for i in 0..k {
			let parents: Vec<usize> = (0..i).filter(|&j| matches!(knobs[j].kind, PKind::Categorical(_)) && knobs[j].cond.is_none()).collect();
			let cond = if !parents.is_empty() && r.chance(0.2) {
				let p = parents[r.below(parents.len())];
				let np = knobs[p].n();
				let mut set: Vec<usize> = (0..np).filter(|_| r.chance(0.5)).collect();
				if set.is_empty() {
					set.push(r.below(np));
				}
				if set.len() == np {
					set.remove(r.below(np));
				}
				Some((p, set))
			} else {
				None
			};
			let x = r.f64();
			let kind = if x < 0.22 {
				let lo = if r.chance(0.5) { 0.0 } else { sig3(r.range(-10.0, 10.0)) };
				let hi = sig3(lo + 10f64.powf(r.range(-1.0, 2.0)));
				PKind::Float { lo, hi: if hi > lo { hi } else { lo + 1.0 }, log: false }
			} else if x < 0.40 {
				let lo = sig3(10f64.powf(r.range(-6.0, 0.0)));
				let hi = sig3(lo * 10f64.powf(r.range(1.0, 4.0)));
				PKind::Float { lo, hi, log: true }
			} else if x < 0.70 {
				let n = 3 + r.below(8);
				let vals: Vec<f64> = match r.below(3) {
					0 => {
						let a = r.below(6) as i32;
						(0..n).map(|i| 2f64.powi(a + i as i32)).collect()
					}
					1 => {
						let start = r.below(10) as f64;
						let step = [1.0, 2.0, 5.0, 10.0][r.below(4)];
						(0..n).map(|i| start + step * i as f64).collect()
					}
					_ => {
						let step = [0.05, 0.1, 0.25][r.below(3)];
						(0..n).map(|i| ((i as f64 * step) * 1e6).round() / 1e6).collect()
					}
				};
				PKind::Ordinal(vals)
			} else {
				let n = 2 + r.below(5);
				let off = r.below(WORDS.len());
				PKind::Categorical((0..n).map(|j| WORDS[(off + j) % WORDS.len()].to_string()).collect())
			};
			let w = if r.chance(0.78) { 10f64.powf(r.range(-1.0, 0.5)) } else { 0.0 };
			let mut ustar = if r.chance(0.25) { if r.chance(0.5) { 0.0 } else { 1.0 } } else { r.f64() };
			if let PKind::Ordinal(v) = &kind {
				let n = v.len();
				ustar = (ustar * (n - 1) as f64).round() / (n - 1) as f64;
			}
			let pow = [0.5, 1.0, 2.0][r.below(3)];
			let q = if r.chance(0.5) { 0 } else { 4 + r.below(17) };
			let (opt, catcost) = if let PKind::Categorical(v) = &kind {
				let opt = r.below(v.len());
				(opt, (0..v.len()).map(|o| if o == opt { 0.0 } else { r.range(0.15, 1.0) }).collect())
			} else {
				(0, vec![])
			};
			knobs.push(PKnob { name: format!("x{i}"), kind, cond, w, ustar, pow, q, opt, catcost });
		}
		if knobs.iter().all(|kn| kn.w == 0.0) {
			knobs[0].w = 1.0;
		}
		let relevant: Vec<usize> = (0..k).filter(|&i| knobs[i].w > 0.0).collect();
		let mut inter = Vec::new();
		for _ in 0..r.below(4) {
			if relevant.len() < 2 {
				break;
			}
			let a = relevant[r.below(relevant.len())];
			let b = relevant[r.below(relevant.len())];
			if a == b {
				continue;
			}
			let w = 10f64.powf(r.range(-0.7, 0.5));
			match (knobs[a].ordered(), knobs[b].ordered()) {
				(true, true) => inter.push(if r.chance(0.5) { Inter::Prod(a, b, w) } else { Inter::Diff(a, b, w) }),
				(false, true) => inter.push(Inter::CatOrd(a, b, w)),
				(true, false) => inter.push(Inter::CatOrd(b, a, w)),
				_ => {}
			}
		}
		let mut regions = Vec::new();
		let nreg = [0, 1, 1, 2][r.below(4)];
		let ordered: Vec<usize> = (0..k).filter(|&i| knobs[i].ordered()).collect();
		let cats: Vec<usize> = (0..k).filter(|&i| !knobs[i].ordered() && knobs[i].cond.is_none()).collect();
		for _ in 0..nreg {
			for _attempt in 0..10 {
				let choice = r.below(3);
				if choice == 0 && !cats.is_empty() && !ordered.is_empty() {
					let a = cats[r.below(cats.len())];
					let b = ordered[r.below(ordered.len())];
					let n = knobs[a].n();
					let mut bad = r.below(n);
					if bad == knobs[a].opt {
						bad = (bad + 1) % n;
					}
					regions.push(Region::CatSide { a, bad, b, thr: r.range(0.3, 0.7), above: r.chance(0.5) });
					break;
				}
				if choice == 1 && ordered.len() >= 2 {
					let a = ordered[r.below(ordered.len())];
					let b = ordered[r.below(ordered.len())];
					if a == b {
						continue;
					}
					let la = r.range(0.0, 0.7);
					let ha = la + r.range(0.2, 0.5);
					let lb = r.range(0.0, 0.7);
					let hb = lb + r.range(0.2, 0.5);
					let inside = |u: f64, l: f64, h: f64| u >= l && u <= h;
					if inside(knobs[a].ustar, la, ha) && inside(knobs[b].ustar, lb, hb) {
						continue;
					}
					regions.push(Region::Box { a, b, la, ha, lb, hb });
					break;
				}
				if choice == 2 && !ordered.is_empty() {
					let a = ordered[r.below(ordered.len())];
					let us = knobs[a].ustar;
					let thr = r.range(0.55, 0.9);
					if us < thr - 0.02 {
						regions.push(Region::Edge { a, thr, above: true });
						break;
					}
					let thr = r.range(0.1, 0.45);
					if us > thr + 0.02 {
						regions.push(Region::Edge { a, thr, above: false });
						break;
					}
				}
			}
		}
		let out = match r.below(10) {
			0..=4 => Out::Linear { base: 10f64.powf(r.range(-3.0, 1.0)), scale: 10f64.powf(r.range(-2.0, 1.0)) },
			5..=7 => Out::Exp { base: 10f64.powf(r.range(-3.0, 1.0)), gamma: r.range(1.0, 8.0) },
			_ => Out::Sat { base: 10f64.powf(r.range(-3.0, 1.0)), scale: 10f64.powf(r.range(-2.0, 1.0)), c: r.range(0.5, 3.0) },
		};
		let noise = if r.chance(0.5) { r.range(0.0, 0.1) } else { 0.0 };
		let wsum = knobs.iter().map(|kn| kn.w).sum::<f64>()
			+ inter.iter().map(|t| match t {
				Inter::Prod(_, _, w) | Inter::Diff(_, _, w) | Inter::CatOrd(_, _, w) => *w,
			})
			.sum::<f64>();
		let mut p = Problem { id, knobs, inter, regions, out, wsum, noise, space: Space { name: String::new(), knobs: vec![] } };
		p.space = Space::from_json(&crate::json::parse(&p.space_json()).expect("sampler space.json parses")).expect("sampler space");
		// keep at least a quarter of the space valid: drop invalid regions (last first) until it is
		let mut check = Rng::new(mix(id, 0xC4EC));
		while !p.regions.is_empty() {
			let valid = (0..400).filter(|_| p.score(&p.random_values(&mut check)).is_some()).count();
			if valid >= 100 {
				break;
			}
			p.regions.pop();
		}
		p
	}

	pub fn space_json(&self) -> String {
		let mut ks = Vec::new();
		for kn in &self.knobs {
			let mut s = format!("    {{\"name\": {}", quote(&kn.name));
			match &kn.kind {
				PKind::Float { lo, hi, log } => {
					s += &format!(", \"type\": \"float\", \"low\": {}, \"high\": {}, \"scale\": \"{}\"", fmt_num(*lo), fmt_num(*hi), if *log { "log" } else { "linear" })
				}
				PKind::Ordinal(v) => s += &format!(", \"type\": \"ordinal\", \"values\": [{}]", v.iter().map(|x| fmt_num(*x)).collect::<Vec<_>>().join(", ")),
				PKind::Categorical(v) => s += &format!(", \"type\": \"categorical\", \"values\": [{}]", v.iter().map(|x| quote(x)).collect::<Vec<_>>().join(", ")),
			}
			if let Some((p, set)) = &kn.cond {
				let PKind::Categorical(pv) = &self.knobs[*p].kind else { unreachable!() };
				s += &format!(
					", \"condition\": {{\"parent\": {}, \"values\": [{}]}}",
					quote(&self.knobs[*p].name),
					set.iter().map(|&o| quote(&pv[o])).collect::<Vec<_>>().join(", ")
				);
			}
			s.push('}');
			ks.push(s);
		}
		format!(
			"{{\n  \"challenge\": \"synthetic-{}\",\n  \"benchmark\": \"Remy first-order sampler problem {} ({})\",\n  \"objective\": {{\"name\": \"score\", \"goal\": \"minimize\"}},\n  \"knobs\": [\n{}\n  ]\n}}\n",
			self.id,
			self.id,
			if self.id >= VALID_MIN { "validation" } else if self.id < TRAIN_MAX { "training" } else { "unassigned" },
			ks.join(",\n")
		)
	}

	/// The problem's score for one configuration, or None if it is invalid.
	pub fn score(&self, vals: &[Val]) -> Option<f64> {
		let k = self.knobs.len();
		if vals.len() != k {
			return None;
		}
		let mut u = vec![f64::NAN; k];
		let mut idx = vec![usize::MAX; k];
		let mut act = vec![false; k];
		for i in 0..k {
			let kn = &self.knobs[i];
			act[i] = match &kn.cond {
				None => true,
				Some((p, set)) => act[*p] && set.contains(&idx[*p]),
			};
			if !act[i] {
				continue;
			}
			match (&kn.kind, vals[i]) {
				(PKind::Float { lo, hi, log }, Val::Num(x)) => {
					let tol = 1e-9 * (hi - lo).abs().max(hi.abs());
					if !(x >= lo - tol && x <= hi + tol) || !x.is_finite() {
						return None;
					}
					let x = x.clamp(*lo, *hi);
					u[i] = if *log { (x / lo).ln() / (hi / lo).ln() } else { (x - lo) / (hi - lo) };
				}
				(PKind::Ordinal(v), Val::Idx(j)) if j < v.len() => {
					idx[i] = j;
					u[i] = j as f64 / (v.len() - 1) as f64;
				}
				(PKind::Categorical(v), Val::Idx(j)) if j < v.len() => idx[i] = j,
				_ => return None,
			}
		}
		for reg in &self.regions {
			let bad = match *reg {
				Region::CatSide { a, bad, b, thr, above } => act[a] && act[b] && idx[a] == bad && if above { u[b] > thr } else { u[b] < thr },
				Region::Box { a, b, la, ha, lb, hb } => act[a] && act[b] && u[a] >= la && u[a] <= ha && u[b] >= lb && u[b] <= hb,
				Region::Edge { a, thr, above } => act[a] && if above { u[a] > thr } else { u[a] < thr },
			};
			if bad {
				return None;
			}
		}
		let signed = |i: usize| {
			let kn = &self.knobs[i];
			let uq = if kn.q > 0 { (u[i] * kn.q as f64).round() / kn.q as f64 } else { u[i] };
			uq - kn.ustar
		};
		let mut f = 0.0;
		for i in 0..k {
			let kn = &self.knobs[i];
			if !act[i] || kn.w == 0.0 {
				continue;
			}
			f += kn.w * if kn.ordered() { signed(i).abs().powf(kn.pow) } else { kn.catcost[idx[i]] };
		}
		for t in &self.inter {
			match *t {
				Inter::Prod(a, b, w) if act[a] && act[b] => f += w * signed(a).abs() * signed(b).abs(),
				Inter::Diff(a, b, w) if act[a] && act[b] => f += w * (signed(a) - signed(b)).powi(2),
				Inter::CatOrd(a, b, w) if act[a] && act[b] => f += w * (idx[a] != self.knobs[a].opt) as u8 as f64 * signed(b).abs(),
				_ => {}
			}
		}
		let mut f = f / self.wsum.max(1e-9);
		if self.noise > 0.0 {
			let mut h = mix(self.id, 0x0015E);
			for i in 0..k {
				let v = if act[i] { if u[i].is_nan() { idx[i] as u64 } else { (u[i] * 1e9).round() as u64 } } else { u64::MAX };
				h = mix(h, v);
			}
			let h01 = (h >> 11) as f64 / (1u64 << 53) as f64;
			f *= 1.0 + self.noise * (2.0 * h01 - 1.0);
		}
		Some(match self.out {
			Out::Linear { base, scale } => base + scale * f,
			Out::Exp { base, gamma } => base * (gamma * f).exp(),
			Out::Sat { base, scale, c } => base + scale * (1.0 - (-c * f).exp()),
		})
	}

	/// The known optimum's score (every knob at its optimum).
	pub fn optimum(&self) -> f64 {
		match self.out {
			Out::Linear { base, .. } | Out::Exp { base, .. } | Out::Sat { base, .. } => base,
		}
	}

	/// A uniformly random configuration over the knob space (continuous knobs uniform on their scale).
	pub fn random_values(&self, r: &mut Rng) -> Vec<Val> {
		let k = self.knobs.len();
		let mut vals = vec![Val::Off; k];
		let mut idx = vec![usize::MAX; k];
		let mut act = vec![false; k];
		for i in 0..k {
			let kn = &self.knobs[i];
			act[i] = match &kn.cond {
				None => true,
				Some((p, set)) => act[*p] && set.contains(&idx[*p]),
			};
			if !act[i] {
				continue;
			}
			vals[i] = match &kn.kind {
				PKind::Float { lo, hi, log } => {
					let t = r.f64();
					Val::Num(if *log { (lo.ln() + t * (hi.ln() - lo.ln())).exp().clamp(*lo, *hi) } else { lo + t * (hi - lo) })
				}
				PKind::Ordinal(_) | PKind::Categorical(_) => {
					let j = r.below(kn.n());
					idx[i] = j;
					Val::Idx(j)
				}
			};
		}
		vals
	}

	/// The reference: every configuration when the space is discrete and small enough, otherwise 2,000 seeded
	/// random ones. Scores sorted ascending; an invalid configuration counts as +inf (worse than any score).
	pub fn reference(&self) -> Vec<f64> {
		let discrete = self.knobs.iter().all(|kn| !matches!(kn.kind, PKind::Float { .. }));
		let mut out: Vec<f64> = if discrete && self.space.count(REF_EXHAUSTIVE) <= REF_EXHAUSTIVE {
			self.space.enumerate().iter().map(|c| self.score(&self.space.values(c)).unwrap_or(f64::INFINITY)).collect()
		} else {
			let mut r = Rng::new(mix(self.id, 0x4EF));
			(0..REF_SAMPLE).map(|_| self.score(&self.random_values(&mut r)).unwrap_or(f64::INFINITY)).collect()
		};
		out.sort_by(f64::total_cmp);
		out
	}

	pub fn has_invalid_region(&self) -> bool {
		!self.regions.is_empty()
	}

	/// Serve as an adapter: read configurations from stdin, one per line, and print each score or `invalid`.
	pub fn serve(&self) {
		use std::io::{BufRead, Write};
		let stdin = std::io::stdin();
		let mut out = std::io::stdout().lock();
		for line in stdin.lock().lines() {
			let Ok(line) = line else { break };
			if line.trim().is_empty() {
				continue;
			}
			let reply = match self.space.parse_line(&line) {
				Ok(vals) => match self.score(&vals) {
					Some(s) => format!("{s:?}"),
					None => "invalid".into(),
				},
				Err(_) => "invalid".into(),
			};
			if writeln!(out, "{reply}").and_then(|_| out.flush()).is_err() {
				break;
			}
		}
	}
}

/// Share of the reference that scores strictly worse than `best` (0 when the run found no valid configuration).
pub fn percentile(best: Option<f64>, reference: &[f64]) -> f64 {
	match best {
		None => 0.0,
		Some(b) => {
			let worse = reference.len() - reference.partition_point(|&x| x <= b);
			worse as f64 / reference.len() as f64
		}
	}
}
