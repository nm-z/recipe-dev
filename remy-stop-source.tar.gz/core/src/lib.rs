//! Remy's first order as a standalone program: Linguini, the score RAT and the validity RAT; the first-order
//! sampler; first-order pretraining (Reptile). See ~/Documents/Nate's Vault/Remy/design-v2.md.

pub mod eval;
pub mod gp;
pub mod json;
pub mod model;
pub mod pretrain;
pub mod remy;
pub mod rng;
pub mod sampler;
pub mod sha256;
pub mod space;
pub mod tape;
