//! One Remy run: 24 guesses on one challenge from an empty history, with the live values reset at the start.
//!
//! Each guess after the first: the score RAT and the validity RAT each train on the whole history so far (a fixed
//! number of steps), then Linguini trains through the frozen RATs (a fixed number of steps) on
//! L(x) = s_hat(x) - ln P_valid(x) - lambda * H(x), then proposes. Decoding rejects configurations already guessed.

use crate::model::{Adam, Ctx, KnobHist, KnobIn, LinHist, Models, NSIG, RatHist, decode, entropy_node};
use crate::rng::{SEED, mix};
use crate::space::{Config, GRID, Space};
use crate::tape::{Id, T, Tape};
use std::collections::HashSet;
use std::time::Instant;

struct Terms {
	s_hat: Id,
	nlp: Id,
	neg_lh: Option<Id>,
	total: Id,
}

struct LossGraph {
	tape: Tape,
	cfg: Config,
	fallback: bool,
	probs: Vec<Id>,
	terms: Option<Terms>,
}

/// Settings fixed before any result (design rule 7).
#[derive(Clone, Debug)]
pub struct Settings {
	pub guesses: usize,
	pub rat_steps: usize,
	pub lin_steps: usize,
	pub lr_rat: f64,
	pub lr_lin: f64,
	pub lambda: f64,
	pub clip: f64,
	/// Score RAT units: its targets are rank scores in [-score_scale, score_scale].
	pub score_scale: f64,
	/// Label smoothing of the validity RAT's targets (1 - smooth for valid, smooth for invalid).
	pub smooth: f64,
	/// Linguini's softmax temperature over a categorical knob's standardized logits.
	pub tau: f64,
	/// Linguini's softmax temperature over an ordered knob's standardized logits.
	pub tau_ordered: f64,
	/// Which knobs decode at their softmax's mean position (the others take the most probable point): 0 none, 1 continuous
	/// knobs, 2 continuous and ordinal knobs.
	pub mean_decode: u8,
	/// Diagnostic only (0 in Remy): when above 0, replace Linguini by brute force: the configuration with the lowest
	/// L(x) among this many random and local candidates.
	pub oracle: usize,
}

impl Default for Settings {
	fn default() -> Settings {
		Settings { guesses: 24, rat_steps: 20, lin_steps: 50, lr_rat: 0.01, lr_lin: 0.03, lambda: 10.0, clip: 5.0, score_scale: 1.0, smooth: 0.05, tau: crate::model::LOGIT_TEMP, tau_ordered: crate::model::ORDERED_TEMP, mean_decode: 0, oracle: 0 }
	}
}

impl Settings {
	pub fn describe(&self) -> String {
		format!(
			"guesses {} rat_steps {} lin_steps {} lr_rat {} lr_lin {} lambda {} clip {} score_scale {} smooth {} tau {} tau_ordered {} mean_decode {} oracle {} widths D {} DA {} DV {} HID {}",
			self.guesses,
			self.rat_steps,
			self.lin_steps,
			self.lr_rat,
			self.lr_lin,
			self.lambda,
			self.clip,
			self.score_scale,
			self.smooth,
			self.tau,
			self.tau_ordered,
			self.mean_decode,
			self.oracle,
			crate::model::D,
			crate::model::DA,
			crate::model::DV,
			crate::model::HID
		)
	}
}

#[derive(Clone, Debug)]
pub struct Guess {
	pub cfg: Config,
	pub score: Option<f64>,
	pub secs: f64,
}

#[derive(Clone, Debug, Default)]
pub struct Diag {
	/// Training steps skipped because a loss or gradient wasn't finite.
	pub nonfinite: usize,
	/// Proposals that fell back to a seeded random configuration.
	pub fallbacks: usize,
	/// Repeated configurations (decoding should make this 0).
	pub repeats: usize,
}

/// What the models read about the history, prepared once per guess.
struct Prepared {
	b: T,
	n: usize,
	valid: Vec<bool>,
	y: Vec<f64>,
	srat: RatHist,
	vrat: RatHist,
	lin: LinHist,
	knobs: Vec<KnobHist>,
	seen: HashSet<Config>,
}

fn symlog(x: f64) -> f64 {
	x.signum() * x.abs().ln_1p()
}

fn prepare(space: &Space, ctx: &Ctx, hist: &[Guess], score_scale: f64) -> Prepared {
	let n = hist.len();
	let refs: Vec<&Config> = hist.iter().map(|g| &g.cfg).collect();
	let b = ctx.encode(&refs);
	let valid: Vec<bool> = hist.iter().map(|g| g.score.is_some()).collect();
	// rank score among valid guesses, in (-1, 1), lower is better; ties share their mean rank
	let mut idx: Vec<usize> = (0..n).filter(|&i| valid[i]).collect();
	idx.sort_by(|&a, &b| hist[a].score.unwrap().total_cmp(&hist[b].score.unwrap()));
	let nv = idx.len();
	let mut y = vec![0.0; n];
	let mut i = 0;
	while i < nv {
		let mut j = i;
		while j + 1 < nv && hist[idx[j + 1]].score == hist[idx[i]].score {
			j += 1;
		}
		let rank = (i + j) as f64 / 2.0;
		for t in i..=j {
			y[idx[t]] = score_scale * (2.0 * (rank + 0.5) / nv as f64 - 1.0);
		}
		i = j + 1;
	}
	// score relative to the run's first valid guess, (s - s1) / |s1|
	let s1 = hist.iter().find_map(|g| g.score);
	let mut sig = T::zeros(n, NSIG);
	for (i, g) in hist.iter().enumerate() {
		if let (Some(s), Some(s1)) = (g.score, s1) {
			let den = if s1 != 0.0 { s1.abs() } else { 1.0 };
			let r = (s - s1) / den;
			sig.v[i * NSIG] = 1.0;
			sig.v[i * NSIG + 1] = y[i];
			sig.v[i * NSIG + 2] = symlog(r).clamp(-3.0, 3.0) / 3.0;
		}
	}
	let srat = RatHist { b: b.clone(), sig: sig.clone(), chan: y.clone(), valid: valid.clone(), n };
	let vrat = RatHist { b: b.clone(), sig: sig.clone(), chan: valid.iter().map(|&v| if v { 1.0 } else { -1.0 }).collect(), valid: valid.clone(), n };
	let lin = LinHist { b: b.clone(), sig, n };
	let knobs = space
		.knobs
		.iter()
		.enumerate()
		.map(|(k, kn)| {
			let mut counts = vec![0.0; kn.n()];
			let mut us = Vec::new();
			for g in hist {
				if let Some(o) = g.cfg[k] {
					counts[o] += 1.0;
					us.push(kn.u[o]);
				}
			}
			KnobHist { counts, us }
		})
		.collect();
	let seen = hist.iter().map(|g| g.cfg.clone()).collect();
	Prepared { b, n, valid, y, srat, vrat, lin, knobs, seen }
}

pub struct Remy<'a> {
	pub space: &'a Space,
	pub ctx: Ctx,
	pub models: Models,
	adam: [Adam; 3],
	pub st: Settings,
	pub diag: Diag,
	/// When set, each guess records the per-term gradient sizes (see `term_gradients`) after the RATs train.
	pub probe: Option<Vec<[f64; 7]>>,
}

impl<'a> Remy<'a> {
	/// A new run: the given fixed values, live values at 0, fresh optimizer state.
	pub fn new(space: &'a Space, mut models: Models, st: Settings) -> Remy<'a> {
		models.reset_live();
		models.lin.tau = st.tau;
		models.lin.tau_ordered = st.tau_ordered;
		models.lin.mean_decode = st.mean_decode;
		let adam = [Adam::new(&models.lin.ps), Adam::new(&models.srat.ps), Adam::new(&models.vrat.ps)];
		Remy { ctx: Ctx::new(space), space, models, adam, st, diag: Diag::default(), probe: None }
	}

	fn train_score_rat(&mut self, pr: &Prepared) {
		let n = pr.n;
		let nv = pr.valid.iter().filter(|&&v| v).count();
		if nv == 0 {
			return;
		}
		let target = T::new(n, 1, pr.y.clone());
		let weight = T::new(n, 1, pr.valid.iter().map(|&v| if v { 1.0 / nv as f64 } else { 0.0 }).collect());
		for _ in 0..self.st.rat_steps {
			let mut tape = Tape::new();
			let p = self.models.srat.ps.nodes(&mut tape, true);
			let cand = tape.constant(pr.b.clone());
			let out = self.models.srat.forward(&mut tape, &p, &self.ctx, cand, n, &pr.srat, true);
			let t = tape.constant(target.clone());
			let d = tape.sub(out, t);
			let sq = tape.square(d);
			let w = tape.constant(weight.clone());
			let wl = tape.mul(sq, w);
			let loss = tape.sum(wl);
			if !tape.val(loss).v[0].is_finite() {
				self.diag.nonfinite += 1;
				continue;
			}
			let g = tape.backward(loss);
			if !self.adam[1].step(&mut self.models.srat.ps, g, self.st.lr_rat, self.st.clip) {
				self.diag.nonfinite += 1;
			}
		}
	}

	fn train_validity_rat(&mut self, pr: &Prepared) {
		let n = pr.n;
		// binary cross-entropy with label smoothing: weights on softplus(-l) (valid) and softplus(l) (invalid)
		let e = self.st.smooth;
		let wa = T::new(n, 1, pr.valid.iter().map(|&v| if v { 1.0 - e } else { e }).collect());
		let wb = T::new(n, 1, pr.valid.iter().map(|&v| if v { e } else { 1.0 - e }).collect());
		for _ in 0..self.st.rat_steps {
			let mut tape = Tape::new();
			let p = self.models.vrat.ps.nodes(&mut tape, true);
			let cand = tape.constant(pr.b.clone());
			let out = self.models.vrat.forward(&mut tape, &p, &self.ctx, cand, n, &pr.vrat, true);
			let neg = tape.scale(out, -1.0);
			let a = tape.softplus(neg);
			let b = tape.softplus(out);
			let ca = tape.constant(wa.clone());
			let cb = tape.constant(wb.clone());
			let la = tape.mul(a, ca);
			let lb = tape.mul(b, cb);
			let s = tape.add(la, lb);
			let tot = tape.sum(s);
			let loss = tape.scale(tot, 1.0 / n as f64);
			if !tape.val(loss).v[0].is_finite() {
				self.diag.nonfinite += 1;
				continue;
			}
			let g = tape.backward(loss);
			if !self.adam[2].step(&mut self.models.vrat.ps, g, self.st.lr_rat, self.st.clip) {
				self.diag.nonfinite += 1;
			}
		}
	}

	/// Linguini's forward pass and decoding, then (with `loss`) the loss through the frozen RATs.
	///
	/// Decoding: a categorical knob takes its softmax's most probable option; an ordered knob takes the value at its
	/// softmax's mean position (a continuous knob: the mean rounded to its 1001-step value grid; an ordinal knob: the
	/// option nearest the mean). The backward pass treats the decoding as the identity (straight-through): the
	/// gradient reaches the softmax (a knob with options) or its mean (a continuous knob).
	///
	/// With `pinned = Some((cfg, p0))` the configuration is not decoded: each active knob's input is `hard + p - p0`
	/// (or `hard_u + mean - mean0`), a smooth stand-in whose derivative at p = p0 equals the straight-through
	/// gradient; the finite-difference check uses it.
	fn build(&self, pr: &Prepared, guess: usize, loss: bool, pinned: Option<(&Config, &[T])>) -> LossGraph {
		let k = self.ctx.k;
		let mut tape = Tape::new();
		let p = self.models.lin.ps.nodes(&mut tape, true);
		let logits = self.models.lin.forward(&mut tape, &p, &self.ctx, &pr.lin);
		let probs: Vec<_> = logits.iter().map(|&l| tape.softmax_rows(l)).collect();
		let outs: Vec<Vec<f64>> = self.space.knobs.iter().map(|kn| kn.out_u()).collect();
		let means: Vec<Option<Id>> = (0..k)
			.map(|kk| {
				if self.space.knobs[kk].continuous() || (self.st.mean_decode >= 2 && self.space.knobs[kk].ordered()) {
					let col = tape.constant(T::new(outs[kk].len(), 1, outs[kk].clone()));
					Some(tape.matmul(probs[kk], col))
				} else {
					None
				}
			})
			.collect();
		let (cfg, fallback) = match pinned {
			Some((c, _)) => (c.clone(), false),
			None => {
				let alts: Vec<Vec<(usize, f64)>> = (0..k)
					.map(|kk| {
						let kn = &self.space.knobs[kk];
						let pv = &tape.val(probs[kk]).v;
						match means[kk] {
							Some(_) if self.st.mean_decode == 0 => {
								// a continuous knob decoded at its most probable point
								let mut a: Vec<(usize, f64)> = pv.iter().enumerate().map(|(j, q)| (kn.nearest(outs[kk][j]), q.max(1e-300).ln())).collect();
								a.sort_by(|x, y| y.1.total_cmp(&x.1).then(x.0.cmp(&y.0)));
								a
							}
							None => {
								let mut a: Vec<(usize, f64)> = pv.iter().enumerate().map(|(o, q)| (o, q.max(1e-300).ln())).collect();
								a.sort_by(|x, y| y.1.total_cmp(&x.1).then(x.0.cmp(&y.0)));
								a
							}
							Some(m) => {
								let mu = tape.val(m).v[0];
								let mut cands: Vec<usize> = if kn.continuous() {
									let mut c = vec![kn.nearest(mu)];
									c.extend(outs[kk].iter().map(|&v| kn.nearest(v)));
									c
								} else {
									(0..kn.n()).collect()
								};
								cands.sort_by(|&x, &y| (kn.u[x] - mu).abs().total_cmp(&(kn.u[y] - mu).abs()).then(x.cmp(&y)));
								cands.dedup();
								let mut seen_o = HashSet::new();
								cands.retain(|o| seen_o.insert(*o));
								cands.into_iter().map(|o| (o, -((kn.u[o] - mu) * (GRID - 1) as f64).powi(2))).collect()
							}
						}
					})
					.collect();
				decode(self.space, &alts, &pr.seen, mix(SEED, 0xDEC0DE ^ guess as u64))
			}
		};
		let mut g = LossGraph { tape, cfg, fallback, probs, terms: None };
		if !loss {
			return g;
		}
		let tape = &mut g.tape;
		let mut parts = vec![tape.constant(self.ctx.type_sel.clone())];
		let mut inputs = Vec::with_capacity(k);
		for kk in 0..k {
			let kn = &self.space.knobs[kk];
			match g.cfg[kk] {
				None => {
					parts.push(tape.constant(self.ctx.inactive[kk].clone()));
					inputs.push(KnobIn::Off);
				}
				Some(o) if kn.continuous() => {
					let mean = means[kk].unwrap();
					let hard = kn.u[o];
					let u = match pinned {
						None if self.st.mean_decode == 0 => {
							// straight-through one-hot over the softmax points, then its position
							let j = outs[kk].iter().enumerate().fold(0, |b, (j, &v)| if (v - hard).abs() < (outs[kk][b] - hard).abs() { j } else { b });
							let mut oh = T::zeros(1, outs[kk].len());
							oh.v[j] = 1.0;
							let e = tape.straight_through(g.probs[kk], oh);
							let col = tape.constant(T::new(outs[kk].len(), 1, outs[kk].clone()));
							tape.matmul(e, col)
						}
						None => tape.straight_through(mean, T::scalar(hard)),
						Some((_, p0)) => {
							let mean0: f64 = p0[kk].v.iter().zip(&outs[kk]).map(|(q, v)| q * v).sum();
							let off = tape.constant(T::scalar(hard - mean0));
							tape.add(mean, off)
						}
					};
					let cu = tape.constant(self.ctx.cont_unit[kk].clone());
					parts.push(tape.matmul(u, cu));
					inputs.push(KnobIn::Cont(u));
				}
				Some(o) => {
					let nk = kn.n();
					let mut hard = T::zeros(1, nk);
					hard.v[o] = 1.0;
					let e = match pinned {
						None => tape.straight_through(g.probs[kk], hard),
						Some((_, p0)) => {
							let off = tape.constant(T::new(1, nk, hard.v.iter().zip(&p0[kk].v).map(|(h, q)| h - q).collect()));
							tape.add(g.probs[kk], off)
						}
					};
					let sk = tape.constant(self.ctx.sel[kk].clone());
					parts.push(tape.matmul(e, sk));
					inputs.push(KnobIn::Disc(e));
				}
			}
		}
		let mut cand = parts[0];
		for &q in &parts[1..] {
			cand = tape.add(cand, q);
		}
		let ps = self.models.srat.ps.nodes(tape, false);
		let s_hat = self.models.srat.forward(tape, &ps, &self.ctx, cand, 1, &pr.srat, false);
		let pv = self.models.vrat.ps.nodes(tape, false);
		let l = self.models.vrat.forward(tape, &pv, &self.ctx, cand, 1, &pr.vrat, false);
		let nl = tape.scale(l, -1.0);
		let nlp = tape.softplus(nl);
		let mut total = tape.add(s_hat, nlp);
		let h = entropy_node(tape, self.space, &pr.knobs, &inputs);
		let mut neg_lh = None;
		if let Some(h) = h {
			let lh = tape.scale(h, -self.st.lambda);
			total = tape.add(total, lh);
			neg_lh = Some(lh);
		}
		g.terms = Some(Terms { s_hat, nlp, neg_lh, total });
		g
	}

	/// One training step of Linguini through the frozen RATs.
	fn linguini_step(&mut self, pr: &Prepared, guess: usize) {
		let g = self.build(pr, guess, true, None);
		let t = g.terms.unwrap();
		if !g.tape.val(t.total).v[0].is_finite() {
			self.diag.nonfinite += 1;
			return;
		}
		let grads = g.tape.backward(t.total);
		if !self.adam[0].step(&mut self.models.lin.ps, grads, self.st.lr_lin, self.st.clip) {
			self.diag.nonfinite += 1;
		}
	}

	/// Per-term gradient sizes with respect to Linguini's parameters at the current state: the global L2 norm of
	/// d(s_hat)/d(theta), d(-ln P_valid)/d(theta) and d(-lambda H)/d(theta), plus the term values.
	pub fn term_gradients(&self, hist: &[Guess]) -> [f64; 6] {
		let pr = prepare(self.space, &self.ctx, hist, self.st.score_scale);
		let g = self.build(&pr, hist.len(), true, None);
		let t = g.terms.unwrap();
		let norm = |id: Option<Id>| -> f64 {
			id.map(|id| g.tape.backward(id).iter().flat_map(|(_, t)| t.v.iter()).map(|x| x * x).sum::<f64>().sqrt()).unwrap_or(0.0)
		};
		let val = |id: Option<Id>| id.map(|id| g.tape.val(id).v[0]).unwrap_or(0.0);
		[norm(Some(t.s_hat)), norm(Some(t.nlp)), norm(t.neg_lh), val(Some(t.s_hat)), val(Some(t.nlp)), val(t.neg_lh)]
	}

	/// Finite-difference check of each loss term's straight-through gradient with respect to Linguini's parameters
	/// (every parameter tensor, biases included, `per` coordinates each). Returns one row per checked coordinate:
	/// (term, parameter name, coordinate, analytic, numeric).
	pub fn check_term_gradients(&mut self, hist: &[Guess], per: usize) -> Vec<(usize, String, usize, f64, f64)> {
		let pr = prepare(self.space, &self.ctx, hist, self.st.score_scale);
		let g0 = self.build(&pr, hist.len(), true, None);
		let cfg = g0.cfg.clone();
		let p0: Vec<T> = g0.probs.iter().map(|&pid| g0.tape.val(pid).clone()).collect();
		let t0 = g0.terms.unwrap();
		let ids = [Some(t0.s_hat), Some(t0.nlp), t0.neg_lh];
		let mut out = Vec::new();
		let h: f64 = std::env::var("REMY_FD_H").ok().and_then(|s| s.parse().ok()).unwrap_or(1e-5);
		for (term, id) in ids.iter().enumerate() {
			let Some(id) = id else { continue };
			let grads = g0.tape.backward(*id);
			for pi in 0..self.models.lin.ps.names.len() {
				let len = self.models.lin.ps.live[pi].len();
				let analytic: Vec<f64> = grads.iter().find(|(i, _)| *i == pi).map(|(_, t)| t.v.clone()).unwrap_or(vec![0.0; len]);
				let mut rng = crate::rng::Rng::new(mix(pi as u64, term as u64));
				for _ in 0..per.min(len) {
					// prefer coordinates with a nonzero analytic gradient so the check is informative
					let mut j = rng.below(len);
					for _ in 0..20 {
						if analytic[j] != 0.0 {
							break;
						}
						j = rng.below(len);
					}
					let base = self.models.lin.ps.live[pi][j];
					let eval = |delta: f64, me: &mut Self| {
						me.models.lin.ps.live[pi][j] = base + delta;
						let g = me.build(&pr, hist.len(), true, Some((&cfg, &p0)));
						let t = g.terms.unwrap();
						let id = [Some(t.s_hat), Some(t.nlp), t.neg_lh][term].unwrap();
						g.tape.val(id).v[0]
					};
					let plus = eval(h, self);
					let minus = eval(-h, self);
					self.models.lin.ps.live[pi][j] = base;
					out.push((term, self.models.lin.ps.names[pi].clone(), j, analytic[j], (plus - minus) / (2.0 * h)));
				}
			}
		}
		out
	}

	/// Choose the next configuration from the history so far.
	pub fn propose(&mut self, hist: &[Guess]) -> Config {
		if hist.is_empty() {
			return self.space.first_guess(SEED);
		}
		let pr = prepare(self.space, &self.ctx, hist, self.st.score_scale);
		self.train_rats(&pr);
		if self.probe.is_some() {
			let t = self.term_gradients(hist);
			let invalid = hist.iter().any(|g| g.score.is_none()) as u8 as f64;
			self.probe.as_mut().unwrap().push([t[0], t[1], t[2], t[3], t[4], t[5], invalid]);
		}
		if self.st.oracle > 0 {
			return self.oracle(hist, &pr);
		}
		for _ in 0..self.st.lin_steps {
			self.linguini_step(&pr, hist.len());
		}
		let g = self.build(&pr, hist.len(), false, None);
		if g.fallback {
			self.diag.fallbacks += 1;
		}
		g.cfg
	}

	fn train_rats(&mut self, pr: &Prepared) {
		self.train_score_rat(pr);
		self.train_validity_rat(pr);
	}

	/// Train both RATs on the history, as the start of a guess does (for diagnostics).
	pub fn train_rats_on(&mut self, hist: &[Guess]) {
		let pr = prepare(self.space, &self.ctx, hist, self.st.score_scale);
		self.train_rats(&pr);
	}

	/// A full run. `measure` returns the score, or None for an invalid configuration. `on_guess` sees each guess
	/// after it is measured, with the Remy state that proposed it.
	pub fn run(&mut self, measure: &mut dyn FnMut(&Config) -> Option<f64>, on_guess: &mut dyn FnMut(usize, &Guess)) -> Vec<Guess> {
		self.models.reset_live();
		self.adam = [Adam::new(&self.models.lin.ps), Adam::new(&self.models.srat.ps), Adam::new(&self.models.vrat.ps)];
		let mut hist: Vec<Guess> = Vec::with_capacity(self.st.guesses);
		for t in 0..self.st.guesses {
			let start = Instant::now();
			let cfg = self.propose(&hist);
			let secs = start.elapsed().as_secs_f64();
			if hist.iter().any(|g| g.cfg == cfg) {
				self.diag.repeats += 1;
			}
			let score = measure(&cfg).filter(|s| s.is_finite());
			let g = Guess { cfg, score, secs };
			on_guess(t + 1, &g);
			hist.push(g);
		}
		if !self.models.finite() {
			self.diag.nonfinite += 1;
		}
		hist
	}
}

/// The best (lowest) valid score of a run, if any.
pub fn best(hist: &[Guess]) -> Option<f64> {
	hist.iter().filter_map(|g| g.score).min_by(f64::total_cmp)
}

impl Remy<'_> {
	/// Both RATs' predictions for candidate configurations given a history (as at the start of a guess, before any
	/// training on it): (predicted rank score, predicted probability of being valid) per candidate.
	pub fn predict(&self, hist: &[Guess], cands: &[Config]) -> Vec<(f64, f64)> {
		let pr = prepare(self.space, &self.ctx, hist, self.st.score_scale);
		let m = cands.len();
		let refs: Vec<&Config> = cands.iter().collect();
		let b = self.ctx.encode(&refs);
		let mut tape = Tape::new();
		let cb = tape.constant(b);
		let ps = self.models.srat.ps.nodes(&mut tape, false);
		let s = self.models.srat.forward(&mut tape, &ps, &self.ctx, cb, m, &pr.srat, false);
		let pv = self.models.vrat.ps.nodes(&mut tape, false);
		let l = self.models.vrat.forward(&mut tape, &pv, &self.ctx, cb, m, &pr.vrat, false);
		(0..m).map(|j| (tape.val(s).v[j], crate::tape::sigmoid(tape.val(l).v[j]))).collect()
	}
}

impl Remy<'_> {
	/// Diagnostic only: minimize L(x) = s_hat - ln P_valid - lambda H over random and local candidates by brute
	/// force, with the same trained RATs, to separate the RATs and the loss from Linguini's optimization.
	fn oracle(&self, hist: &[Guess], pr: &Prepared) -> Config {
		let mut rng = crate::rng::Rng::new(mix(SEED, 0x0AC1E ^ hist.len() as u64));
		let best = hist.iter().filter(|g| g.score.is_some()).min_by(|a, b| a.score.unwrap().total_cmp(&b.score.unwrap())).map(|g| g.cfg.clone());
		let mut cands: Vec<Config> = Vec::new();
		for i in 0..self.st.oracle {
			let c = match (&best, i % 2) {
				(Some(b), 1) => {
					let mut c = b.clone();
					let k = rng.below(self.space.k());
					c[k] = Some(rng.below(self.space.knobs[k].n()));
					let k2 = rng.below(self.space.k());
					if rng.chance(0.5) {
						c[k2] = Some(rng.below(self.space.knobs[k2].n()));
					}
					let full: Config = c.iter().enumerate().map(|(k, o)| Some(o.unwrap_or_else(|| rng.below(self.space.knobs[k].n())))).collect();
					self.space.canonical(&full)
				}
				_ => self.space.random_config(&mut rng),
			};
			if !pr.seen.contains(&c) {
				cands.push(c);
			}
		}
		let mut best_c = cands[0].clone();
		let mut best_l = f64::INFINITY;
		let configs: Vec<Config> = hist.iter().map(|g| g.cfg.clone()).collect();
		for chunk in cands.chunks(50) {
			let preds = self.predict(hist, chunk);
			for (c, (s, pv)) in chunk.iter().zip(preds) {
				let mut all = configs.clone();
				all.push(c.clone());
				let h = self.space.exploration_entropy(&all);
				let l = s - pv.max(1e-300).ln() - self.st.lambda * h;
				if l < best_l {
					best_l = l;
					best_c = c.clone();
				}
			}
		}
		best_c
	}
}

/// Meta-gradients for the fixed values of the three models (0 Linguini, 1 score RAT, 2 validity RAT), summed over
/// contributions, with the number of contributions per model.
#[derive(Clone, Debug)]
pub struct MetaGrads {
	pub g: [Vec<Vec<f64>>; 3],
	pub n: [f64; 3],
}

impl MetaGrads {
	pub fn new(m: &Models) -> MetaGrads {
		let z = |ps: &crate::model::ParamSet| ps.fixed.iter().map(|f| vec![0.0; f.len()]).collect::<Vec<_>>();
		MetaGrads { g: [z(&m.lin.ps), z(&m.srat.ps), z(&m.vrat.ps)], n: [0.0; 3] }
	}
	/// Add one contribution; skipped entirely if any gradient isn't finite.
	fn add(&mut self, s: usize, grads: Vec<(usize, T)>) -> bool {
		if !grads.iter().all(|(_, t)| t.v.iter().all(|x| x.is_finite())) {
			return false;
		}
		for (i, t) in grads {
			for (a, b) in self.g[s][i].iter_mut().zip(&t.v) {
				*a += b;
			}
		}
		self.n[s] += 1.0;
		true
	}
	pub fn merge(&mut self, o: &MetaGrads) {
		for s in 0..3 {
			for (a, b) in self.g[s].iter_mut().zip(&o.g[s]) {
				for (x, y) in a.iter_mut().zip(b) {
					*x += y;
				}
			}
			self.n[s] += o.n[s];
		}
	}
	/// The mean gradient of model `s` in the form Adam takes.
	pub fn mean(&self, s: usize, ps: &crate::model::ParamSet) -> Vec<(usize, T)> {
		let k = if self.n[s] > 0.0 { 1.0 / self.n[s] } else { 0.0 };
		self.g[s].iter().enumerate().map(|(i, v)| (i, T::new(ps.shapes[i].0, ps.shapes[i].1, v.iter().map(|x| x * k).collect()))).collect()
	}
}

/// What first-order pretraining (meta) adds to a practice run.
#[derive(Clone, Debug)]
pub struct MetaCfg {
	/// Query configurations per guess on which the RATs' predictions are scored (half random, half near the best).
	pub queries: usize,
	/// Collect Linguini's gradient of L at the start of each guess.
	pub lin: bool,
	/// Collect the RATs' query-prediction gradients.
	pub rats: bool,
}

impl Remy<'_> {
	/// A configuration one or two knobs away from `b`.
	fn local_move(&self, b: &Config, rng: &mut crate::rng::Rng) -> Config {
		let mut c = b.clone();
		let k = rng.below(self.space.k());
		c[k] = Some(rng.below(self.space.knobs[k].n()));
		if rng.chance(0.5) {
			let k2 = rng.below(self.space.k());
			c[k2] = Some(rng.below(self.space.knobs[k2].n()));
		}
		let full: Config = c.iter().enumerate().map(|(k, o)| Some(o.unwrap_or_else(|| rng.below(self.space.knobs[k].n())))).collect();
		self.space.canonical(&full)
	}

	/// The RATs' prediction losses on unseen query configurations after they trained on the history, and their
	/// gradients with respect to the parameters (fixed + live), added to `mg`. The score RAT's target for a valid
	/// query is its rank score among the history's valid scores plus itself, on the same scale as `prepare`.
	fn rat_meta(&self, pr: &Prepared, hist: &[Guess], measure: &mut dyn FnMut(&Config) -> Option<f64>, q: usize, rng: &mut crate::rng::Rng, mg: &mut MetaGrads) {
		let best = hist.iter().filter(|g| g.score.is_some()).min_by(|a, b| a.score.unwrap().total_cmp(&b.score.unwrap())).map(|g| g.cfg.clone());
		let mut cands: Vec<Config> = Vec::new();
		let mut tries = 0;
		while cands.len() < q && tries < 20 * q {
			tries += 1;
			let c = match (&best, cands.len() % 2) {
				(Some(b), 1) => self.local_move(b, rng),
				_ => self.space.random_config(rng),
			};
			if !pr.seen.contains(&c) && !cands.contains(&c) {
				cands.push(c);
			}
		}
		let m = cands.len();
		if m == 0 {
			return;
		}
		let scores: Vec<Option<f64>> = cands.iter().map(|c| measure(c).filter(|s| s.is_finite())).collect();
		let refs: Vec<&Config> = cands.iter().collect();
		let b = self.ctx.encode(&refs);
		// validity RAT: binary cross-entropy with the same label smoothing as its online training
		{
			let e = self.st.smooth;
			let wa = T::new(m, 1, scores.iter().map(|s| if s.is_some() { 1.0 - e } else { e }).collect());
			let wb = T::new(m, 1, scores.iter().map(|s| if s.is_some() { e } else { 1.0 - e }).collect());
			let mut tape = Tape::new();
			let p = self.models.vrat.ps.nodes(&mut tape, true);
			let cb = tape.constant(b.clone());
			let out = self.models.vrat.forward(&mut tape, &p, &self.ctx, cb, m, &pr.vrat, false);
			let neg = tape.scale(out, -1.0);
			let a = tape.softplus(neg);
			let bb = tape.softplus(out);
			let ca = tape.constant(wa);
			let cb2 = tape.constant(wb);
			let la = tape.mul(a, ca);
			let lb = tape.mul(bb, cb2);
			let s = tape.add(la, lb);
			let tot = tape.sum(s);
			let loss = tape.scale(tot, 1.0 / m as f64);
			if tape.val(loss).v[0].is_finite() {
				mg.add(2, tape.backward(loss));
			}
		}
		let vs: Vec<f64> = hist.iter().filter_map(|g| g.score).collect();
		let nq = scores.iter().filter(|s| s.is_some()).count();
		if vs.is_empty() || nq == 0 {
			return;
		}
		let nv = vs.len() as f64;
		let mut y = vec![0.0; m];
		let mut w = vec![0.0; m];
		for (j, s) in scores.iter().enumerate() {
			if let Some(s) = s {
				let less = vs.iter().filter(|&&v| v < *s).count() as f64;
				let eq = vs.iter().filter(|&&v| v == *s).count() as f64;
				let rank = less + eq / 2.0;
				y[j] = self.st.score_scale * (2.0 * (rank + 0.5) / (nv + 1.0) - 1.0);
				w[j] = 1.0 / nq as f64;
			}
		}
		let mut tape = Tape::new();
		let p = self.models.srat.ps.nodes(&mut tape, true);
		let cb = tape.constant(b);
		let out = self.models.srat.forward(&mut tape, &p, &self.ctx, cb, m, &pr.srat, false);
		let t = tape.constant(T::new(m, 1, y));
		let d = tape.sub(out, t);
		let sq = tape.square(d);
		let wc = tape.constant(T::new(m, 1, w));
		let wl = tape.mul(sq, wc);
		let loss = tape.sum(wl);
		if tape.val(loss).v[0].is_finite() {
			mg.add(1, tape.backward(loss));
		}
	}

	/// A practice run for first-order pretraining: the same run as `run`, plus meta-gradients collected at every
	/// guess after the first (the RATs' query losses after they train on the history, and Linguini's loss before it
	/// trains). Queries are measured but never enter the history.
	pub fn meta_run(&mut self, measure: &mut dyn FnMut(&Config) -> Option<f64>, mc: &MetaCfg, mg: &mut MetaGrads, seed: u64) -> Vec<Guess> {
		self.models.reset_live();
		self.adam = [Adam::new(&self.models.lin.ps), Adam::new(&self.models.srat.ps), Adam::new(&self.models.vrat.ps)];
		let mut rng = crate::rng::Rng::new(seed);
		let mut hist: Vec<Guess> = Vec::with_capacity(self.st.guesses);
		for _ in 0..self.st.guesses {
			let cfg = if hist.is_empty() {
				self.space.first_guess(SEED)
			} else {
				let pr = prepare(self.space, &self.ctx, &hist, self.st.score_scale);
				self.train_rats(&pr);
				if mc.rats {
					self.rat_meta(&pr, &hist, measure, mc.queries, &mut rng, mg);
				}
				if mc.lin {
					let g = self.build(&pr, hist.len(), true, None);
					let t = g.terms.unwrap();
					if g.tape.val(t.total).v[0].is_finite() {
						mg.add(0, g.tape.backward(t.total));
					}
				}
				for _ in 0..self.st.lin_steps {
					self.linguini_step(&pr, hist.len());
				}
				self.build(&pr, hist.len(), false, None).cfg
			};
			let score = measure(&cfg).filter(|s| s.is_finite());
			hist.push(Guess { cfg, score, secs: 0.0 });
		}
		hist
	}
}
