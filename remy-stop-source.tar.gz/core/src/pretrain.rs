//! First-order pretraining with Reptile (Nichol, Achiam and Schulman, 2018, "On First-Order Meta-Learning
//! Algorithms"): practice runs on training sampler problems, each from the current fixed values with live values
//! at 0; after a batch of practice runs, the fixed values move toward fixed + live by a step beta (the batch mean of
//! the live values), and live resets. Validation (mean best percentile on held-out problems) runs every few
//! steps; pretraining stops when it hasn't improved for `patience` validations, and keeps the best fixed values.

use crate::eval::{Task, mean, parallel, remy_run, tasks};
use crate::model::Models;
use crate::remy::{Remy, Settings};
use crate::rng::{Rng, SEED, mix};
use crate::sampler::{Problem, TRAIN_MAX};
use std::io::Write;
use std::time::Instant;

#[derive(Clone, Debug)]
pub struct PretrainCfg {
	pub meta_batch: usize,
	pub beta: f64,
	pub eval_every: usize,
	pub patience: usize,
	pub max_iters: usize,
	pub stop_ids: Vec<u64>,
}

impl PretrainCfg {
	pub fn describe(&self) -> String {
		format!(
			"reptile meta_batch {} beta {} eval_every {} patience {} max_iters {} stopping-validation ids {}..={} ({} problems)",
			self.meta_batch,
			self.beta,
			self.eval_every,
			self.patience,
			self.max_iters,
			self.stop_ids.first().unwrap_or(&0),
			self.stop_ids.last().unwrap_or(&0),
			self.stop_ids.len()
		)
	}
}

/// One practice run; returns the models at its end (live values as learned).
pub fn practice(p: &Problem, models: &Models, st: &Settings) -> Models {
	let mut remy = Remy::new(&p.space, models.clone(), st.clone());
	let mut measure = |cfg: &crate::space::Config| p.score(&p.space.values(cfg));
	remy.run(&mut measure, &mut |_, _| {});
	remy.models
}

pub fn validate(stop: &[Task], models: &Models, st: &Settings, threads: usize) -> f64 {
	let r = parallel(stop.len(), threads, |i| remy_run(&stop[i], models, st).0.pct);
	mean(&r)
}

pub fn pretrain(cfg: &PretrainCfg, st: &Settings, out: &str, log: &str, threads: usize) -> Models {
	let start = Instant::now();
	let stop = tasks(&cfg.stop_ids, threads);
	let mut fixed = Models::new(SEED);
	let mut logf = std::fs::File::create(log).expect("pretraining log");
	writeln!(logf, "# first-order pretraining, seed {SEED}; {}; settings {}", cfg.describe(), st.describe()).unwrap();
	writeln!(logf, "iter\tpractice_runs\tseconds\tvalidation_pct\tbest_pct\tsince_best\tstep_norm").unwrap();
	let mut best = validate(&stop, &fixed, st, threads);
	let mut best_models = fixed.clone();
	let mut best_iter = 0;
	writeln!(logf, "0\t0\t{:.1}\t{best:.5}\t{best:.5}\t0\t0", start.elapsed().as_secs_f64()).unwrap();
	eprintln!("pretrain: iteration 0, validation {best:.5}");
	let save = |m: &Models, iter: usize, score: f64, secs: f64| {
		let header = format!(
			"remy first-order weights (Reptile)\nseed {SEED}\nbest at iteration {iter}, {} practice runs, stopping-validation mean best percentile {score:.6}, {secs:.1} s of pretraining so far\n{}\nsettings {}",
			iter * cfg.meta_batch,
			cfg.describe(),
			st.describe()
		);
		std::fs::write(out, m.save_text(&header)).expect("write weights");
	};
	save(&best_models, 0, best, start.elapsed().as_secs_f64());
	let mut ids = Rng::new(mix(SEED, 0x7EA1));
	let mut since = 0;
	let mut iter = 0;
	while iter < cfg.max_iters {
		iter += 1;
		let batch: Vec<u64> = (0..cfg.meta_batch).map(|_| 1 + ids.below(TRAIN_MAX as usize - 1) as u64).collect();
		let ends = parallel(batch.len(), threads, |i| practice(&Problem::new(batch[i]), &fixed, st));
		let mut sq = 0.0;
		let nsets = 3;
		for s in 0..nsets {
			let np = fixed.sets()[s].names.len();
			for pi in 0..np {
				let len = fixed.sets()[s].fixed[pi].len();
				for j in 0..len {
					let m: f64 = ends.iter().map(|e| e.sets()[s].live[pi][j]).sum::<f64>() / ends.len() as f64;
					if m.is_finite() {
						let step = cfg.beta * m;
						fixed.sets_mut()[s].fixed[pi][j] += step;
						sq += step * step;
					}
				}
			}
		}
		fixed.reset_live();
		if iter % cfg.eval_every == 0 {
			let v = validate(&stop, &fixed, st, threads);
			if v > best {
				best = v;
				best_models = fixed.clone();
				best_iter = iter;
				since = 0;
				save(&best_models, best_iter, best, start.elapsed().as_secs_f64());
			} else {
				since += 1;
			}
			writeln!(logf, "{iter}\t{}\t{:.1}\t{v:.5}\t{best:.5}\t{since}\t{:.4}", iter * cfg.meta_batch, start.elapsed().as_secs_f64(), sq.sqrt()).unwrap();
			logf.flush().ok();
			eprintln!("pretrain: iteration {iter}, validation {v:.5}, best {best:.5} (iteration {best_iter}), since best {since}, {:.0} s", start.elapsed().as_secs_f64());
			if since >= cfg.patience {
				break;
			}
		}
	}
	writeln!(logf, "# stopped at iteration {iter}; best iteration {best_iter}, validation {best:.6}; {:.1} s", start.elapsed().as_secs_f64()).unwrap();
	best_models
}

/// First-order pretraining by meta-gradients (first-order MAML, Finn, Abbeel and Levine, 2017, with the first-order
/// approximation): each practice run trains the live values exactly as a run does, and at every guess the RATs'
/// losses on unseen query configurations (and Linguini's loss before it trains) give gradients with respect to the
/// parameters, which move the fixed values by Adam. Validation and the stopping rule are the same as Reptile's.
#[derive(Clone, Debug)]
pub struct MetaPretrainCfg {
	pub meta_batch: usize,
	pub lr: f64,
	pub clip: f64,
	pub eval_every: usize,
	pub patience: usize,
	pub max_iters: usize,
	pub stop_ids: Vec<u64>,
	pub mc: crate::remy::MetaCfg,
}

impl MetaPretrainCfg {
	pub fn describe(&self) -> String {
		format!(
			"meta (first-order MAML) meta_batch {} lr {} clip {} queries {} lin {} rats {} eval_every {} patience {} max_iters {} stopping-validation ids {}..={} ({} problems)",
			self.meta_batch,
			self.lr,
			self.clip,
			self.mc.queries,
			self.mc.lin,
			self.mc.rats,
			self.eval_every,
			self.patience,
			self.max_iters,
			self.stop_ids.first().unwrap_or(&0),
			self.stop_ids.last().unwrap_or(&0),
			self.stop_ids.len()
		)
	}
}

pub fn pretrain_meta(cfg: &MetaPretrainCfg, st: &Settings, init: Models, out: &str, log: &str, threads: usize) -> Models {
	use crate::model::Adam;
	use crate::remy::MetaGrads;
	let start = Instant::now();
	let stop = tasks(&cfg.stop_ids, threads);
	let mut fixed = init;
	fixed.reset_live();
	let mut adams: Vec<Adam> = fixed.sets().iter().map(|ps| Adam::new(ps)).collect();
	let mut logf = std::fs::File::create(log).expect("pretraining log");
	writeln!(logf, "# first-order pretraining, seed {SEED}; {}; settings {}", cfg.describe(), st.describe()).unwrap();
	writeln!(logf, "iter\tpractice_runs\tseconds\tvalidation_pct\tbest_pct\tsince_best\tlin_grad\tsrat_grad\tvrat_grad").unwrap();
	let mut best = validate(&stop, &fixed, st, threads);
	let mut best_models = fixed.clone();
	let mut best_iter = 0;
	writeln!(logf, "0\t0\t{:.1}\t{best:.5}\t{best:.5}\t0\t0\t0\t0", start.elapsed().as_secs_f64()).unwrap();
	eprintln!("pretrain: iteration 0, validation {best:.5}");
	let save = |m: &Models, iter: usize, score: f64, secs: f64| {
		let header = format!(
			"remy first-order weights (meta)\nseed {SEED}\nbest at iteration {iter}, {} practice runs, stopping-validation mean best percentile {score:.6}, {secs:.1} s of pretraining so far\n{}\nsettings {}",
			iter * cfg.meta_batch,
			cfg.describe(),
			st.describe()
		);
		std::fs::write(out, m.save_text(&header)).expect("write weights");
	};
	save(&best_models, 0, best, start.elapsed().as_secs_f64());
	let mut ids = Rng::new(mix(SEED, 0x3E7A));
	let mut since = 0;
	let mut iter = 0;
	let mut gnorm = [0.0f64; 3];
	while iter < cfg.max_iters {
		iter += 1;
		let batch: Vec<u64> = (0..cfg.meta_batch).map(|_| 1 + ids.below(TRAIN_MAX as usize - 1) as u64).collect();
		let parts = parallel(batch.len(), threads, |i| {
			let p = Problem::new(batch[i]);
			let mut remy = Remy::new(&p.space, fixed.clone(), st.clone());
			let mut mg = MetaGrads::new(&fixed);
			let mut measure = |c: &crate::space::Config| p.score(&p.space.values(c));
			remy.meta_run(&mut measure, &cfg.mc, &mut mg, mix(SEED, batch[i] ^ 0x3E7A_0000));
			mg
		});
		let mut total = MetaGrads::new(&fixed);
		for p in &parts {
			total.merge(p);
		}
		for s in 0..3 {
			if total.n[s] == 0.0 {
				continue;
			}
			let ps = &mut fixed.sets_mut()[s];
			let g = total.mean(s, ps);
			gnorm[s] = g.iter().flat_map(|(_, t)| t.v.iter()).map(|x| x * x).sum::<f64>().sqrt();
			// Adam moves `live`; swap so that it moves the fixed values, then swap back (live stays 0)
			std::mem::swap(&mut ps.fixed, &mut ps.live);
			adams[s].step(ps, g, cfg.lr, cfg.clip);
			std::mem::swap(&mut ps.fixed, &mut ps.live);
		}
		if iter % cfg.eval_every == 0 {
			let v = validate(&stop, &fixed, st, threads);
			if v > best {
				best = v;
				best_models = fixed.clone();
				best_iter = iter;
				since = 0;
				save(&best_models, best_iter, best, start.elapsed().as_secs_f64());
			} else {
				since += 1;
			}
			writeln!(logf, "{iter}\t{}\t{:.1}\t{v:.5}\t{best:.5}\t{since}\t{:.4}\t{:.4}\t{:.4}", iter * cfg.meta_batch, start.elapsed().as_secs_f64(), gnorm[0], gnorm[1], gnorm[2]).unwrap();
			logf.flush().ok();
			eprintln!("pretrain: iteration {iter}, validation {v:.5}, best {best:.5} (iteration {best_iter}), since best {since}, {:.0} s", start.elapsed().as_secs_f64());
			if since >= cfg.patience {
				break;
			}
		}
	}
	writeln!(logf, "# stopped at iteration {iter}; best iteration {best_iter}, validation {best:.6}; {:.1} s", start.elapsed().as_secs_f64()).unwrap();
	best_models
}
