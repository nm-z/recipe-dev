# First-order GPU status

## Queued Codex pacing task

The updated goal adds hourly Codex pacing behind the rates fit and recipe-dev #994. Data and objective are prepared in `/home/nate/ceo-orders/codex-pace/`. `fit.rs` reuses the rates task's 26-line recipe program. No worker was spawned and neither GPU fit was run.

The corrected full rollout scan reads 358 files, 6,981,970,533 bytes, and retains selected token/quota data only. One record fails parsing. The resulting history contains 2,080 hourly rows and 327 token-producing sessions; 256 quota-drop candidates remain explicitly unconfirmed. The current objective uses 824 measured burn/activity observations and 46 reset-time scenarios.

The archived public page contains 59 announcements with fetch time and SHA-256. Banked grants are separated from automatic-reset scenarios. The fresh app-server reading reports weekly usage 83%, the scheduled reset at 2026-10-13 22:28:50 PDT, and one Full reset credit expiring 2026-11-06 15:20:52 PST. No credit was consumed.

`codex-pace.timer` is active on an hourly calendar. Its service runs at Nice 19 and successfully refreshes the one-line `latest.json` and objective data; the recorded extraction takes 0.666691 seconds. While GPU fitting is queued, the output labels 1.1 pp/h as the CEO's interim order and leaves model predictions, agent count, and bank-spend recommendation unmeasured. Zero confirmed bank-spend/refill outcomes exist. The objective can now use nine observed full-refill candidates from the same Codex Pro bucket as an explicitly labeled extrapolation for an available Full reset; these are not relabeled as banked redemptions. Without either source of effect data, a spend-now candidate remains invalid.

Objective checks pass for the unused quota cap, coast endpoint, rush and exhaustion penalties, idle fleet at full allowance, discrete outputs, unknown bank effects, and complete public-page parsing. Evidence is `/home/nate/ceo-orders/codex-pace/proof.json`; the hourly timer and service have been read back. Recipe issue #994 remains open and is now claimed by recipe-lead. Both learned GPU fits remain outstanding.

The hourly GPU-fit path is now wired in `codex-pace/fit.rb`. It requires fresh rates publication with actual amdgpu engine-time evidence, then uses the same bounded executor as rates. Backend preflight additionally requires issue #994 to be closed. Both jobs share a GPU lock; pacing runs four minutes past each hour to avoid the normal rates-refresh start. The real service invocation currently takes the queued path and preserves the CEO's interim target. The coast-stage agent calibration check passes: when less than 20% remains, both scoring and the eventual published target use the fitted coast rate. No learned output is labeled measured before GPU evidence exists; an unmeasured bank decision remains null.

The objective now counts idle time when the allowance starts exhausted. Its rush term measures concentration beyond uniform depletion, so it does not penalize productive quota consumption merely for consuming more quota. It also scores the waste of a banked allowance that expires before the planned cycle ends. Checks pass for those cases and for the explicitly labeled full-refill extrapolation. The latest successful data service run contains 827 burn/activity observations and nine reset-effect candidates. Issue #994 remains open; both GPU fits remain unmeasured.

### Expanded-goal blocked audit

The backend blocker remains unchanged across at least three consecutive turns of the expanded rates-and-pacing goal. Recipe is still at `d3661cef` with ROCm dependencies, and #994 is open with only the recipe-lead claim. `rates-fit.service` rejects preflight; `codex-pace.service` successfully refreshes queued data. Both services report `MainPID=0`, so there is no live fit process to wait on. The data, objective, and fit wiring are prepared. GPU rates publication and all four learned hourly pacing outputs still require #994 to land and its compliant backend to be installed in the configured checkout. The expanded goal is blocked, not complete; its objective remains unchanged.

Updated: 2026-10-07. Lead: `01a114e1-85ac-7a81-84ad-b60dd3b139fb`.

## Quota rates task, October 7

The latest order requests replacing the quota-card NNLS fitter in `/home/nate/ceo-orders/rates/refresh.rb` with recipe knob-mode Remy on engi's GPU, using system LLVM and no ROCm dependencies. Inspection of recipe revision `d3661cef` shows that its AMD artifact compiler still links ROCm bitcode and its device initialization still loads the ROCm HSA runtime. This conflicts with the latest toolchain rule.

Missing backend operation: compile and dispatch composed AMDGPU training using system LLVM without ROCm compiler, bitcode, or runtime dependencies. Filed [recipe issue #994](https://github.com/nm-z/recipe-dev/issues/994) under the order's explicit missing-capability reporting route. This is a backend gap; no fitting math operation has been identified as missing.

`rates-fit.service` runs `/usr/bin/ruby /home/nate/ceo-orders/rates/refresh.rb` with `Nice=19` and idle I/O priority. The refresher now selects the Remy recipe fitter instead of its CPU NNLS/bootstrap path. A service invocation at 2026-10-07 21:43:40 PDT reaches the new backend preflight, rejects the ROCm dependencies, and exits with status 1 after 0.070029 seconds. This time measures the rejected service invocation, not GPU fitting. The final-source recheck also exits with status 1; its preflight duration is 0.064235 seconds, recorded in `integration-state.json`. Remy rates, GPU execution, GPU activity during fitting, and GPU wall time are **not measured**. The original first-order implementation and validation objective remains outstanding.

The rates integration includes a 26-line `/home/nate/ceo-orders/rates/remy-fit.rs` script and a Ruby objective/runner in `remy-fit.rb`. Signed rates are accepted. The objective measures quota-delta error and a weak prior term from retained NNLS diagnostics. `live-fit.rb` accepts the fitter callback for pooled and reasoning-split fits, and its table renderer adds NNLS comparison, status, and snapshot columns. Syntax/interface checks pass. A verification invocation exercises 18 callback calls for five strict and four observational cards, with the CPU fitter replaced by a raising guard; no CPU fit runs. The signed-rate objective and invalid-answer protocol checks pass. GPU execution remains unverified.

The existing `DAILY.md` and `latest.json` publications remain preserved because the real backend preflight fails before fitting. A comparison preview is saved in `/home/nate/codex/rates-remy-proof/DAILY-preview.md`. Do not describe the preview as published rates or GPU proof.

Evidence: `/home/nate/codex/rates-remy-proof/recipe-issue.md`, `integration-state.json`, `integration-check.json`, `service-properties.txt`, `service-journal.txt`, and `ceo-delivery.txt`. No GPU invocation or CPU fitting fallback was run for this task.

CEO delivery used the exact requested route:

```sh
dsh hook --deliver --server-only 91e80780-a93b-4fe3-af92-25324360992a 'Rates fit blocked by recipe backend capability at d3661cef: ...'
```

DSH rejected it with `Server-only delivery requires a known Codex thread; no input submitted`. Delivery is not confirmed, and no alternate messaging route was used.

### Blocked audit

The same backend blocker persists across three consecutive goal turns. The checkout remains at `d3661cef`, its AMD compiler/bitcode/runtime dependencies remain ROCm-based, and recipe issue #994 is open with no comments. The latest service invocation, 2026-10-07 21:48:40 PDT, again exits with status 1; `MainPID=0`, so no fit process is running. The rates integration and its non-training checks are prepared, but compliant GPU execution requires the missing recipe backend capability or an explicit change to the toolchain constraint. The goal is blocked, not complete. Its full GPU fitting and publication objective remains unchanged.

## Current scope

Implement Linguini, both RATs, online training, and batched meta pretraining in Rust recipe. Preserve the CPU reference architecture, `Settings::default()`, and seed `20261006`. All model math and training must execute on the GPU through recipe, with one dispatch per epoch or forward pass. No CPU training.

The latest correction directs use of Rust recipe's existing GPU and toolchain path without migration. This supersedes the intervening recipe-asm direction. The existing Rust recipe configuration names ROCm paths; this report does not characterize those paths as system LLVM. No toolchain changes were made. No extra worker launched.

## Checkouts

- Remy integration: `/home/nate/work/remy/remy-core-gpu`, branch `gpu`.
- Recipe integration: `/home/nate/work/recipe-dev-remy-first`, branch `remy/first-order-gpu`, created from `1b142776`.
- Second-order lead owns `/home/nate/work/recipe-dev-remy`.
- The temporary recipe-asm worktree and branch were removed as instructed.
- Leave `/home/nate/work/remy/remy-core` and `/home/nate/work/remy/second-order` unchanged.

## Evidence

Read the complete design, handoff, survey, updated brief, CPU model/tape/pretraining entrypoints, and recipe source. Searched recipe, the allowed Remy directories, and `jev`. Rust recipe already composes native primitive bodies into one AOT forward or epoch entrypoint. Model integration will use that composition.

Retained CPU validation data exists in `logs/validation-none.tsv` and `logs/validation-none.tsv.none.guesses.tsv`, with the requested settings and seed in the header. Retained meta pretraining timings exist in `logs/pretrain-meta.tsv`. These are prior measurements, not fresh CPU runs. Their suitability for throughput comparison is not yet established.

## Acceptance results

| Check | Result |
|---|---|
| One complete GPU run | not measured |
| Matching full guess sequences, validation 900000–900049 | not measured |
| GPU versus CPU mean best percentile difference | not measured |
| Linguini gradient relative error | not measured |
| Score RAT gradient relative error | not measured |
| Validity RAT gradient relative error | not measured |
| GPU NaNs, repeats, and deterministic rerun | not measured |
| Single-run seconds per proposal | not measured |
| GPU practice runs per second | not measured |
| Comparable CPU practice runs per second | not measured |
| GPU/CPU throughput ratio | not measured |
| One dispatch per epoch or forward pass | not measured |

## Commands executed

```sh
git -C /home/nate/work/recipe-asm worktree add /home/nate/work/recipe-asm-remy-first -b remy/first-order
git -C /home/nate/work/recipe-asm worktree remove --force /home/nate/work/recipe-asm-remy-first
git -C /home/nate/work/recipe-asm branch -D remy/first-order
git -C /home/nate/work/recipe-dev-remy worktree add /home/nate/work/recipe-dev-remy-first -b remy/first-order-gpu
jev --no-judge 'recipe tensor graph training one dispatch system LLVM AMDGPU fixed live Remy'
```

No model training or holdout execution has been started in this session. No forbidden holdout table, trace directory, or recompute directory was opened.
