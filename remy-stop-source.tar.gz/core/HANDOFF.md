# remy-core handoff (2026-10-06, Claude)

Remy's first order as one Rust crate: no external crates, CPU only, `cargo build --release`, seed 20261006 (`src/rng.rs`).
Wrapper scripts `./remy` and `./adapter` run `target/release/{remy,adapter}`. A `remy pretrain` started at 22:15:45 is still running; leave it alone.

## 1. Files and commands
- `src/json.rs` reads JSON. `src/sha256.rs` hashes the trace headers. `src/rng.rs` holds the seed and the RNG.
- `src/space.rs` reads only the `knobs` list of a space.json (ordinal, categorical, float with linear or log scale, int, conditions). It computes the first guess, config text, and exploration entropy (no bins). `./remy first-guess ~/work/remy/holdout/fcnet/space.json`
- `src/tape.rs` is reverse-mode autodiff over small matrices.
- `src/model.rs` holds Linguini, the score RAT, the validity RAT, fixed+live parameters, Adam on live values, the entropy term, and the repeat-rejecting k-best decoder.
  - Each model has its own table: one row per (knob position, option), plus inactive and continuous rows per position and 6 type rows. A continuous knob adds u·row.
  - A token is the sum of its knobs' rows plus [valid, rank score, symlog relative score]. A causal width-3 convolution runs along the guess sequence; one attention head runs from the candidate to the past guesses.
  - The RATs use distance attention, a null token, and a skip connection that averages the past guesses' rank score or valid bit. RAT training is leave-one-out, with the target removed from its sequence.
- `src/remy.rs` is one run: per guess, both RATs train for 20 steps, then Linguini trains for 50 steps through the frozen RATs, then proposes. It also has the gradient probes, finite-difference checks, and a brute-force "oracle" (a diagnostic only).
- `src/sampler.rs` holds the seeded synthetic problems (ids < 800000 train, >= 900000 validation). `./remy sample 900001 --out DIR` writes the space.json, and `./remy problem 900001` serves as its adapter.
- `src/eval.rs` runs problems in parallel, deterministically. Random search draws uniformly over each problem's reference. `src/pretrain.rs` is Reptile.
- `src/bin/adapter.rs` is the holdout adapter: exact lookup, the LCBench snap (rule 17), and kernel-tiles through `measure`. `printf '%s\n' 'name=v,...' | ./adapter fcnet [--with-id]`
- `src/main.rs` is the command-line program:
  - `./remy run --technique none|first-order --challenge S --adapter CMD --out T`. A holdout challenge needs `REMY_EVALUATION=1`.
  - `./remy synth --technique none,random --from 900000 --count 50 [--out F]`
  - `./remy pretrain --out weights/first-order.txt --log logs/pretrain.tsv --meta-batch 16 --beta 0.25 --eval-every 10 --patience 8`
  - `./remy grad-report --from 1 --count 48 --fd-problems 6`, `./remy rat-report --from 1 --count 48`, `./remy sampler-stats --count 1000`, `./remy selftest`
- `checks/adapter-vs-vizier.sh` checks the adapter against the Vizier traces. Logs are in `logs/`; weights are in `weights/`.

## 2. Checks and results
- **FCNet first guess:** 64/64 units, dropout 0.3/0.3, init_lr 0.005, batch 16, plus seeded picks act1=tanh, act2=relu, cosine. `strace` shows that only `space.json` was opened. PASS.
- **Adapter vs the Vizier traces:** 24 of 24 table ids and scores on fcnet, nasbench201, lcbench and kernel-tiles. PASS.
- **selftest** PASS:
  - Tape ops agree with finite differences to 8.8e-7, and both RAT training losses to 7.4e-7.
  - The continuous entropy node is off by 1.4e-5 at h = 1e-7, and the error scales linearly with h, so it is truncation error at kinks.
  - Entropy end points hold (evenly spread = 1, identical = 0, random sets ≤ 0.93). Decoding never repeats, and the same input gives the same guesses.
- **Sampler, 1,000 training problems:**
  - 2–12 knobs (mean 7.4) of all types; 52.6% have conditional knobs and 73.9% an invalid region.
  - The valid share is at least 0.41; the median configuration is in the best 5% on 65 of 1,000 problems.
- **Validation 900000–900049, no pretraining:**
  - 0 repeats, 0 non-finite steps or NaN, 0 decode fallbacks.
  - Final exploration entropy averages 0.444 (minimum 0.097).
  - Invalid share is 18.6% of guesses 1–8, 4.6% of 9–16 and 6.1% of 17–24; random search's is 21%.
- **Online learning:** mean best percentile 0.9509 for Remy vs 0.9495 for random search. The difference is +0.0014 (standard error 0.0095), which is a tie. Remy is higher on 34 problems, lower on 14 and tied on 2 (sign test p = 0.006); median 0.989 vs 0.959.
- **t_propose** per guess: mean 0.12 s, median 0.093 s, p95 0.28 s, max 0.37 s.
- **Loss-term gradient sizes** at the frozen settings: the median ratio ŝ : −λH is 1.4. The ratio of −ln P to ŝ is 0.15 when the history holds an invalid guess and 6e-4 when it is all valid (inactive, as it should be).
- **Finite differences on Linguini's parameters, with biases included:** no sign disagreements on any term. On gradients above 1e-6 the relative error is 2.9e-4 for ŝ, 8.3e-6 for −ln P and 4.4e-3 for −λH.
- **The λH discrepancy:**
  - Earlier it was systematic, about 7% (stable across h), and bisection placed it in continuous knobs.
  - The cause was kinks at exact ties on the value grid: the candidate equidistant from two past guesses, or a past guess's nearest distance equal to its distance to the candidate. My code took a one-sided slope there. It now uses the symmetric subgradient.
  - What remains is finite-difference truncation at kinks, plus a max relative error of 0.79 on gradients below 1e-6.
  - Suspicion: at an exact tie the symmetric subgradient is 0, so the entropy term never pushes a candidate off a tied value.
- **Pretraining, still running:** the stopping-validation score was 0.934 at iteration 0, then 0.916, 0.911 and 0.907 at iterations 10, 20 and 30. Reptile is making Remy worse. `weights/first-order.txt` currently holds iteration 0 (the seeded initialization). With patience 8 it should stop at iteration 80, around 10 minutes in. Remy with first-order pretraining vs no pretraining on the validation problems: not measured.

## 3. Settings tuned and why (on training ids 1–192 only; validation was not used)
- **Logits:** standardized per knob with τ = 1.5. Without this, the softmaxes collapse after two guesses, the straight-through gradient dies, and runs get stuck (0.877 vs random 0.955).
- **λ = 10:** the brute-force oracle on the same RATs gives 0.949, 0.966, 0.986 and 0.988 at λ = 1, 3, 10 and 30. With Linguini, λ = 10 was best.
- **Linguini steps:** 50 at learning rate 0.03. 20 steps gave 0.937; 50 gave 0.956; 100 and 200 gave 0.95–0.96 for 1.5–2.3 times the time. A learning rate of 0.1 hurt.
- **Label smoothing 0.05 on the validity RAT:** without it, an all-invalid history drove −ln P to about 40 everywhere, and one run was 24 of 24 invalid. Its effect is at noise level overall.
- **Decoding (`mean_decode`):**
  - I use 0 (argmax for every knob). Argmax drives continuous knobs to the ends of their range, because the straight-through Taylor estimate is linear in u.
  - Decoding at the mean (1 for continuous knobs, 2 for continuous and ordinal, with `tau_ordered` = 5) removes the endpoints but scored worse overall (0.90–0.95). Also tried without a clear gain: RAT steps 40 at learning rate 0.02.
- **Left fixed:**
  - Widths: D 32, DA 16, DV 16, HID 32.
  - RAT steps 20 at learning rate 0.01; clip 5; rank-score scale 1.
  - Entropy distance floor δ = 0.005; continuous value grid of 1,001 steps, with 21 softmax points per continuous knob.

## 4. Open bugs and suspicions
- **Linguini is the bottleneck:** 0.936 vs the oracle's 0.988 on the same loss. It optimizes locally, drifts to corners or range ends, and can't jump back to a distant good region. A few bad runs (minimum around 0.65) pull the mean down to random's level.
- **The validity RAT generalizes all-invalid histories into "invalid everywhere"**, because its null prior is a live value that learns.
- **Reptile degrades validation:** the step norm is about 4 per iteration. β = 0.25 may be too large, or Linguini's live deltas, which are specific to each problem, may hurt when averaged.
- **The sampler only exercises low option rows:** ordinal knobs have at most 10 values and categorical at most 6, so option rows above index 10 never train. Kernel-tiles has 38 options.
- **The RAT's leave-one-out sequences cost O(n²) rows,** which dominates t_propose.
- **Leak review, for transparency:** I printed first guesses for all four holdout spaces (space reader only) and sent one hand-typed FCNet configuration (the first guess) to the adapter, which returned 0.01555. No Remy model ever ran on a holdout challenge.

## 5. What I'd do next
1. Let pretraining stop. If it ends at iteration 0, rerun it with β = 0.05, or with Reptile applied to the RATs only, then run `synth --technique first-order,none,random`.
2. Widen the sampler's ordinal and categorical option counts (up to 40) so pretraining reaches higher option rows.
3. Give the validity RAT's null prior a fixed or regularized live value.
4. Look into Linguini's corner drift. One possibility: train on the k-best batch of decodes instead of one decode per step.

## Final report
I built Remy's first order as a standalone Rust program in ~/work/remy/remy-core, along with the holdout adapter, the sampler and Reptile pretraining. The FCNet first guess, the adapter check against the Vizier traces, the gradient checks and the sanity checks all pass. With no pretraining on 50 validation problems, Remy never repeats a guess, produces no NaN, keeps every run's exploration entropy above 0 (minimum 0.097), and cuts its invalid guesses from 18.6% early in the run to 5–6% late. It beats random search on 34 of 50 problems (p = 0.006), but its mean best percentile is a statistical tie with random search's (0.951 vs 0.950). The brute-force oracle reaches 0.988 on the same loss and RATs, so Linguini's optimization is the weak link. First-order pretraining is running and, so far, makes validation worse (0.934 to 0.907), so the comparison of first-order pretraining with no pretraining is not measured yet.
